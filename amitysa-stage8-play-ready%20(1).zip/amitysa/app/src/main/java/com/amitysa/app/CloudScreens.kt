package com.amitysa.app

import android.content.Context
import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

internal fun shareText(ctx: Context, text: String) {
    ctx.startActivity(
        Intent.createChooser(
            Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, text),
            "Share invite"
        ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    )
}

@Composable
internal fun CloudScreen(account: Account, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val t = LocalAmity.current
    val scope = rememberCoroutineScope()
    val cloud = remember { CloudStore(ctx) }
    val childStore = remember { ChildStore(ctx) }
    val owner = account.email
    val me = remember { cloud.accountId(owner) }
    val educator = account.role == Role.EDUCATOR
    val noun = if (educator) "learners" else "children"

    var url by remember { mutableStateOf(cloud.url(owner)) }
    var connected by remember { mutableStateOf(cloud.enabled(owner)) }
    var links by remember { mutableStateOf(cloud.cachedLinks(owner)) }
    var status by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    var inviteText by remember { mutableStateOf("") }
    var setupUrl by remember { mutableStateOf("") }
    var setupKey by remember { mutableStateOf("") }
    var joinText by remember { mutableStateOf("") }
    var tick by remember { mutableStateOf(0) }

    fun client() = CloudClient(url, cloud.token(owner))

    suspend fun doSync() {
        status = CloudSync.syncAll(ctx, account)
        links = cloud.cachedLinks(owner)
        tick++
    }

    fun launchCloud(block: suspend () -> Unit) {
        scope.launch {
            busy = true
            status = null
            try { block() } catch (e: CloudException) { status = e.message } finally { busy = false }
        }
    }

    val buttonColors = ButtonDefaults.buttonColors(
        containerColor = t.primary, contentColor = if (t.dark) Color(0xFF04201F) else Color.White
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(t.canvas)
            .verticalScroll(rememberScrollState())
            .imePadding()
            .navigationBarsPadding()
    ) {
        ScreenHeader("Cloud link (optional)", onBack)
        Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {

            CloudCard {
                Text("Your choice", color = t.ink, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                Text(
                    "AmitySA works fully on its own. Linking is optional and stays off until you choose it. " +
                        "Parents and teachers keep their own accounts and never see each other's login details. " +
                        "A link only shares your username and the $noun you choose to share: names, grade, class, school, " +
                        "guardian contact and feature settings. Notes and allergies never leave your phone.",
                    color = t.inkSoft, fontSize = 13.sp
                )
            }

            if (!connected) {
                CloudCard {
                    Text("Join with an invite", color = t.ink, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                    Text(
                        "The parent or teacher you want to link with sends you an invite from their app. " +
                            "Paste it here. You don't need a server address, key or anyone's login.",
                        color = t.inkSoft, fontSize = 13.sp
                    )
                    AuthField(inviteText, { inviteText = it; status = null }, "Invite (ABCD2345@https://…)", KeyboardType.Uri)
                    Button(
                        onClick = {
                            val invite = parseInvite(inviteText)
                            if (invite == null) { status = "That doesn't look like an invite."; return@Button }
                            launchCloud {
                                val token = withContext(Dispatchers.IO) { CloudClient(invite.url, "").joinInvite(invite.code, me, account) }
                                cloud.connect(owner, invite.url, token)
                                url = invite.url
                                connected = true
                                inviteText = ""
                                doSync()
                            }
                        },
                        enabled = !busy,
                        modifier = Modifier.fillMaxWidth().height(50.dp),
                        shape = RoundedCornerShape(14.dp), colors = buttonColors
                    ) { Text(if (busy) "Joining…" else "Join", fontWeight = FontWeight.SemiBold) }
                }

                CloudCard {
                    Text("Setting up for the first time?", color = t.ink, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                    Text(
                        "Only one person needs to do this, once, for example the parent who hosts the server (see the server folder in the project). " +
                            "The access key is used just to register this phone and is not kept. After that you invite others with a code.",
                        color = t.inkSoft, fontSize = 13.sp
                    )
                    AuthField(setupUrl, { setupUrl = it.trim(); status = null }, "Server address (https://…)", KeyboardType.Uri)
                    AuthField(setupKey, { setupKey = it.trim(); status = null }, "Access key", password = true)
                    OutlinedButton(
                        onClick = {
                            if (!setupUrl.startsWith("https://")) { status = "The address must start with https://"; return@OutlinedButton }
                            if (setupKey.length < 16) { status = "Enter the full access key."; return@OutlinedButton }
                            launchCloud {
                                val token = withContext(Dispatchers.IO) { CloudClient(setupUrl, setupKey).register(me, account) }
                                cloud.connect(owner, setupUrl, token)
                                url = setupUrl
                                connected = true
                                setupKey = ""
                                doSync()
                            }
                        },
                        enabled = !busy,
                        modifier = Modifier.fillMaxWidth().height(50.dp), shape = RoundedCornerShape(14.dp)
                    ) { Text(if (busy) "Connecting…" else "Set up & connect", color = t.primary, fontWeight = FontWeight.SemiBold) }
                }
            } else {
                CloudCard {
                    Text("✓ Connected", color = t.ink, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                    Text(url, color = t.inkSoft, fontSize = 12.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Button(
                            onClick = { launchCloud { doSync() } },
                            enabled = !busy, shape = RoundedCornerShape(14.dp), colors = buttonColors
                        ) { Text(if (busy) "Working…" else "Sync now", fontWeight = FontWeight.SemiBold) }
                        OutlinedButton(
                            onClick = {
                                cloud.disconnect(owner)
                                connected = false; links = emptyList(); url = ""; status = null
                            },
                            shape = RoundedCornerShape(14.dp)
                        ) { Text("Disconnect", color = Danger, fontWeight = FontWeight.SemiBold) }
                    }
                    Text(
                        "Disconnecting only stops this phone from syncing. Use “Remove link” first if you want the shared details taken off the server.",
                        color = t.inkSoft, fontSize = 12.sp
                    )
                }

                CloudCard {
                    Text(if (educator) "Link with a parent" else "Link with an educator", color = t.ink, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                    Text(
                        "Create an invite and send it to them, or paste one they sent you. Invites last 24 hours and contain no passwords. " +
                            "Linking is only between a parent and a teacher, and either of you can remove it at any time.",
                        color = t.inkSoft, fontSize = 13.sp
                    )
                    Button(
                        onClick = { launchCloud { withContext(Dispatchers.IO) { client().createLink() }; doSync() } },
                        enabled = !busy, modifier = Modifier.fillMaxWidth().height(48.dp),
                        shape = RoundedCornerShape(14.dp), colors = buttonColors
                    ) { Text("Create an invite", fontWeight = FontWeight.SemiBold) }
                    AuthField(joinText, { joinText = it; status = null }, "…or paste an invite you were sent", KeyboardType.Uri)
                    OutlinedButton(
                        onClick = {
                            val invite = parseInvite(joinText)
                            val code = invite?.code ?: joinText.trim().uppercase()
                            if (code.length != 8) { status = "That doesn't look like an invite."; return@OutlinedButton }
                            if (invite != null && invite.url.trimEnd('/') != url.trimEnd('/')) {
                                status = "This invite is for a different server. Disconnect first to use it."
                                return@OutlinedButton
                            }
                            launchCloud {
                                withContext(Dispatchers.IO) { client().join(code) }
                                joinText = ""
                                doSync()
                            }
                        },
                        enabled = !busy, modifier = Modifier.fillMaxWidth().height(48.dp), shape = RoundedCornerShape(14.dp)
                    ) { Text("Join", color = t.primary, fontWeight = FontWeight.SemiBold) }
                }

                // The link list is only ever shown here, inside parent and teacher accounts.
                links.forEach { link ->
                    val unused = tick
                    val sharedCount = childStore.list(owner).count { it.linkId == link.linkId }
                    val unsharedCount = childStore.list(owner).count { it.linkId.isBlank() }
                    CloudCard {
                        if (link.status == "active") {
                            Text(
                                "🔗 ${link.partnerName} · ${link.partnerRole.replaceFirstChar { it.uppercase() }}",
                                color = t.ink, fontWeight = FontWeight.Bold, fontSize = 16.sp
                            )
                            Text(
                                "Equal admin rights: you and ${link.partnerName} can both add, edit and remove the $noun on this link, " +
                                    "and choose which features are active for each one. Neither of you sees the other's login details.",
                                color = t.inkSoft, fontSize = 13.sp
                            )
                            Text("$sharedCount $noun shared on this link.", color = t.ink, fontSize = 14.sp, fontWeight = FontWeight.Medium)
                            if (unsharedCount > 0) {
                                Button(
                                    onClick = {
                                        childStore.shareAll(owner, link.linkId)
                                        launchCloud { doSync() }
                                    },
                                    enabled = !busy, shape = RoundedCornerShape(14.dp), colors = buttonColors
                                ) { Text("Share my other $unsharedCount with ${link.partnerName}", fontWeight = FontWeight.SemiBold) }
                            }
                            Text(
                                "To share just one, open it under Children and choose Share.",
                                color = t.inkSoft, fontSize = 12.sp
                            )
                        } else {
                            val invite = makeInvite(link.code, url)
                            Text("⏳ Waiting for the other person", color = t.ink, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                            Text("Send them this invite:", color = t.inkSoft, fontSize = 13.sp)
                            Text(invite, color = t.primary, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                            OutlinedButton(onClick = { shareText(ctx, invite) }, shape = RoundedCornerShape(14.dp)) {
                                Text("Share invite", color = t.primary, fontWeight = FontWeight.SemiBold)
                            }
                        }
                        Text(
                            "Remove link", color = Danger, fontSize = 13.sp, fontWeight = FontWeight.SemiBold,
                            modifier = Modifier.clickable(enabled = !busy) {
                                launchCloud {
                                    withContext(Dispatchers.IO) { client().revokeLink(link.linkId) }
                                    doSync()
                                }
                            }.padding(vertical = 6.dp)
                        )
                    }
                }
            }

            status?.let {
                Text(it, color = if (it.startsWith("Synced")) t.primary else Danger, fontSize = 13.sp)
            }
        }
    }
}

@Composable
private fun CloudCard(content: @Composable ColumnScope.() -> Unit) {
    val t = LocalAmity.current
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = t.card),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp), content = content)
    }
}

package com.amitysa.app

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
internal fun ScreenHeader(title: String, onBack: () -> Unit) {
    val theme = LocalAmity.current
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(bottomStart = 28.dp, bottomEnd = 28.dp))
            .background(Brush.verticalGradient(listOf(theme.primary, theme.primary.copy(alpha = 0.84f))))
            .statusBarsPadding()
            .padding(horizontal = 12.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            "←", color = theme.onAccent, fontSize = 24.sp,
            modifier = Modifier.clip(CircleShape).clickable(onClick = onBack).padding(horizontal = 14.dp, vertical = 6.dp)
        )
        Text(title, color = theme.onAccent, fontSize = 22.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
internal fun ChildrenScreen(
    account: Account,
    store: ChildStore,
    onBack: () -> Unit,
    onEdit: (String?) -> Unit
) {
    val t = LocalAmity.current
    val educator = account.role == Role.EDUCATOR
    val ctx = LocalContext.current
    val cloud = remember { CloudStore(ctx) }
    var records by remember { mutableStateOf(store.list(account.email)) }
    val clock = remember { SimpleDateFormat("HH:mm", Locale.getDefault()) }
    LaunchedEffect(Unit) {
        if (cloud.enabled(account.email)) {
            try {
                CloudSync.syncAll(ctx, account)
                records = store.list(account.email)
            } catch (e: Exception) { /* offline: keep what is on this phone */ }
        }
    }
    fun extraFor(c: Child): String {
        val parts = mutableListOf<String>()
        if (c.linkId.isNotBlank()) parts.add("🔗 Linked")
        if (account.role == Role.PARENT || BuildConfig.EDUCATOR_SEES_LOCATION) {
            cloud.fix(account.email, c.id)?.let { parts.add("📍 " + clock.format(Date(it.time))) }
        }
        return parts.joinToString(" · ")
    }
    var school by remember { mutableStateOf(store.school(account.email)) }
    var editSchool by remember { mutableStateOf(false) }
    val noun = if (educator) "learner" else "child"

    LazyColumn(
        modifier = Modifier.fillMaxSize().background(t.canvas),
        contentPadding = PaddingValues(bottom = 40.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item { ScreenHeader(if (educator) "My learners" else "My children", onBack) }
        if (educator) item { SchoolCard(school) { editSchool = true } }
        item {
            Button(
                onClick = { onEdit(null) },
                modifier = Modifier.padding(horizontal = 20.dp).fillMaxWidth().height(52.dp),
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = t.primary,
                    contentColor = if (t.dark) Color(0xFF04201F) else Color.White
                )
            ) { Text("＋ Add $noun", fontWeight = FontWeight.SemiBold) }
        }
        if (records.isEmpty()) {
            item {
                Column(
                    modifier = Modifier.fillMaxWidth().padding(32.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(if (educator) "🏫" else "🧒", fontSize = 44.sp)
                    Spacer(Modifier.height(8.dp))
                    Text("No ${noun}s yet", color = t.ink, fontWeight = FontWeight.SemiBold, fontSize = 18.sp)
                    Text(
                        "Add your first $noun. Details are saved on this phone and work offline.",
                        color = t.inkSoft, fontSize = 13.sp, textAlign = TextAlign.Center
                    )
                }
            }
        } else if (educator) {
            val groups = records.groupBy { it.className.ifBlank { "No class" } }.toSortedMap()
            groups.forEach { (cls, list) ->
                item(key = "h_$cls") {
                    Text(
                        "$cls · ${list.size}",
                        modifier = Modifier.padding(horizontal = 24.dp),
                        color = t.ink, fontWeight = FontWeight.Bold, fontSize = 16.sp
                    )
                }
                items(list, key = { it.id }) { ChildCard(it, educator, extraFor(it)) { onEdit(it.id) } }
            }
        } else {
            items(records, key = { it.id }) { ChildCard(it, educator, extraFor(it)) { onEdit(it.id) } }
        }
    }

    if (editSchool) {
        SchoolDialog(
            current = school,
            onSave = { school = it.trim(); store.setSchool(account.email, school); editSchool = false },
            onDismiss = { editSchool = false }
        )
    }
}

@Composable
private fun SchoolCard(school: String, onEdit: () -> Unit) {
    val t = LocalAmity.current
    Card(
        modifier = Modifier.padding(horizontal = 20.dp).fillMaxWidth().clickable(onClick = onEdit),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = t.card),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("🏫", fontSize = 26.sp)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text("My school", color = t.inkSoft, fontSize = 12.sp)
                Text(
                    school.ifBlank { "Tap to add your school" },
                    color = if (school.isBlank()) t.primary else t.ink,
                    fontWeight = FontWeight.SemiBold, fontSize = 17.sp
                )
            }
            Text("Edit", color = t.primary, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
        }
    }
}

@Composable
private fun SchoolDialog(current: String, onSave: (String) -> Unit, onDismiss: () -> Unit) {
    val t = LocalAmity.current
    var value by remember { mutableStateOf(current) }
    Dialog(onDismissRequest = onDismiss) {
        Card(shape = RoundedCornerShape(24.dp), colors = CardDefaults.cardColors(containerColor = t.card)) {
            Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("School name", color = t.ink, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                AuthField(value, { value = it.take(60) }, "School", capitalize = true)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                    TextButton(onClick = onDismiss) { Text("Cancel", color = t.inkSoft) }
                    TextButton(onClick = { onSave(value) }) {
                        Text("Save", color = t.primary, fontWeight = FontWeight.SemiBold)
                    }
                }
            }
        }
    }
}

@Composable
private fun ChildCard(child: Child, educator: Boolean, extra: String = "", onClick: () -> Unit) {
    val t = LocalAmity.current
    Row(
        modifier = Modifier
            .padding(horizontal = 20.dp)
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(t.card)
            .clickable(onClick = onClick)
            .padding(14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier.size(46.dp).clip(CircleShape).background(t.primary.copy(alpha = 0.18f)),
            contentAlignment = Alignment.Center
        ) {
            Text(
                child.firstName.take(1).uppercase(),
                color = t.primary, fontWeight = FontWeight.Bold, fontSize = 20.sp
            )
        }
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(child.fullName, color = t.ink, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
            val line = listOf(child.grade, if (!educator) child.className else "").filter { it.isNotBlank() }.joinToString(" · ")
            if (line.isNotBlank()) Text(line, color = t.inkSoft, fontSize = 13.sp)
            if (!educator && child.school.isNotBlank()) Text(child.school, color = t.inkSoft, fontSize = 12.sp)
            if (extra.isNotBlank()) Text(extra, color = t.primary, fontSize = 12.sp)
        }
        Text("›", color = t.inkSoft, fontSize = 22.sp)
    }
}

@Composable
internal fun ChildEditScreen(
    account: Account,
    store: ChildStore,
    id: String?,
    onDone: () -> Unit
) {
    val t = LocalAmity.current
    val educator = account.role == Role.EDUCATOR
    val existing = remember { id?.let { store.find(account.email, it) } }
    var first by remember { mutableStateOf(existing?.firstName ?: "") }
    var last by remember { mutableStateOf(existing?.lastName ?: "") }
    var grade by remember { mutableStateOf(existing?.grade ?: "") }
    var className by remember { mutableStateOf(existing?.className ?: "") }
    var school by remember { mutableStateOf(existing?.school ?: if (educator) store.school(account.email) else "") }
    var contactName by remember { mutableStateOf(existing?.contactName ?: "") }
    var contactPhone by remember { mutableStateOf(existing?.contactPhone ?: "") }
    var notes by remember { mutableStateOf(existing?.notes ?: "") }
    var error by remember { mutableStateOf<String?>(null) }
    var confirmDelete by remember { mutableStateOf(false) }
    val noun = if (educator) "learner" else "child"
    var features by remember { mutableStateOf(existing?.features ?: ChildFeature.defaults) }
    var linkId by remember { mutableStateOf(existing?.linkId ?: "") }
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val cloud = remember { CloudStore(ctx) }
    val cloudOn = remember { cloud.enabled(account.email) }
    val activeLinks = remember { if (cloudOn) cloud.cachedLinks(account.email).filter { it.status == "active" } else emptyList() }
    var pairCode by remember { mutableStateOf<String?>(null) }
    var cloudMsg by remember { mutableStateOf<String?>(null) }
    var deviceCount by remember { mutableStateOf(existing?.let { cloud.deviceCount(account.email, it.id) } ?: 0) }

    fun save() {
        if (first.isBlank() || last.isBlank()) { error = "Enter first name and surname."; return }
        if (grade.isBlank()) { error = "Enter the grade, e.g. Grade 4."; return }
        if (educator && className.isBlank()) { error = "Enter the class, e.g. 4A."; return }
        val phone = if (contactPhone.isBlank()) "" else normalizeSaPhone(contactPhone)
            ?: run { error = "Contact number must be a South African number, e.g. 082 123 4567."; return }
        if (educator && school.isNotBlank()) store.setSchool(account.email, school)
        store.save(
            account.email,
            Child(
                id = existing?.id ?: store.newId(),
                firstName = first.trim(), lastName = last.trim(), grade = grade.trim(),
                className = className.trim(), school = school.trim(),
                contactName = contactName.trim(), contactPhone = phone, notes = notes.trim(),
                features = features, linkId = linkId
            )
        )
        if (linkId.isNotBlank() && cloudOn) CloudSync.syncInBackground(ctx, account)
        onDone()
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(t.canvas)
            .verticalScroll(rememberScrollState())
            .imePadding()
            .navigationBarsPadding()
    ) {
        ScreenHeader(if (existing == null) "Add $noun" else "Edit $noun", onDone)
        Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            AuthField(first, { first = it.take(40); error = null }, "First name", capitalize = true)
            AuthField(last, { last = it.take(40); error = null }, "Surname", capitalize = true)
            AuthField(grade, { grade = it.take(20); error = null }, "Grade (e.g. Grade 4)", capitalize = true)
            AuthField(
                className, { className = it.take(20); error = null },
                if (educator) "Class (e.g. 4A)" else "Class (optional)", capitalize = true
            )
            AuthField(school, { school = it.take(60); error = null }, "School", capitalize = true)
            Text(
                if (educator) "Parent or guardian" else "Emergency contact",
                color = t.ink, fontWeight = FontWeight.SemiBold, fontSize = 15.sp,
                modifier = Modifier.padding(top = 8.dp)
            )
            AuthField(contactName, { contactName = it.take(60); error = null }, "Contact name", capitalize = true)
            AuthField(contactPhone, { contactPhone = it; error = null }, "Contact number (South Africa)", KeyboardType.Phone)
            AuthField(
                notes, { notes = it.take(300); error = null },
                if (educator) "Notes (optional)" else "Allergies or notes (optional)",
                singleLine = false
            )
            Text(
                "Features for this ${noun}", color = t.ink, fontWeight = FontWeight.SemiBold, fontSize = 15.sp,
                modifier = Modifier.padding(top = 8.dp)
            )
            Text(
                "These apply on the child's phone once it is paired. Any linked parent or teacher can change them from their own phone.",
                color = t.inkSoft, fontSize = 12.sp
            )
            ChildFeature.available.filter { it.first != ChildFeature.LOCATION || account.role == Role.PARENT || BuildConfig.EDUCATOR_SEES_LOCATION }
                .forEach { (key, label, description) ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(label, color = t.ink, fontWeight = FontWeight.Medium)
                        Text(description, color = t.inkSoft, fontSize = 12.sp)
                    }
                    Switch(checked = key in features, onCheckedChange = { on -> features = if (on) features + key else features - key })
                }
            }

            if (cloudOn) {
                Text("Sharing", color = t.ink, fontWeight = FontWeight.SemiBold, fontSize = 15.sp, modifier = Modifier.padding(top = 8.dp))
                if (linkId.isBlank()) {
                    activeLinks.forEach { l ->
                        OutlinedButton(
                            onClick = { linkId = l.linkId },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(14.dp)
                        ) { Text("Share with ${l.partnerName} (${l.partnerRole})", color = t.primary) }
                    }
                    if (activeLinks.isEmpty()) {
                        Text("Link with a parent or teacher under Cloud link to share this ${noun}.", color = t.inkSoft, fontSize = 12.sp)
                    } else {
                        Text("Tap Save to share. You will both have equal rights to edit it.", color = t.inkSoft, fontSize = 12.sp)
                    }
                } else {
                    val partner = activeLinks.firstOrNull { it.linkId == linkId }
                    Text(
                        "🔗 Shared with ${partner?.partnerName ?: "your linked user"}. You both have equal rights to edit or remove this ${noun}.",
                        color = t.inkSoft, fontSize = 13.sp
                    )
                }
            }

            if (cloudOn && existing != null && existing.linkId.isNotBlank()) {
                Text("Child's phone", color = t.ink, fontWeight = FontWeight.SemiBold, fontSize = 15.sp, modifier = Modifier.padding(top = 8.dp))
                Text(
                    if (deviceCount > 0) "📱 $deviceCount phone(s) paired." else "No phone paired yet. Save any changes first, then pair.",
                    color = t.inkSoft, fontSize = 13.sp
                )
                Button(
                    onClick = {
                        scope.launch {
                            cloudMsg = null
                            try {
                                CloudSync.syncAll(ctx, account)
                                val client = CloudClient(cloud.url(account.email), cloud.token(account.email))
                                pairCode = withContext(Dispatchers.IO) {
                                    client.deviceCode(existing.linkId, existing.id)
                                }
                            } catch (e: CloudException) { cloudMsg = e.message }
                        }
                    },
                    modifier = Modifier.fillMaxWidth().height(48.dp),
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = t.primary, contentColor = if (t.dark) Color(0xFF04201F) else Color.White)
                ) { Text("Pair this child's phone", fontWeight = FontWeight.SemiBold) }
                if (deviceCount > 0) {
                    OutlinedButton(
                        onClick = {
                            scope.launch {
                                try {
                                    val client = CloudClient(cloud.url(account.email), cloud.token(account.email))
                                    withContext(Dispatchers.IO) { client.deviceRevoke(existing.linkId, existing.id) }
                                    deviceCount = 0
                                } catch (e: CloudException) { cloudMsg = e.message }
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp)
                    ) { Text("Unpair all phones", color = Danger) }
                }
                (if (account.role == Role.PARENT || BuildConfig.EDUCATOR_SEES_LOCATION) cloud.fix(account.email, existing.id) else null)?.let { fix ->
                    val whenText = remember(fix) { SimpleDateFormat("d MMM, HH:mm", Locale.getDefault()).format(Date(fix.time)) }
                    Text("📍 Last location: $whenText", color = t.inkSoft, fontSize = 13.sp)
                    Text(
                        "Open in Maps", color = t.primary, fontSize = 13.sp, fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.clickable {
                            ctx.startActivity(
                                Intent(Intent.ACTION_VIEW, Uri.parse("https://maps.google.com/?q=${fix.lat},${fix.lng}"))
                                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            )
                        }.padding(vertical = 4.dp)
                    )
                }
                cloudMsg?.let { Text(it, color = Danger, fontSize = 13.sp) }
            }

            error?.let { Text(it, color = Danger, fontSize = 13.sp) }
            Button(
                onClick = { save() },
                modifier = Modifier.fillMaxWidth().height(54.dp),
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = t.primary,
                    contentColor = if (t.dark) Color(0xFF04201F) else Color.White
                )
            ) { Text("Save", fontWeight = FontWeight.SemiBold) }
            if (existing != null) {
                OutlinedButton(
                    onClick = { confirmDelete = true },
                    modifier = Modifier.fillMaxWidth().height(52.dp),
                    shape = RoundedCornerShape(16.dp)
                ) { Text("Delete $noun", color = Danger, fontWeight = FontWeight.SemiBold) }
            }
            Text(
                "Saved only on this phone. Works offline.",
                color = t.inkSoft, fontSize = 12.sp, textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth()
            )
        }
    }

    pairCode?.let { code ->
        AlertDialog(
            onDismissRequest = { pairCode = null },
            containerColor = t.card,
            title = { Text("Pair the child's phone", color = t.ink) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("On the child's phone, install AmitySA, tap “Setting up a child's phone?” and paste this invite:", color = t.inkSoft, fontSize = 14.sp)
                    Text(makeInvite(code, cloud.url(account.email)), color = t.primary, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    Text("It works once and lasts 15 minutes. It contains no passwords.", color = t.inkSoft, fontSize = 12.sp)
                }
            },
            dismissButton = {
                TextButton(onClick = { shareText(ctx, makeInvite(code, cloud.url(account.email))) }) { Text("Share invite", color = t.primary) }
            },
            confirmButton = { TextButton(onClick = { pairCode = null; deviceCount = cloud.deviceCount(account.email, existing?.id ?: "") }) { Text("Done", color = t.primary) } }
        )
    }

    if (confirmDelete && existing != null) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            containerColor = t.card,
            title = { Text("Delete ${existing.fullName}?", color = t.ink) },
            text = { Text(if (existing.linkId.isNotBlank()) "This child is shared, so it will be removed for everyone on the link and any paired phone will be unpaired." else "This removes the record from this phone.", color = t.inkSoft) },
            confirmButton = {
                TextButton(onClick = {
                    store.delete(account.email, existing.id)
                    if (existing.linkId.isNotBlank() && cloudOn) CloudSync.syncInBackground(ctx, account)
                    onDone()
                }) {
                    Text("Delete", color = Danger, fontWeight = FontWeight.SemiBold)
                }
            },
            dismissButton = {
                TextButton(onClick = { confirmDelete = false }) { Text("Cancel", color = t.inkSoft) }
            }
        )
    }
}

package com.amitysa.app

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private const val AUTHENTICATORS =
    BiometricManager.Authenticators.BIOMETRIC_WEAK or BiometricManager.Authenticators.DEVICE_CREDENTIAL

internal fun canUseLock(ctx: Context): Boolean =
    BiometricManager.from(ctx).canAuthenticate(AUTHENTICATORS) == BiometricManager.BIOMETRIC_SUCCESS

/** Fingerprint / face, with the phone's PIN, pattern or password as the fallback. */
internal fun promptUnlock(activity: FragmentActivity, title: String, onSuccess: () -> Unit, onFail: (String) -> Unit) {
    val prompt = BiometricPrompt(
        activity,
        ContextCompat.getMainExecutor(activity),
        object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) { onSuccess() }
            override fun onAuthenticationError(errorCode: Int, errString: CharSequence) { onFail(errString.toString()) }
        }
    )
    val info = BiometricPrompt.PromptInfo.Builder()
        .setTitle(title)
        .setAllowedAuthenticators(AUTHENTICATORS)
        .build()
    prompt.authenticate(info)
}

// ---------- Lock screen ----------

@Composable
internal fun LockScreen(onUnlock: () -> Unit, onSos: () -> Unit, onTurnOffLock: () -> Unit) {
    val ctx = LocalContext.current
    val activity = ctx as? FragmentActivity
    val usable = remember { canUseLock(ctx) }
    var error by remember { mutableStateOf<String?>(null) }

    fun prompt() {
        if (activity != null) promptUnlock(activity, "Unlock AmitySA", onUnlock) { error = it }
    }
    LaunchedEffect(Unit) {
        delay(350)
        if (usable) prompt()
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(HeaderTop, HeaderBottom)))
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(28.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Image(
            painter = painterResource(R.drawable.amity_logo),
            contentDescription = "AmitySA logo",
            modifier = Modifier.fillMaxWidth(0.6f).widthIn(max = 280.dp)
        )
        Spacer(Modifier.height(20.dp))
        Text("AmitySA is locked", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(6.dp))
        if (usable) {
            Text("Use your fingerprint, face or phone PIN to continue.", color = Color.White.copy(alpha = 0.7f), textAlign = TextAlign.Center, fontSize = 14.sp)
            error?.let { Text(it, color = Gold, fontSize = 13.sp, textAlign = TextAlign.Center, modifier = Modifier.padding(top = 8.dp)) }
            Spacer(Modifier.height(20.dp))
            Button(
                onClick = { prompt() },
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Color(0xFF1A1405))
            ) { Text("Unlock", fontWeight = FontWeight.SemiBold) }
        } else {
            Text(
                "This phone no longer has a screen lock or fingerprint set up, so AmitySA can't check it's you.",
                color = Color.White.copy(alpha = 0.7f), textAlign = TextAlign.Center, fontSize = 14.sp
            )
            Spacer(Modifier.height(16.dp))
            Button(
                onClick = onTurnOffLock,
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Color(0xFF1A1405))
            ) { Text("Turn off app lock", fontWeight = FontWeight.SemiBold) }
        }
        Spacer(Modifier.height(36.dp))
        OutlinedButton(onClick = onSos, shape = RoundedCornerShape(16.dp)) {
            Text("🚨 Emergency SOS", color = Color.White, fontWeight = FontWeight.SemiBold)
        }
        Text("SOS works without unlocking.", color = Color.White.copy(alpha = 0.5f), fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
    }
}

// ---------- Voice SOS phrase (only while AmitySA is open on screen) ----------

@Composable
internal fun VoicePhraseListener(enabled: Boolean, phrase: String, onHeard: () -> Unit) {
    val ctx = LocalContext.current
    val currentOnHeard by rememberUpdatedState(onHeard)
    if (!enabled || phrase.isBlank()) return

    DisposableEffect(phrase) {
        val micOk = ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        if (!micOk || !SpeechRecognizer.isRecognitionAvailable(ctx)) return@DisposableEffect onDispose { }

        val handler = Handler(Looper.getMainLooper())
        val recognizer = SpeechRecognizer.createSpeechRecognizer(ctx)
        var active = true
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            .putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)

        fun listen() {
            if (!active) return
            try { recognizer.startListening(intent) } catch (e: Exception) { }
        }
        fun restart() {
            if (active) handler.postDelayed({ listen() }, 800)
        }
        fun check(bundle: Bundle?) {
            val heard = bundle?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION) ?: return
            if (active && heard.any { it.contains(phrase, ignoreCase = true) }) {
                active = false
                currentOnHeard()
            }
        }

        recognizer.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onError(error: Int) { restart() }
            override fun onResults(results: Bundle?) { check(results); restart() }
            override fun onPartialResults(partialResults: Bundle?) { check(partialResults) }
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        listen()

        onDispose {
            active = false
            handler.removeCallbacksAndMessages(null)
            try { recognizer.destroy() } catch (e: Exception) { }
        }
    }
}

// ---------- Security settings ----------

@Composable
internal fun SecurityScreen(account: Account, onBack: () -> Unit, onChanged: () -> Unit, onDeleted: () -> Unit) {
    val ctx = LocalContext.current
    val activity = ctx as? FragmentActivity
    val t = LocalAmity.current
    val sec = remember { SecurityStore(ctx) }
    val owner = account.email
    var lockOn by remember { mutableStateOf(sec.lockEnabled(owner)) }
    var voiceOn by remember { mutableStateOf(sec.voiceEnabled(owner)) }
    var phrase by remember { mutableStateOf(sec.phrase(owner)) }
    var message by remember { mutableStateOf<String?>(null) }
    var pendingVoice by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }
    var deleting by remember { mutableStateOf(false) }
    var forceLocal by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val cloudConnected = CloudStore(ctx).enabled(owner) && !forceLocal

    fun enableVoice() {
        sec.setVoice(owner, true, phrase)
        voiceOn = true
        onChanged()
    }
    val micLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted && pendingVoice) enableVoice()
        else if (!granted) message = "Microphone permission is needed for the voice phrase."
        pendingVoice = false
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(t.canvas)
            .verticalScroll(rememberScrollState())
            .imePadding()
            .navigationBarsPadding()
    ) {
        ScreenHeader("Security", onBack)
        Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {

            SecCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("App lock", color = t.ink, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                        Text(
                            "Ask for your fingerprint, face or phone PIN when AmitySA opens or after 30 seconds away. Protects children's details.",
                            color = t.inkSoft, fontSize = 13.sp
                        )
                    }
                    Switch(
                        checked = lockOn,
                        onCheckedChange = { wantOn ->
                            message = null
                            when {
                                activity == null -> message = "Can't show the lock prompt here."
                                !canUseLock(ctx) -> message = "Set up a fingerprint, face or screen lock in Android settings first."
                                else -> promptUnlock(
                                    activity,
                                    if (wantOn) "Confirm to turn on app lock" else "Confirm to turn off app lock",
                                    onSuccess = { sec.setLock(owner, wantOn); lockOn = wantOn; onChanged() },
                                    onFail = { message = it }
                                )
                            }
                        }
                    )
                }
            }

            SecCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Voice SOS phrase", color = t.ink, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                        Text(
                            "Say your phrase while AmitySA is open on screen and the SOS countdown starts. You can still cancel it.",
                            color = t.inkSoft, fontSize = 13.sp
                        )
                    }
                    Switch(
                        checked = voiceOn,
                        onCheckedChange = { wantOn ->
                            message = null
                            if (!wantOn) {
                                sec.setVoice(owner, false, phrase); voiceOn = false; onChanged()
                            } else if (phrase.trim().length < 6) {
                                message = "Choose a phrase of at least 6 characters, e.g. “help me amity”."
                            } else if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                                enableVoice()
                            } else {
                                pendingVoice = true
                                micLauncher.launch(Manifest.permission.RECORD_AUDIO)
                            }
                        }
                    )
                }
                AuthField(phrase, { phrase = it.take(40); message = null }, "Your SOS phrase")
                Text(
                    "Listening only happens while this app is open on screen, and uses your phone's own speech recognition. It is not a voiceprint, so anyone saying the phrase can trigger it.",
                    color = t.inkSoft, fontSize = 12.sp
                )
            }

            SecCard {
                Text("SOS shortcut", color = t.ink, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                Text(
                    "Press and hold the AmitySA icon on your home screen and tap “Send SOS”. You can drag that shortcut onto the home screen as its own button.",
                    color = t.inkSoft, fontSize = 13.sp
                )
            }

            SecCard {
                Text("Delete my account and data", color = t.ink, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                Text(
                    "Removes your account, children, zones and SOS contacts from this phone" +
                        (if (cloudConnected) ", and your shared details and links from the server. People you linked with keep their own copies of anything you shared" else "") +
                        ". This cannot be undone.",
                    color = t.inkSoft, fontSize = 13.sp
                )
                OutlinedButton(
                    onClick = { confirmDelete = true },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp)
                ) { Text("Delete my account", color = Danger, fontWeight = FontWeight.SemiBold) }
            }

            message?.let { Text(it, color = Danger, fontSize = 13.sp) }
        }
    }

    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            containerColor = t.card,
            title = { Text("Delete everything?", color = t.ink) },
            text = { Text("Your account and all its data will be erased. This cannot be undone.", color = t.inkSoft) },
            confirmButton = {
                TextButton(
                    enabled = !deleting,
                    onClick = {
                        deleting = true
                        scope.launch {
                            try {
                                if (cloudConnected) {
                                    val cloud = CloudStore(ctx)
                                    withContext(Dispatchers.IO) { CloudClient(cloud.url(owner), cloud.token(owner)).deleteAccount() }
                                }
                                wipeAccountOnPhone(ctx, owner)
                                onDeleted()
                            } catch (e: CloudException) {
                                message = (e.message ?: "Could not reach the server.") + " Connect to the internet and try again, or delete from this phone only."
                                forceLocal = true
                                confirmDelete = false
                            } finally { deleting = false }
                        }
                    }
                ) { Text(if (deleting) "Deleting…" else "Delete", color = Danger, fontWeight = FontWeight.SemiBold) }
            },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("Cancel", color = t.inkSoft) } }
        )
    }
}

@Composable
private fun SecCard(content: @Composable ColumnScope.() -> Unit) {
    val t = LocalAmity.current
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = t.card),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp), content = content)
    }
}

// ---------- Required disclosure before the volume-button hotkey can be switched on ----------

@Composable
internal fun HotkeyDisclosureDialog(onAgree: () -> Unit, onDismiss: () -> Unit) {
    val t = LocalAmity.current
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = t.card,
        title = { Text("Allow the SOS hotkey?", color = t.ink) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    "To start an SOS when you press Volume Down three times quickly, AmitySA needs to use Android's Accessibility service.",
                    color = t.inkSoft, fontSize = 14.sp
                )
                Text(
                    "What it accesses: only the Volume Down button presses, to count them. It does not read your screen, messages, passwords or other apps, and it collects no personal data.",
                    color = t.inkSoft, fontSize = 14.sp
                )
                Text(
                    "How it is used: only to start the SOS alert. Nothing from it is stored or shared. You can switch it off at any time in Android's Accessibility settings.",
                    color = t.inkSoft, fontSize = 14.sp
                )
            }
        },
        confirmButton = { TextButton(onClick = onAgree) { Text("I agree", color = t.primary, fontWeight = FontWeight.SemiBold) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("No thanks", color = t.inkSoft) } }
    )
}

// ---------- Delete my account and data ----------

/** Wipes everything this account has on this phone. */
internal fun wipeAccountOnPhone(ctx: Context, owner: String) {
    stopTracking(ctx, owner)
    ChildStore(ctx).deleteAll(owner)
    ZoneStore(ctx).deleteAll(owner)
    SosStore(ctx).deleteAll(owner)
    SecurityStore(ctx).deleteAll(owner)
    CloudStore(ctx).disconnect(owner)
    AccountStore(ctx).deleteAccount(owner)
}

# AmitySA test checklist

Tick each line on real phones. Most features use the phone's SMS, GPS and buttons, so they cannot be tested on a computer.
Use a spare contact number you control. Standard SMS charges apply.

**Phones you need:** Phone A (parent), Phone B (teacher), Phone C (spare, as the child's phone). Phone C can be an old phone.

## 1. Install and first run
- [ ] APK installs and opens (no crash).
- [ ] Launch popup shows the logo and the three taglines, and can be skipped by tapping.
- [ ] The app icon and splash show the new shield/handshake logo.
- [ ] Change theme (Midnight, Ocean, Sunrise, Forest, Auto). It is remembered after closing the app.

## 2. Accounts (airplane mode ON for this section)
- [ ] Create a parent account with a username, a South African number (try `082 123 4567`) and a password.
- [ ] A non-South-African number (`+44 7700 900123`) is refused.
- [ ] A weak password and a repeated username/email are refused.
- [ ] Sign out and sign in again with email and password.
- [ ] 5 wrong passwords lock sign-in for about 30 seconds.
- [ ] Offline banner shows; Cloud link says it needs a connection.

## 3. Children and learners
- [ ] Parent: add a child with grade, school and emergency contact. Edit it. Delete it (asks first).
- [ ] Educator account: set the school, add learners to classes (4A, 4B). They are grouped by class.
- [ ] A contact number that is not South African is refused.
- [ ] Add 30 or more children quickly. The list stays smooth to scroll.
- [ ] Close and reopen the app: everything is still there.

## 4. SOS
- [ ] SOS setup: add 2 contacts, tap Allow for SMS and location.
- [ ] Tap SOS: 5-second countdown, **Cancel** stops it and nothing is sent.
- [ ] Let it finish: both contacts get a text with a maps link. Police 10111 / 112 buttons open the dialer (do not dial).
- [ ] Switch on the hotkey in Accessibility. Press **Volume Down 3 times**:
  - [ ] Unlocked: the app opens with the countdown.
  - [ ] Screen locked: the text is sent straight away (check the contact's phone).
- [ ] Volume still works normally with 1 or 2 presses.
- [ ] Long-press the app icon, tap **Send SOS**: the countdown opens.
- [ ] Say your voice phrase with the app open: the countdown opens. Nothing happens when the app is closed.

## 5. Location and safe zones
- [ ] Start tracking (a notification stays visible). Save the current spot as "Home".
- [ ] Walk 300 m or more away: a "left Home" notification appears and your SOS contact gets a text.
- [ ] Return: "arrived at Home".
- [ ] Switch off the Text-my-contacts toggle on the zone: no text is sent next time.
- [ ] Stop tracking: the notification disappears. Recent activity on the home screen lists real events.

## 6. Security
- [ ] Turn on App lock (fingerprint, face or phone PIN). Close the app, wait 30 seconds, reopen: it asks to unlock.
- [ ] The lock screen's **Emergency SOS** button works without unlocking.
- [ ] Turn off the app lock (asks for authentication).

## 7. Linking (needs the backend running)
- [ ] Phone A: Cloud link, set up the server with address and access key. Create an invite and share it.
- [ ] Phone B (educator): paste the invite under Cloud link. It joins without asking for any server details.
- [ ] Both phones show each other's username and **no** email, password or phone number.
- [ ] A parent trying to join another parent's invite is refused. An invite works only once.
- [ ] Phone A shares a child. It appears on Phone B within a minute (or after Sync now).
- [ ] Phone B changes the class and a feature switch. Phone A sees both after syncing.
- [ ] Phone A deletes the child: it disappears on Phone B too.
- [ ] Notes/allergies typed on Phone A do **not** appear on Phone B.
- [ ] Remove the link from either phone: both phones keep their own children as private records.

## 8. Child phone (Phone C)
- [ ] Phone A: open a shared child, switch on SOS button and Share location, tap **Pair this child's phone**, share the invite.
- [ ] Phone C: "Setting up a child's phone?", paste the invite. It shows "Hi <name>".
- [ ] SOS button on Phone C texts the guardian number with a location link.
- [ ] Phone A and B show "Last location" for the child and Open in Maps works.
- [ ] Phone B turns **Share location** off: Phone C stops sharing within about 5 minutes (the notification goes away).
- [ ] Phone A taps **Unpair all phones**: Phone C returns to the sign-in screen within a minute.
- [ ] Unpairing from Phone C asks for the phone's own screen lock.

## 9. Offline behaviour
- [ ] With data off: accounts, children, SOS texts, zones and app lock still work.
- [ ] Reconnect: Sync now brings shared changes across.

## 10. Google Play build (install `amitysa-debug-apks`, the play one)
- [ ] The app asks for **location only**: no SMS permission prompt anywhere.
- [ ] SOS countdown finishes, then the phone's **messages app opens** with the alert and contacts already filled in. Tap Send.
- [ ] The "Open messages" button on the result screen reopens it.
- [ ] No hotkey card in SOS setup, no "SOS hotkey" switch on a child, and Accessibility does not list AmitySA.
- [ ] Safe zones show no "Text my SOS contacts" switch; arrivals only show a notification.
- [ ] On a **teacher** account the child's last location and the "Share location" switch are not shown; on a parent account they are.
- [ ] Pairing a child's phone shows the agreement box, and cannot continue until it is ticked.
- [ ] Security, **Delete my account**: wipes the phone; if connected, the server account is removed and a linked partner no longer sees the shared children.
- [ ] Direct build: turning on the hotkey first shows the "Allow the SOS hotkey?" explanation with I agree / No thanks.

## Known limits (not bugs)
- Safe-zone alerts and the voice phrase are for parent and teacher phones; child phones get SOS, hotkey and location sharing.
- The SOS location is the phone's last known position, so the text states how old it is.
- SMS delivery is not confirmed by the phone: the app can only confirm the text was handed to the network.
- The backend uses one shared access key to register the first phone; add per-user sign-in and backups before real use.
- Tracking and the hotkey need battery optimisation to be switched off for AmitySA on some brands (Xiaomi, Huawei, Samsung).

# Building and installing AmitySA

## 1. Put the project on GitHub
1. Create an empty repository named `amitysa`.
2. Upload the contents of the `amitysa` folder (keep `.github/workflows` and `server/`).
3. Open the **Actions** tab. Each push to `main` runs:
   - **server-test**: checks linking, shared children, features and child-phone pairing.
   - **debug-apk**: builds `amitysa-debug-apk`, which you can install straight away (see step 4).

If the build fails, open the failed step, copy the red error lines and send them to me.

## 2. Make a signed release APK (once)
A signed APK is what you give to other families and keep updating. You only create the key once, and you must
**keep it safe forever**: if you lose it you can never update an installed app, only replace it.

1. On any computer with Java installed, create the key:
   ```
   keytool -genkeypair -v -keystore amitysa.jks -alias amitysa -keyalg RSA -keysize 2048 -validity 10000
   ```
   Choose strong passwords and write them down somewhere safe. Back up `amitysa.jks` (not in GitHub).
2. Turn the key into text:
   - Mac/Linux: `base64 -w0 amitysa.jks`
   - Windows PowerShell: `[Convert]::ToBase64String([IO.File]::ReadAllBytes("amitysa.jks"))`
3. In GitHub: **Settings, Secrets and variables, Actions, New repository secret.** Add four secrets:
   | Name | Value |
   |---|---|
   | `KEYSTORE_BASE64` | the long text from step 2 |
   | `KEYSTORE_PASSWORD` | the keystore password |
   | `KEY_ALIAS` | `amitysa` (or the alias you chose) |
   | `KEY_PASSWORD` | the key password |
4. Build it: **Actions, Build AmitySA, Run workflow**, or push a tag: `git tag v0.8.0 && git push origin v0.8.0`.
   A tagged build also appears under **Releases** with the APK attached.

## 2b. The two builds
Every release makes two files:
- `AmitySA-direct-vX.apk`: install from a file. Texts SOS contacts by itself and has the Volume Down hotkey.
- `AmitySA-play-vX.aab`: the bundle you upload to Google Play (no SMS permission, no hotkey). See `docs/PLAY_STORE.md`.
Debug builds of both are made on every push (`amitysa-debug-apks`).

## 3. Optional: run the backend (only for parent-teacher linking)
See `server/README.md`. Without it, everything else still works on each phone.

## 4. Install on a phone
1. Download the APK from the run (**Artifacts**) or the Release page onto the phone.
2. Open it. Android asks you to allow installing from that app (browser or Files): allow it.
3. Open AmitySA, create your account, and allow SMS and location when asked.
4. To update later, install the newer APK over the old one. Your accounts and children are kept
   (they only survive updates when the same signing key is used, so always use the release APK once you start).

## Before real families use it
- Add a privacy notice and get consent for children's details (POPIA).
- Test everything in `docs/TEST_CHECKLIST.md` on real phones first, especially SOS.
- Put the backend on a host with a persistent disk and backups.
- Publishing on Google Play: read `docs/PLAY_STORE.md` first. It lists what Google requires, what the Play build leaves out and why, and how to fill in the Play Console forms.

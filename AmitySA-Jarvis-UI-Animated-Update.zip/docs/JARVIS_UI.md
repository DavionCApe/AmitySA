# AmitySA JARVIS UI layer

The shared JARVIS ambient visual layer is rendered on every main app route, including child/family, map, safe zones, check-in, SOS, security, cloud and home. It adds a low-contrast animated Earth-style sphere, rotating orbital tracks, a satellite marker, drifting signal stars and a soft atmospheric rim. The layer is visual-only and does not intercept touch input.

The home feature menu and in-page menu use the same left-side sliding JARVIS drawer. The drawer includes an animated mini-planet in its header and remains a platform modal window above the active page. The appearance chooser also opens in a full-window modal scrim.

Transient root-level popups (appearance and Google Maps chooser) are closed before navigation and when navigating back. Page-owned dialogs are disposed with their page when a different feature is selected, preventing stale popup windows from being left behind the next feature screen.

## Build and QA

Run `./gradlew assembleDirectDebug assemblePlayDebug` in the configured GitHub Actions/Android build environment. On a device, verify the ambient HUD on every route, menu slide-in from the left, modal dismissal, and that selecting a feature closes the old popup before the new page is shown.

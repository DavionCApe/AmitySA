# Publishing AmitySA on Google Play

Checked against Google's published rules in November 2026. Rules change, so read the linked Play Console help pages
before you submit. This is practical guidance, not legal advice.

## The two builds
| Build | For | Sends SOS | Hotkey | Location shown to |
|---|---|---|---|---|
| `direct` | APK you share yourself | Texts contacts by itself (works offline) | Yes (Volume Down x3) | Parents and teachers |
| `play` | Google Play (`.aab`) | Opens the phone's messages app with the alert written; the person taps Send | Not included | Parents only |

Why the Play build is different:
- **SMS.** Google restricts the SEND_SMS permission to default SMS apps and a short list of approved exceptions, which includes
  "physical safety/emergency alerts to send SMS". Exceptions are temporary and case-by-case, and "family or device locator" is on
  the not-allowed list. To avoid a rejection on day one, the Play build does not ask for SMS at all. You can apply for the
  emergency-alert exception later and switch it on.
- **Arrival/departure texts** are also off in the Play build (they look like a family locator, not an emergency).
- **Accessibility hotkey.** Apps that are not disability tools must show a separate in-app disclosure with a tap-to-agree button,
  and complete an Accessibility declaration with a video. The disclosure is built in (it appears in the direct build), but the Play
  build leaves the hotkey out so your first review is simpler. The service is removed from the Play build's manifest.
- **Teachers and location.** Google allows apps that monitor another person only if they are "exclusively designed and marketed for
  parents to monitor their children" (or for employers). AmitySA also has teachers, so the Play build shows a child's location to
  parents only. Describe the app as a **parent-led family safety app** with optional school partners, never as a school tracking tool.
  Expect closer review. The app already includes the `isMonitoringTool = child_monitoring` flag Google requires.

## Technical requirements (done in this version)
- Targets **Android 16 (API 36)**. New apps and updates have had to since 31 August 2026.
- Ships as an **Android App Bundle** (`bundlePlayRelease`), not an APK.
- In-app **Delete my account** (Security screen) removes the phone data and, if connected, the server data.
- No background-location permission is used. Location runs in a visible foreground notification.

## Before you create the Play listing
1. **Account type.** A *personal* Play developer account created after 13 November 2023 must run a **closed test with at least
   12 testers opted in for 14 continuous days** before it can apply for production. An *organisation* account (for example a
   registered company or school) does not. Plan about three weeks for a first launch on a personal account.
2. **Host two web pages** (GitHub Pages is free): `docs/privacy-policy.html` and `docs/account-deletion.html`. Fill in the
   `[square brackets]` first and have someone qualified check them against POPIA.
3. **Reviewer access.** The app needs an account to get in. In *App content, App access*, give reviewers a parent and a teacher
   login and the steps to create a link (or tell them linking is optional).

## Play Console answers (drafts to check)
**App content**
- *Target audience:* adults (parents and teachers). Do not select children under 13. A child's phone is paired by a parent or guardian.
  Re-read the Families policy and confirm you are comfortable with this answer.
- *Privacy policy:* the URL of `privacy-policy.html`.
- *Ads:* none. *Content rating:* answer the questionnaire honestly (no violence or user-generated public content).
- *Account deletion:* in-app path "Security, Delete my account"; web link `account-deletion.html`.
- *Foreground service permissions:* type **location**. Use: "While a parent turns on safe-zone tracking, or while a parent/guardian
  has switched on location sharing on a child's paired phone, a visible notification keeps the app able to detect arrivals and share the
  child's location with the parent."
- *Permissions declaration:* none needed for the Play build (no SMS, no call log, no accessibility service).

**Data safety (a draft; confirm against your real server)**
| Data | Collected (leaves the phone)? | Why | Shared with others? | Optional? |
|---|---|---|---|---|
| Child's name, grade, class, school | Only if a parent/teacher shares that child on a link | App functionality | Only with the linked parent/teacher | Yes |
| Guardian name and phone number | Only if shared on a link | App functionality (SOS contact) | Only with the linked adult | Yes |
| Username and a one-way hash of your email | Only if you use Cloud link | Linking | Only with the person you link with | Yes |
| Precise location | Only from a child's paired phone when location sharing is switched on | App functionality | Parent (and teacher only in the direct build) | Yes |
| Email, password (hashed), notes/allergies, SOS contacts, zones | **No**, they stay on the phone | | | |
- Data is encrypted in transit (HTTPS only). Users can request deletion (in-app and web page).
- You act as the data controller for your own server. If a school or other party runs it, they share that role.

**Store listing text (starting point)**
- *Short (80 chars):* "Parent-led child safety: SOS alerts, safe zones and optional teacher link."
- *Full:* describe what each feature does, that location is only shared from a paired child phone when a parent switches it on, that a
  notification is always visible while it is on, that the app is for parents and guardians, and that SOS needs the phone's messages app
  and a signal. Do not promise that it "keeps children safe"; say it helps.
- Screenshots: home, SOS countdown, Children list, child's features, Security, Cloud link (no real children's details).

## Release path
1. Create the app in Play Console and upload `AmitySA-play-vX.Y.Z.aab` (from the GitHub release) to **Internal testing**. Turn on Play App Signing and keep your upload key safe.
2. Personal account: run **Closed testing** with 12 or more testers for 14 days (testers must really use the app), then apply for production.
3. Production review usually takes a few days; monitoring and permission-sensitive apps can take longer.
4. Every update needs a higher version code. The GitHub run number already provides this.

## Useful Google pages
- Target API level requirements: https://support.google.com/googleplay/android-developer/answer/11926878
- SMS and Call Log permissions: https://support.google.com/googleplay/android-developer/answer/10208820
- AccessibilityService API: https://support.google.com/googleplay/android-developer/answer/10964491
- isMonitoringTool flag: https://support.google.com/googleplay/android-developer/answer/12955211
- Testing requirements for new personal accounts: https://support.google.com/googleplay/android-developer/answer/14151465

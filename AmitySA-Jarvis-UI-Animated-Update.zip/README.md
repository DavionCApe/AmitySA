# AmitySA

Child-safety app for parents and teachers (Android, Kotlin + Jetpack Compose).

- `app/`: the Android app. Works fully on its own, offline.
- `server/`: optional backend for linking a parent and a teacher. Includes `smoke-test.js`.
- `docs/PLAY_STORE.md`: Google Play requirements, the Play build, and Play Console answers.
- `docs/privacy-policy.html`, `docs/account-deletion.html`: templates to host and fill in.
- `docs/DEPLOY.md`: build, sign and install the APK.
- `docs/TEST_CHECKLIST.md`: what to test on real phones.
- `.github/workflows/android.yml`: tests the server, builds the debug APK, and builds a signed release APK on a `v*` tag.


## Family live map

The parent/educator app includes an in-app OpenStreetMap view. It displays linked children's last shared GPS positions when the child's **Share location** feature is enabled, the current phone's last recorded position when safe-zone monitoring is active, and saved safe zones with their configured radius. The screen refreshes cloud location data every 30 seconds while open. Map tiles require internet access; location sharing requires an active HTTPS AmitySA cloud link and the relevant device permissions. The map labels the age of each location and does not present stale positions as live.


## Family map, check-ins and alerts (0.9.1)

- The Family live map now uses the native Google Maps SDK: 2D, satellite, terrain, hybrid, 3D camera tilt/buildings, child/parent markers, safe-zone radius circles and embedded Street View where imagery exists.
- Set the `MAPS_API_KEY` environment variable before building, or replace the placeholder in the Gradle manifest placeholder. Create a Google Maps Platform project, enable Maps SDK for Android and Street View, enable billing, and restrict the key to this Android package and signing certificate. Google Maps Platform usage is billed by its current SKU/pricing rules; set quota limits and budget alerts.
- Family check-ins are shared with adults on the same active cloud link. Supported statuses: I'm safe, arrived, need pickup, and need help. The server retains the latest 100 check-ins per link and deletes them when the link is revoked.
- Safe-zone entry/exit notifications are evaluated for newly synced child positions while the Family live map is open. Existing on-device safe-zone monitoring remains active for the phone being monitored. Background/closed-app push delivery is not enabled yet.
- Instant SOS push notifications still require a Firebase project, `google-services.json`, FCM server credentials and deployment configuration. Existing direct SMS SOS behaviour is unchanged. Do not describe push alerts as active until Firebase credentials and end-to-end delivery have been configured and tested.

### Required setup before testing the Google map

1. In Google Cloud Console create/select a project and enable Maps SDK for Android and Street View.
2. Enable billing and set strict daily quotas/budget alerts.
3. Create an Android-restricted API key for package `com.amitysa.app`; include the SHA-1 fingerprint for the signing key used to build the APK.
4. Set `MAPS_API_KEY` in the environment used by Gradle, then sync and run the app. Never commit a production API key.


## Free offline family maps

The Family live map now has an **Online maps / Free offline maps** switch. Offline mode uses the open-source osmdroid renderer and reads a raster MBTiles package stored privately in the app's internal storage. It does not download tiles automatically and does not use Google's tile servers.

1. Obtain a raster `.mbtiles` map package from a provider that permits offline use. For South Africa, [OpenAndroMaps' free general maps page](https://www.openandromaps.org/en/downloads/general-maps) offers an Africa MBTiles package (the ZL 11 package is listed at about 1.3 GB). Check the current file size, licence, attribution requirements and available detail before downloading. The larger Africa ZL 12 package is listed at about 4.3 GB.
2. On the phone, open **Family live map → Free offline maps → Import offline map** and select the downloaded `.mbtiles` file.
3. Once imported, the map can display its stored map area without mobile data or Wi-Fi. You can replace or remove the package from the same screen. The app copies the file into private storage, so make sure the phone has enough free space.

OpenStreetMap-derived map packages must show the required OpenStreetMap attribution. The offline map is a static map package: it does not include Google Street View, live satellite imagery, live traffic, or live routing. Family GPS positions and safe-zone overlays are shown when available; syncing new family positions still requires an internet connection. The package covers only the geographic area and zoom levels included by its provider.


## Startup, signup and guest preview

- After the Android splash/loading screen completes, a new or signed-out user is taken directly to the registration screen (with sign-in available as a tab).
- A floating **Skip signup for now · Preview app** button stays at the bottom of the signup/sign-in screen.
- The preview is a scrollable, read-only tour of the app's features. It uses descriptions/sample information only and does not expose live family data, trigger SOS alerts, or enable protected actions.
- Visitors must create an account or sign in before entering the working app features.

## Public welcome and feature preview

On a fresh install, people can browse a public AmitySA feature overview before signing in or registering. The preview describes SOS, family maps, safe zones, check-ins, family profiles and privacy features without exposing real family data or enabling account-protected functionality. Users must create an account or sign in to enter the main app. The welcome screen's create-account and sign-in buttons open the corresponding authentication mode.

### Open Google Maps
The signed-in home screen includes a Google Maps shortcut. Selecting it asks the user whether to open the installed Google Maps Android app or open Google Maps in the device's web browser. Both choices open Google's Maps service without an AmitySA subscription. Internet/mobile data may be required; Google Maps app availability and some features depend on the device and region.

## Welcome-focused home screen update
- Reworked the signed-in home screen into a scrollable welcome and information experience.
- Moved app navigation and feature access into the top MENU dropdown, including family profiles, family map, Google Maps, safe zones, check-ins, SOS, contacts, security, cloud sync, appearance and sign-out.
- Added a native animated family-safety hero illustration and rotating animated feature information cards.
- Removed the visible quick-action grid and large SOS shortcut from the home screen so features remain inside the menu.
- The animated artwork is rendered locally by Compose; it does not stream external video or use family/location data.

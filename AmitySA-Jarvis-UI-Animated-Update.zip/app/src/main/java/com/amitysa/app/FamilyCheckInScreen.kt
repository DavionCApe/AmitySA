package com.amitysa.app

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.platform.LocalContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
internal fun FamilyCheckInScreen(account: Account, onBack: () -> Unit) {
    val context = LocalContext.current
    val cloud = remember { CloudStore(context) }
    val scope = rememberCoroutineScope()
    var linkId by remember { mutableStateOf("") }
    var events by remember { mutableStateOf(emptyList<FamilyCheckIn>()) }
    var note by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("Connect Cloud link to share check-ins with linked family adults.") }
    var busy by remember { mutableStateOf(false) }

    suspend fun load() {
        if (!cloud.enabled(account.email)) return
        try {
            val data = withContext(Dispatchers.IO) {
                val client = CloudClient(cloud.url(account.email), cloud.token(account.email))
                client.links().firstOrNull { it.status == "active" }?.let { it.linkId to client.checkIns(it.linkId) }
            }
            if (data != null) { linkId = data.first; events = data.second; status = "Shared with linked family adults." }
            else status = "No active family link yet. Connect another adult in Cloud link settings."
        } catch (e: Exception) { status = e.message ?: "Could not load family check-ins." }
    }

    LaunchedEffect(account.email) { load() }

    fun send(code: String) {
        scope.launch {
            busy = true
            try {
                withContext(Dispatchers.IO) {
                    CloudClient(cloud.url(account.email), cloud.token(account.email)).createCheckIn(linkId, code, note)
                }
                note = ""
                status = "Check-in sent successfully."
                load()
            } catch (e: Exception) { status = e.message ?: "Check-in could not be sent." }
            finally { busy = false }
        }
    }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            TextButton(onClick = onBack) { Text("‹ Back") }
            Text("Family check-in", style = MaterialTheme.typography.titleLarge)
            TextButton(enabled = !busy, onClick = { scope.launch { load() } }) { Text("Refresh") }
        }
        Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Send a quick family update", style = MaterialTheme.typography.titleMedium)
                Text(status, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                OutlinedTextField(value = note, onValueChange = { note = it.take(180) }, label = { Text("Optional note") },
                    placeholder = { Text("e.g. At the school gate") }, modifier = Modifier.fillMaxWidth(), minLines = 1, maxLines = 3)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(enabled = !busy && linkId.isNotBlank(), onClick = { send("SAFE") }, modifier = Modifier.weight(1f)) { Text("I'm safe") }
                    OutlinedButton(enabled = !busy && linkId.isNotBlank(), onClick = { send("ARRIVED") }, modifier = Modifier.weight(1f)) { Text("Arrived") }
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(enabled = !busy && linkId.isNotBlank(), onClick = { send("PICKUP") }, modifier = Modifier.weight(1f)) { Text("Need pickup") }
                    OutlinedButton(enabled = !busy && linkId.isNotBlank(), onClick = { send("HELP") }, modifier = Modifier.weight(1f)) { Text("Need help") }
                }
            }
        }
        Spacer(Modifier.height(14.dp))
        Text("Recent family updates", style = MaterialTheme.typography.titleMedium)
        if (events.isEmpty()) Text("No check-ins yet.", Modifier.padding(top = 12.dp), color = MaterialTheme.colorScheme.onSurfaceVariant)
        LazyColumn(contentPadding = PaddingValues(vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(events, key = { it.id }) { event ->
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp)) {
                        Text("${event.by} · ${event.status.replace('_', ' ')}", style = MaterialTheme.typography.titleSmall)
                        if (event.note.isNotBlank()) Text(event.note, style = MaterialTheme.typography.bodyMedium)
                        Text(SimpleDateFormat("EEE, dd MMM · HH:mm", Locale.getDefault()).format(Date(event.time)),
                            style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
    }

}

package com.amitysa.app

import android.os.Bundle
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import android.net.Uri
import java.io.File
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.StreetViewPanoramaOptions
import com.google.android.gms.maps.StreetViewPanoramaView
import com.google.android.gms.maps.model.CameraPosition
import com.google.android.gms.maps.model.LatLng
import com.google.maps.android.compose.Circle
import com.google.maps.android.compose.GoogleMap
import com.google.maps.android.compose.MapProperties
import com.google.maps.android.compose.MapType
import com.google.maps.android.compose.MapUiSettings
import com.google.maps.android.compose.Marker
import com.google.maps.android.compose.MarkerState
import com.google.maps.android.compose.rememberCameraPositionState
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

internal data class FamilyMapPoint(
    val name: String, val lat: Double, val lng: Double, val time: Long,
    val kind: String, val radiusM: Int = 0
)

@Composable
internal fun FamilyMapScreen(account: Account, onBack: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val childStore = remember { ChildStore(context) }
    val cloudStore = remember { CloudStore(context) }
    val zoneStore = remember { ZoneStore(context) }
    var refreshRequest by remember { mutableIntStateOf(0) }
    var status by remember { mutableStateOf("Loading family locations…") }
    var points by remember { mutableStateOf(emptyList<FamilyMapPoint>()) }
    var mapType by remember { mutableIntStateOf(MapType.NORMAL) }
    var is3d by remember { mutableStateOf(false) }
    var streetView by remember { mutableStateOf(false) }
    var selected by remember { mutableStateOf<FamilyMapPoint?>(null) }
    var centeredOnFamily by remember { mutableStateOf(false) }
    var offlineMode by remember { mutableStateOf(false) }
    var offlineMapFile by remember { mutableStateOf<File?>(null) }
    var offlineMapMessage by remember { mutableStateOf("No offline map imported yet.") }
    val offlineDirectory = remember { File(context.filesDir, "offline_maps").apply { mkdirs() } }
    val mapPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            try {
                val target = File(offlineDirectory, "offline-map-${System.currentTimeMillis()}.mbtiles")
                context.contentResolver.openInputStream(uri)?.use { input ->
                    target.outputStream().use { output -> input.copyTo(output) }
                } ?: error("Could not open selected file")
                val header = target.inputStream().use { input -> ByteArray(16).also { input.read(it) } }
                val sqliteHeader = "SQLite format 3\u0000".toByteArray(Charsets.US_ASCII)
                if (!header.contentEquals(sqliteHeader)) {
                    target.delete()
                    error("This is not an MBTiles SQLite map. Please choose a .mbtiles file.")
                }
                offlineMapFile = target
                offlineMapMessage = "Offline map imported · ${(target.length() / (1024 * 1024)).coerceAtLeast(1)} MB"
            } catch (e: Exception) {
                offlineMapMessage = "Import failed: ${e.message ?: "Please select an MBTiles file."}"
            }
        }
    }
    LaunchedEffect(Unit) {
        val saved = context.getSharedPreferences("amity_offline_maps", android.content.Context.MODE_PRIVATE)
            .getString("active_map", null)
        if (saved != null) {
            val file = File(saved)
            if (file.exists()) {
                offlineMapFile = file
                offlineMapMessage = "Offline map ready · ${(file.length() / (1024 * 1024)).coerceAtLeast(1)} MB"
            }
        }
    }
    LaunchedEffect(offlineMapFile) {
        offlineMapFile?.let { file ->
            context.getSharedPreferences("amity_offline_maps", android.content.Context.MODE_PRIVATE)
                .edit().putString("active_map", file.absolutePath).apply()
        }
    }
    val initial = points.firstOrNull() ?: FamilyMapPoint("Cape Town", -33.9249, 18.4241, 0L, "parent")
    val camera = rememberCameraPositionState {
        position = CameraPosition.fromLatLngZoom(LatLng(initial.lat, initial.lng), 11f)
    }

    fun readPoints(): List<FamilyMapPoint> {
        val children = childStore.list(account.email)
        val childPoints = children.filter { it.features.contains(ChildFeature.LOCATION) && it.linkId.isNotBlank() }
            .mapNotNull { child -> cloudStore.fix(account.email, child.id)?.let { fix ->
                FamilyMapPoint(child.fullName.ifBlank { "Child" }, fix.lat, fix.lng, fix.time, "child")
            } }
        val zonePoints = zoneStore.zones(account.email).map {
            FamilyMapPoint(it.name, it.lat, it.lng, 0L, "zone", it.radiusM)
        }
        val own = zoneStore.lastFix(account.email)?.let { listOf(FamilyMapPoint("This phone", it.lat, it.lng, it.time, "parent")) } ?: emptyList()
        return childPoints + own + zonePoints
    }

    LaunchedEffect(points) {
        val firstFamilyPoint = points.firstOrNull { it.kind != "zone" }
        if (!centeredOnFamily && firstFamilyPoint != null) {
            camera.animate(CameraUpdateFactory.newLatLngZoom(LatLng(firstFamilyPoint.lat, firstFamilyPoint.lng), 14f))
            centeredOnFamily = true
        }
    }

    LaunchedEffect(account.email, refreshRequest) {
        while (true) {
            status = if (cloudStore.enabled(account.email)) "Updating shared locations…" else
                "Connect Cloud link and enable Share location on a child's profile to see their location."
            if (cloudStore.enabled(account.email)) {
                try {
                    CloudSync.syncAll(context.applicationContext, account)
                    childStore.list(account.email)
                        .filter { it.features.contains(ChildFeature.LOCATION) && it.linkId.isNotBlank() }
                        .forEach { child -> cloudStore.fix(account.email, child.id)?.let { fix ->
                            ZoneMonitor.processRemote(context.applicationContext, account, child.id, child.fullName.ifBlank { "Child" }, fix)
                        } }
                    status = "Family locations updated · automatic refresh every 30 seconds"
                } catch (e: Exception) {
                    status = "Showing saved locations · ${e.message ?: "Sync unavailable"}"
                }
            }
            points = readPoints()
            delay(30_000L)
        }
    }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp), horizontalArrangement = Arrangement.SpaceBetween) {
            TextButton(onClick = onBack) { Text("‹ Back") }
            Text("Family live map", style = MaterialTheme.typography.titleLarge)
            TextButton(onClick = { refreshRequest++ }) { Text("Refresh") }
        }
        Card(Modifier.fillMaxWidth().padding(horizontal = 12.dp), shape = RoundedCornerShape(14.dp)) {
            Column(Modifier.padding(10.dp)) {
                Text(status, style = MaterialTheme.typography.bodySmall)
                Text("Child sharing is controlled by each child's Share location setting.", style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = !offlineMode, onClick = { offlineMode = false }, label = { Text("Online maps") })
            FilterChip(selected = offlineMode, onClick = { offlineMode = true }, label = { Text("Free offline maps") })
        }
        if (offlineMode) {
            Column(Modifier.fillMaxWidth().padding(horizontal = 12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(offlineMapMessage, style = MaterialTheme.typography.bodySmall)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { mapPicker.launch(arrayOf("application/octet-stream", "application/x-sqlite3", "application/vnd.sqlite3", "*/*")) }) {
                        Text(if (offlineMapFile == null) "Import offline map" else "Replace map")
                    }
                    if (offlineMapFile != null) {
                        TextButton(onClick = {
                            offlineMapFile?.delete()
                            offlineMapFile = null
                            offlineMapMessage = "Offline map removed. Import an MBTiles package to use offline maps."
                            context.getSharedPreferences("amity_offline_maps", android.content.Context.MODE_PRIVATE)
                                .edit().remove("active_map").apply()
                        }) { Text("Remove") }
                    }
                }
                Text("Choose a legally obtained .mbtiles map package for your area. Map tiles are stored privately on this phone.",
                    style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        if (!offlineMode) {
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 10.dp, vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            FilterChip(selected = mapType == MapType.NORMAL, onClick = { mapType = MapType.NORMAL; streetView = false }, label = { Text("2D map") })
            FilterChip(selected = mapType == MapType.SATELLITE, onClick = { mapType = MapType.SATELLITE; streetView = false }, label = { Text("Satellite") })
            FilterChip(selected = mapType == MapType.TERRAIN, onClick = { mapType = MapType.TERRAIN; streetView = false }, label = { Text("Terrain") })
            FilterChip(selected = mapType == MapType.HYBRID, onClick = { mapType = MapType.HYBRID; streetView = false }, label = { Text("Hybrid") })
            FilterChip(selected = is3d && !streetView, onClick = {
                streetView = false
                val enable3d = !is3d
                is3d = enable3d
                scope.launch { camera.animate(CameraUpdateFactory.newCameraPosition(CameraPosition(camera.position.target, 17f, if (enable3d) 60f else 0f, camera.position.bearing))) }
            }, label = { Text(if (is3d) "3D on" else "3D view") })
            FilterChip(selected = streetView, onClick = { selected = points.firstOrNull { it.kind != "zone" } ?: points.firstOrNull(); streetView = selected != null }, label = { Text("Street View") })
        }
        }
        if (offlineMode) {
            if (offlineMapFile != null) {
                OfflineFamilyMapView(
                    mapFile = offlineMapFile!!,
                    points = points,
                    modifier = Modifier.fillMaxWidth().weight(1f).padding(horizontal = 8.dp)
                )
            } else {
                Box(Modifier.fillMaxWidth().weight(1f).padding(24.dp), contentAlignment = androidx.compose.ui.Alignment.Center) {
                    Text("No offline map installed. Import a free MBTiles map package to view streets without mobile data or Wi-Fi.",
                        style = MaterialTheme.typography.bodyMedium)
                }
            }
        } else if (streetView && selected != null) {
            StreetViewPanel(selected!!.lat, selected!!.lng, Modifier.fillMaxWidth().weight(1f))
            TextButton(onClick = { streetView = false }) { Text("Back to map") }
        } else {
            GoogleMap(
                modifier = Modifier.fillMaxWidth().weight(1f).padding(horizontal = 8.dp),
                cameraPositionState = camera,
                properties = MapProperties(mapType = mapType, isBuildingEnabled = true, isTrafficEnabled = false),
                uiSettings = MapUiSettings(zoomControlsEnabled = true, compassEnabled = true, myLocationButtonEnabled = false)
            ) {
                points.forEach { point ->
                    val pos = LatLng(point.lat, point.lng)
                    if (point.kind == "zone") {
                        Circle(center = pos, radius = point.radiusM.toDouble(), strokeWidth = 3f,
                            strokeColor = androidx.compose.ui.graphics.Color(0xFFD99A27),
                            fillColor = androidx.compose.ui.graphics.Color(0x33D99A27))
                    }
                    Marker(state = MarkerState(pos), title = point.name,
                        snippet = if (point.time > 0L) "Updated ${ageLabel(point.time)}" else if (point.kind == "zone") "Safe zone · ${point.radiusM} m radius" else "Family device")
                }
            }
        }
        Text(if (offlineMode) "Offline map package · © OpenStreetMap contributors where applicable. Live family locations still need GPS and occasional internet sync; offline maps do not provide Street View or live satellite imagery."
            else "Google Maps · Map detail and Street View coverage vary by location. Internet and a configured API key are required.",
            Modifier.fillMaxWidth().padding(10.dp), style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun StreetViewPanel(lat: Double, lng: Double, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val view = remember { StreetViewPanoramaView(context, StreetViewPanoramaOptions().position(LatLng(lat, lng))) }
    DisposableEffect(lifecycleOwner, view) {
        view.onCreate(Bundle())
        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_RESUME -> view.onResume()
                Lifecycle.Event.ON_PAUSE -> view.onPause()
                else -> Unit
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer); view.onDestroy() }
    }
    AndroidView(factory = { view }, modifier = modifier)
}

internal fun ageLabel(time: Long): String {
    val mins = ((System.currentTimeMillis() - time).coerceAtLeast(0L) / 60_000L)
    return when { mins < 1 -> "just now"; mins < 60 -> "$mins min ago"; mins < 1440 -> "${mins / 60} hr ago"; else -> SimpleDateFormat("dd MMM, HH:mm", Locale.getDefault()).format(Date(time)) }
}

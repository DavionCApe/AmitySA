package com.amitysa.app

import android.content.Context
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.Date

/** Keeps shared children, their features and last-known locations in step between linked parents and teachers. */
object CloudSync {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    suspend fun syncAll(ctx: Context, account: Account): String = withContext(Dispatchers.IO) {
        val cloud = CloudStore(ctx)
        val store = ChildStore(ctx)
        val owner = account.email
        if (!cloud.enabled(owner)) throw CloudException("Cloud link is not connected.")
        val client = CloudClient(cloud.url(owner), cloud.token(owner))

        val links = client.links()
        cloud.setCachedLinks(owner, links)
        val active = links.filter { it.status == "active" }
        store.unlinkMissing(owner, active.map { it.linkId }.toSet())

        val fixes = mutableMapOf<String, Fix>()
        val devices = mutableMapOf<String, Int>()
        active.forEach { link ->
            val mine = store.list(owner).filter { it.linkId == link.linkId }
            val tombs = store.tombstones(owner, link.linkId)
            val result = client.syncChildren(link.linkId, mine, tombs)
            store.clearTombstones(owner, tombs.map { it.first }.toSet())
            store.mergeRemote(owner, link.linkId, result.children, result.deleted)
            fixes.putAll(result.fixes)
            devices.putAll(result.devices)
        }
        cloud.setFixes(owner, fixes)
        cloud.setDevices(owner, devices)
        "Synced at " + SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
    }

    /** Best-effort sync that never blocks or crashes the screen; errors are simply retried next time. */
    fun syncInBackground(ctx: Context, account: Account) {
        val app = ctx.applicationContext
        scope.launch { try { syncAll(app, account) } catch (e: Exception) { } }
    }
}

package com.amitysa.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

/** Per-child features that a linked parent or teacher can switch on or off. They apply on the child's paired phone. */
object ChildFeature {
    const val SOS = "sos"
    const val HOTKEY = "hotkey"
    const val LOCATION = "location"

    val all = listOf(
        Triple(SOS, "SOS button", "A big SOS button that texts the guardian contact with the child's location."),
        Triple(HOTKEY, "SOS hotkey", "Pressing Volume Down 3 times quickly starts an SOS alert."),
        Triple(LOCATION, "Share location", "The child's phone shares its location with the linked parent and teacher.")
    )
    val defaults: Set<String> = setOf(SOS, HOTKEY)

    /** Features this build can actually offer. */
    val available get() = all.filter { it.first != HOTKEY || BuildConfig.HOTKEY }
}

/** A child (parent accounts) or a learner (educator accounts). When linkId is set, linked adults edit the same record. */
data class Child(
    val id: String,
    val firstName: String,
    val lastName: String,
    val grade: String,
    val className: String,
    val school: String,
    val contactName: String,
    val contactPhone: String,
    val notes: String,
    val features: Set<String> = ChildFeature.defaults,
    val updatedAt: Long = 0L,
    val linkId: String = ""
) {
    val fullName get() = "$firstName $lastName".trim()
}

/** Child and learner records are saved on this phone (works offline) and synced only when a link exists. */
class ChildStore(context: Context) {
    private val prefs = context.getSharedPreferences("amity_children", Context.MODE_PRIVATE)

    /** Erases everything saved for this account on this phone. */
    fun deleteAll(owner: String) {
        val editor = prefs.edit()
        prefs.all.keys.filter { it.endsWith("_$owner") }.forEach { editor.remove(it) }
        editor.apply()
    }

    fun newId(): String = UUID.randomUUID().toString()

    fun list(owner: String): List<Child> {
        val arr = JSONArray(prefs.getString("children_$owner", "[]"))
        return (0 until arr.length()).map { arr.getJSONObject(it).toChild() }
            .sortedWith(compareBy({ it.lastName.lowercase() }, { it.firstName.lowercase() }))
    }

    fun find(owner: String, id: String): Child? = list(owner).firstOrNull { it.id == id }

    /** Save an edit made on this phone: stamps the time so the newest edit wins when syncing. */
    fun save(owner: String, child: Child) = saveRaw(owner, child.copy(updatedAt = System.currentTimeMillis()))

    fun saveRaw(owner: String, child: Child) {
        write(owner, list(owner).filter { it.id != child.id } + child)
    }

    fun delete(owner: String, id: String) {
        val child = find(owner, id)
        if (child != null && child.linkId.isNotBlank()) addTombstone(owner, id, child.linkId)
        write(owner, list(owner).filter { it.id != id })
    }

    /** Share every child that isn't shared yet with this link. Returns how many were added. */
    fun shareAll(owner: String, linkId: String): Int {
        val now = System.currentTimeMillis()
        val all = list(owner)
        val toShare = all.filter { it.linkId.isBlank() }
        write(owner, all.map { if (it.linkId.isBlank()) it.copy(linkId = linkId, updatedAt = now) else it })
        return toShare.size
    }

    /** If a link no longer exists, its children stay on this phone as private records. */
    fun unlinkMissing(owner: String, activeLinkIds: Set<String>) {
        val all = list(owner)
        if (all.none { it.linkId.isNotBlank() && it.linkId !in activeLinkIds }) return
        write(owner, all.map { if (it.linkId.isNotBlank() && it.linkId !in activeLinkIds) it.copy(linkId = "") else it })
    }

    fun tombstones(owner: String, linkId: String): List<Pair<String, Long>> {
        val arr = JSONArray(prefs.getString("tomb_$owner", "[]"))
        return (0 until arr.length()).map { arr.getJSONObject(it) }
            .filter { it.getString("linkId") == linkId }.map { it.getString("id") to it.getLong("t") }
    }

    fun clearTombstones(owner: String, ids: Set<String>) {
        if (ids.isEmpty()) return
        val arr = JSONArray(prefs.getString("tomb_$owner", "[]"))
        val keep = JSONArray()
        (0 until arr.length()).map { arr.getJSONObject(it) }.filter { it.getString("id") !in ids }.forEach { keep.put(it) }
        prefs.edit().putString("tomb_$owner", keep.toString()).apply()
    }

    /** Applies what the server has: the newest edit wins, and deletions made by the other adult remove the child here too. */
    fun mergeRemote(owner: String, linkId: String, remote: List<Child>, deleted: List<Pair<String, Long>>) {
        val local = list(owner).associateBy { it.id }.toMutableMap()
        remote.forEach { r ->
            val l = local[r.id]
            if (l == null || r.updatedAt > l.updatedAt) local[r.id] = r.copy(linkId = linkId, notes = l?.notes ?: "")
        }
        deleted.forEach { (id, time) ->
            val l = local[id]
            if (l != null && l.linkId == linkId && time >= l.updatedAt) local.remove(id)
        }
        write(owner, local.values.toList())
    }

    private fun addTombstone(owner: String, id: String, linkId: String) {
        val arr = JSONArray(prefs.getString("tomb_$owner", "[]"))
        arr.put(JSONObject().put("id", id).put("linkId", linkId).put("t", System.currentTimeMillis()))
        prefs.edit().putString("tomb_$owner", arr.toString()).apply()
    }

    private fun write(owner: String, children: List<Child>) {
        val arr = JSONArray()
        children.forEach { arr.put(it.toJson()) }
        prefs.edit().putString("children_$owner", arr.toString()).apply()
    }

    private fun Child.toJson() = JSONObject()
        .put("id", id).put("firstName", firstName).put("lastName", lastName)
        .put("grade", grade).put("className", className).put("school", school)
        .put("contactName", contactName).put("contactPhone", contactPhone).put("notes", notes)
        .put("features", JSONArray(features.toList())).put("updatedAt", updatedAt).put("linkId", linkId)

    private fun JSONObject.toChild() = Child(
        getString("id"), optString("firstName"), optString("lastName"), optString("grade"),
        optString("className"), optString("school"), optString("contactName"),
        optString("contactPhone"), optString("notes"),
        features = optJSONArray("features")?.let { a -> (0 until a.length()).map { a.getString(it) }.toSet() } ?: ChildFeature.defaults,
        updatedAt = optLong("updatedAt"),
        linkId = optString("linkId")
    )
}

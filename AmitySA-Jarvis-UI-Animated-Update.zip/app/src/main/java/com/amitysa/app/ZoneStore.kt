package com.amitysa.app

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.PackageManager
import android.location.Location
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

data class SafeZone(val id: String, val name: String, val lat: Double, val lng: Double, val radiusM: Int, val notify: Boolean)
data class ZoneEvent(val time: Long, val text: String)
data class Fix(val lat: Double, val lng: Double, val time: Long)

/** Safe zones, last position and zone history, saved on this phone (works offline). */
class ZoneStore(context: Context) {
    private val prefs = context.getSharedPreferences("amity_zones", Context.MODE_PRIVATE)

    /** Erases everything saved for this account on this phone. */
    fun deleteAll(owner: String) {
        val editor = prefs.edit()
        prefs.all.keys.filter { it.endsWith("_$owner") }.forEach { editor.remove(it) }
        editor.apply()
    }

    fun newId(): String = UUID.randomUUID().toString()

    fun zones(owner: String): List<SafeZone> {
        val arr = JSONArray(prefs.getString("zones_$owner", "[]"))
        return (0 until arr.length()).map { arr.getJSONObject(it) }.map {
            SafeZone(it.getString("id"), it.getString("name"), it.getDouble("lat"), it.getDouble("lng"), it.getInt("r"), it.optBoolean("notify", true))
        }
    }

    fun addZone(owner: String, zone: SafeZone): Boolean {
        val current = zones(owner)
        if (current.size >= MAX_ZONES) return false
        writeZones(owner, current + zone)
        val states = insideStates(owner)
        states[zone.id] = true // we are standing here when we save it
        saveInsideStates(owner, states)
        return true
    }

    fun setNotify(owner: String, id: String, notify: Boolean) {
        writeZones(owner, zones(owner).map { if (it.id == id) it.copy(notify = notify) else it })
    }

    fun deleteZone(owner: String, id: String) {
        writeZones(owner, zones(owner).filter { it.id != id })
        saveInsideStates(owner, insideStates(owner).also { it.remove(id) })
    }

    fun insideStates(owner: String): MutableMap<String, Boolean> {
        val obj = JSONObject(prefs.getString("inside_$owner", "{}"))
        val map = mutableMapOf<String, Boolean>()
        obj.keys().forEach { map[it] = obj.getBoolean(it) }
        return map
    }

    fun saveInsideStates(owner: String, states: Map<String, Boolean>) {
        val obj = JSONObject()
        states.forEach { (k, v) -> obj.put(k, v) }
        prefs.edit().putString("inside_$owner", obj.toString()).apply()
    }

    fun lastFix(owner: String): Fix? {
        if (!prefs.contains("fix_time_$owner")) return null
        return Fix(
            Double.fromBits(prefs.getLong("fix_lat_$owner", 0L)),
            Double.fromBits(prefs.getLong("fix_lng_$owner", 0L)),
            prefs.getLong("fix_time_$owner", 0L)
        )
    }

    fun setLastFix(owner: String, lat: Double, lng: Double, time: Long) {
        prefs.edit().putLong("fix_lat_$owner", lat.toBits()).putLong("fix_lng_$owner", lng.toBits())
            .putLong("fix_time_$owner", time).apply()
    }

    fun events(owner: String): List<ZoneEvent> {
        val arr = JSONArray(prefs.getString("events_$owner", "[]"))
        return (0 until arr.length()).map { arr.getJSONObject(it) }.map { ZoneEvent(it.getLong("time"), it.getString("text")) }
    }

    fun addEvent(owner: String, event: ZoneEvent) {
        val arr = JSONArray()
        (listOf(event) + events(owner)).take(30).forEach { arr.put(JSONObject().put("time", it.time).put("text", it.text)) }
        prefs.edit().putString("events_$owner", arr.toString()).apply()
    }

    fun remoteProcessedAt(owner: String, childId: String): Long = prefs.getLong("remote_${childId}_$owner", 0L)
    fun setRemoteProcessedAt(owner: String, childId: String, time: Long) {
        prefs.edit().putLong("remote_${childId}_$owner", time).apply()
    }

    fun monitoring(owner: String): Boolean = prefs.getBoolean("monitoring_$owner", false)
    fun setMonitoring(owner: String, on: Boolean) { prefs.edit().putBoolean("monitoring_$owner", on).apply() }

    private fun writeZones(owner: String, list: List<SafeZone>) {
        val arr = JSONArray()
        list.forEach {
            arr.put(JSONObject().put("id", it.id).put("name", it.name).put("lat", it.lat).put("lng", it.lng)
                .put("r", it.radiusM).put("notify", it.notify))
        }
        prefs.edit().putString("zones_$owner", arr.toString()).apply()
    }

    companion object { const val MAX_ZONES = 10 }
}

/** Works out arrivals and departures for each new position. Runs on the phone, no internet needed. */
object ZoneMonitor {
    const val CHANNEL_WATCH = "amity_watch"
    const val CHANNEL_ZONE = "amity_zone_alerts"
    private const val EXIT_BUFFER_M = 30f

    fun hasLocationPermission(ctx: Context): Boolean =
        ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED

    fun ensureChannels(ctx: Context) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CHANNEL_WATCH, "Safe zone watching", NotificationManager.IMPORTANCE_LOW))
        nm.createNotificationChannel(NotificationChannel(CHANNEL_ZONE, "Zone alerts", NotificationManager.IMPORTANCE_HIGH))
    }

    fun process(ctx: Context, account: Account, loc: Location) {
        val store = ZoneStore(ctx)
        store.setLastFix(account.email, loc.latitude, loc.longitude, loc.time)
        if (loc.hasAccuracy() && loc.accuracy > 150f) return // too vague to judge arrivals/departures

        val states = store.insideStates(account.email)
        val results = FloatArray(1)
        store.zones(account.email).forEach { zone ->
            Location.distanceBetween(loc.latitude, loc.longitude, zone.lat, zone.lng, results)
            val was = states[zone.id]
            val inside = if (was == true) results[0] <= zone.radiusM + EXIT_BUFFER_M else results[0] <= zone.radiusM
            if (was == null) { states[zone.id] = inside; return@forEach }
            if (inside == was) return@forEach

            states[zone.id] = inside
            val time = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
            val text = "${account.username}'s phone ${if (inside) "arrived at" else "left"} ${zone.name}"
            store.addEvent(account.email, ZoneEvent(System.currentTimeMillis(), text))
            notify(ctx, "$text at $time")
            if (zone.notify && BuildConfig.DIRECT_SMS) Thread { SosSender.sendText(ctx.applicationContext, account, "AmitySA: $text at $time.") }.start()
        }
        store.saveInsideStates(account.email, states)
    }

    /** Checks a newly synced child-phone fix against this adult's saved zones. */
    fun processRemote(ctx: Context, account: Account, childId: String, childName: String, fix: Fix) {
        val store = ZoneStore(ctx)
        if (fix.time <= store.remoteProcessedAt(account.email, childId)) return
        if (System.currentTimeMillis() - fix.time > 10 * 60_000L) {
            store.setRemoteProcessedAt(account.email, childId, fix.time)
            return
        }
        val states = store.insideStates(account.email)
        val distance = FloatArray(1)
        store.zones(account.email).forEach { zone ->
            val key = "${childId}_${zone.id}"
            Location.distanceBetween(fix.lat, fix.lng, zone.lat, zone.lng, distance)
            val was = states[key]
            val inside = if (was == true) distance[0] <= zone.radiusM + EXIT_BUFFER_M else distance[0] <= zone.radiusM
            if (was == null) { states[key] = inside; return@forEach }
            if (inside == was) return@forEach
            states[key] = inside
            val whenText = if (inside) "arrived at" else "left"
            val text = "$childName $whenText ${zone.name}"
            store.addEvent(account.email, ZoneEvent(fix.time, text))
            notify(ctx, "${text} · ${SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(fix.time))}")
        }
        store.saveInsideStates(account.email, states)
        store.setRemoteProcessedAt(account.email, childId, fix.time)
    }

    private fun notify(ctx: Context, text: String) {
        ensureChannels(ctx)
        val nm = NotificationManagerCompat.from(ctx)
        if (!nm.areNotificationsEnabled()) return
        val n = NotificationCompat.Builder(ctx, CHANNEL_ZONE)
            .setSmallIcon(R.drawable.ic_stat_shield)
            .setContentTitle("AmitySA zone alert")
            .setContentText(text)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .build()
        try { nm.notify((System.currentTimeMillis() % 100000).toInt(), n) } catch (e: SecurityException) { }
    }
}

package com.amitysa.app

import android.Manifest
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val SosRed = Color(0xFFB3261E)
private val sosPermissions = if (BuildConfig.DIRECT_SMS) arrayOf(
    Manifest.permission.SEND_SMS,
    Manifest.permission.ACCESS_FINE_LOCATION,
    Manifest.permission.ACCESS_COARSE_LOCATION
) else arrayOf(
    Manifest.permission.ACCESS_FINE_LOCATION,
    Manifest.permission.ACCESS_COARSE_LOCATION
)

internal fun isHotkeyEnabled(ctx: Context): Boolean {
    val enabled = Settings.Secure.getString(ctx.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
    return enabled?.contains("SosHotkeyService") == true
}

private fun dial(ctx: Context, number: String) {
    ctx.startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:$number")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
}

// ---------- SOS countdown and send ----------

@Composable
internal fun SosCountdownScreen(
    account: Account?,
    onClose: () -> Unit,
    onSetup: () -> Unit,
    deviceName: String = "",
    deviceNumbers: List<String> = emptyList()
) {
    val ctx = LocalContext.current
    var allowed by remember { mutableStateOf(SosSender.ready(ctx)) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        allowed = SosSender.ready(ctx)
    }
    var secondsLeft by remember { mutableStateOf(5) }
    var phase by remember { mutableStateOf("countdown") }
    var result by remember { mutableStateOf<SosSender.Result?>(null) }

    LaunchedEffect(allowed) {
        if (!allowed) return@LaunchedEffect
        while (secondsLeft > 0) {
            delay(1000)
            secondsLeft--
        }
        phase = "sending"
        result = withContext(Dispatchers.IO) {
            if (account != null) SosSender.send(ctx, account, "on-screen")
            else SosSender.sendToNumbers(ctx, deviceName, deviceNumbers, "child phone")
        }
        phase = "done"
        result?.let { if (it.composeNumbers.isNotEmpty()) SosSender.openCompose(ctx, it.composeNumbers, it.composeMessage) }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(SosRed)
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(28.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        when {
            !allowed -> {
                Text("SOS needs permission", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                Text(
                    "Allow sending SMS and reading your location so AmitySA can text your SOS contacts.",
                    color = Color.White.copy(alpha = 0.9f), textAlign = TextAlign.Center
                )
                Spacer(Modifier.height(20.dp))
                WhiteButton("Allow") { launcher.launch(sosPermissions) }
            }
            phase == "countdown" -> {
                Text("Sending SOS in", color = Color.White, fontSize = 20.sp)
                Box(
                    modifier = Modifier.padding(24.dp).size(160.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.18f)),
                    contentAlignment = Alignment.Center
                ) { Text("$secondsLeft", color = Color.White, fontSize = 80.sp, fontWeight = FontWeight.ExtraBold) }
                WhiteButton("Cancel", filled = true) { onClose() }
            }
            phase == "sending" -> Text("Sending…", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold)
            else -> {
                val r = result
                val ok = r != null && r.error == null && r.sent > 0
                val compose = r != null && r.composeNumbers.isNotEmpty()
                Text(if (compose) "SOS ready" else if (ok) "SOS sent" else "SOS not sent", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.ExtraBold)
                Spacer(Modifier.height(8.dp))
                Text(
                    when {
                        r == null -> "Something went wrong."
                        r.error != null -> r.error
                        r.composeNumbers.isNotEmpty() -> "Your messages app is open with the alert ready. Tap Send to alert ${r.total} contact(s)."
                        else -> "Text sent to ${r.sent} of ${r.total} contacts. " +
                            if (r.hasLocation) "Your last known location was included." else "Location was not available."
                    },
                    color = Color.White.copy(alpha = 0.92f), textAlign = TextAlign.Center
                )
                if (r != null && r.composeNumbers.isNotEmpty()) {
                    Spacer(Modifier.height(12.dp))
                    WhiteButton("Open messages") { SosSender.openCompose(ctx, r.composeNumbers, r.composeMessage) }
                }
                if (r?.total == 0 && account != null) {
                    Spacer(Modifier.height(12.dp))
                    WhiteButton("Add SOS contacts") { onSetup() }
                }
            }
        }
        if (phase != "countdown" || !allowed) {
            Spacer(Modifier.height(28.dp))
            Text("Call for help", color = Color.White.copy(alpha = 0.8f), fontSize = 13.sp)
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                WhiteButton("Police 10111") { dial(ctx, "10111") }
                WhiteButton("Emergency 112") { dial(ctx, "112") }
            }
            Spacer(Modifier.height(16.dp))
            TextButton(onClick = onClose) { Text("Close", color = Color.White) }
        }
    }
}

@Composable
private fun WhiteButton(label: String, filled: Boolean = false, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        shape = RoundedCornerShape(16.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = if (filled) Color.White else Color.White.copy(alpha = 0.2f),
            contentColor = if (filled) SosRed else Color.White
        )
    ) { Text(label, fontWeight = FontWeight.SemiBold) }
}

// ---------- Emergency setup ----------

@Composable
internal fun SosSetupScreen(account: Account, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val t = LocalAmity.current
    val store = remember { SosStore(ctx) }
    var contacts by remember { mutableStateOf(store.contacts(account.email)) }
    val events = remember { store.events(account.email) }
    var name by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    var hotkeyOn by remember { mutableStateOf(isHotkeyEnabled(ctx)) }
    var permOk by remember { mutableStateOf(SosSender.ready(ctx)) }
    var showDisclosure by remember { mutableStateOf(false) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        permOk = SosSender.ready(ctx)
    }

    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                hotkeyOn = isHotkeyEnabled(ctx)
                permOk = SosSender.ready(ctx)
            }
        }
        owner.lifecycle.addObserver(observer)
        onDispose { owner.lifecycle.removeObserver(observer) }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(t.canvas)
            .verticalScroll(rememberScrollState())
            .imePadding()
            .navigationBarsPadding()
    ) {
        ScreenHeader("Emergency setup", onBack)
        Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {

            SetupCard {
                Text("SOS contacts", color = t.ink, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                Text(
                    "Up to ${SosStore.MAX_CONTACTS} people get a text with your location. Works without internet.",
                    color = t.inkSoft, fontSize = 13.sp
                )
                contacts.forEach { c ->
                    Row(
                        modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(t.canvas).padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text(c.name, color = t.ink, fontWeight = FontWeight.SemiBold)
                            Text(c.phone, color = t.inkSoft, fontSize = 12.sp)
                        }
                        Text(
                            "Remove", color = Danger, fontSize = 13.sp, fontWeight = FontWeight.SemiBold,
                            modifier = Modifier.clickable {
                                store.removeContact(account.email, c.phone)
                                contacts = store.contacts(account.email)
                            }.padding(8.dp)
                        )
                    }
                }
                if (contacts.size < SosStore.MAX_CONTACTS) {
                    AuthField(name, { name = it.take(40); error = null }, "Contact name", capitalize = true)
                    AuthField(phone, { phone = it; error = null }, "Number (South Africa)", KeyboardType.Phone)
                    error?.let { Text(it, color = Danger, fontSize = 13.sp) }
                    Button(
                        onClick = {
                            val normalized = normalizeSaPhone(phone)
                            when {
                                name.isBlank() -> error = "Enter the contact's name."
                                normalized == null -> error = "Use a South African number, e.g. 082 123 4567."
                                !store.addContact(account.email, SosContact(name.trim(), normalized)) ->
                                    error = "That number is already saved."
                                else -> {
                                    contacts = store.contacts(account.email)
                                    name = ""; phone = ""; error = null
                                }
                            }
                        },
                        modifier = Modifier.fillMaxWidth().height(50.dp),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = t.primary,
                            contentColor = if (t.dark) Color(0xFF04201F) else Color.White
                        )
                    ) { Text("Add contact", fontWeight = FontWeight.SemiBold) }
                }
            }

            SetupCard {
                Text("Permissions", color = t.ink, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                Text(
                    if (permOk) "✓ SMS and location are allowed." else "SOS needs permission to send SMS and read your location.",
                    color = t.inkSoft, fontSize = 13.sp
                )
                if (!permOk) {
                    Button(
                        onClick = { launcher.launch(sosPermissions) },
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = t.primary, contentColor = if (t.dark) Color(0xFF04201F) else Color.White)
                    ) { Text("Allow", fontWeight = FontWeight.SemiBold) }
                }
            }

            if (BuildConfig.HOTKEY) {
            SetupCard {
                Text("Hotkey", color = t.ink, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                Text(
                    if (hotkeyOn) "✓ On: press Volume Down 3 times quickly." else "Off: turn it on to start SOS with the volume button.",
                    color = t.inkSoft, fontSize = 13.sp
                )
                Text(
                    "Phone locked: the alert is sent immediately. Phone unlocked: AmitySA opens with a 5-second countdown you can cancel. Android will show a warning when you switch it on; AmitySA only watches for this button press.",
                    color = t.inkSoft, fontSize = 12.sp
                )
                if (!hotkeyOn) {
                    Button(
                        onClick = { showDisclosure = true },
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = t.primary, contentColor = if (t.dark) Color(0xFF04201F) else Color.White)
                    ) { Text("Open Accessibility settings", fontWeight = FontWeight.SemiBold) }
                    Text("Find “AmitySA SOS hotkey” and switch it on.", color = t.inkSoft, fontSize = 12.sp)
                }
            }
            }

            if (events.isNotEmpty()) {
                SetupCard {
                    Text("Recent SOS alerts", color = t.ink, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                    val fmt = remember { SimpleDateFormat("d MMM, HH:mm", Locale.getDefault()) }
                    events.take(5).forEach { e ->
                        Text(
                            "${fmt.format(Date(e.time))} · sent to ${e.sent}/${e.total}" +
                                (if (e.hasLocation) " · with location" else ""),
                            color = t.inkSoft, fontSize = 13.sp
                        )
                    }
                }
            }
        }
    }

    if (showDisclosure) {
        HotkeyDisclosureDialog(
            onAgree = {
                showDisclosure = false
                ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            },
            onDismiss = { showDisclosure = false }
        )
    }
}

@Composable
private fun SetupCard(content: @Composable ColumnScope.() -> Unit) {
    val t = LocalAmity.current
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xD9091B2A)),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp), content = content)
    }
}

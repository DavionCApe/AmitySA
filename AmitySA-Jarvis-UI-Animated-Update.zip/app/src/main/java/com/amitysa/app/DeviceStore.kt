package com.amitysa.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class DeviceInfo(
    val url: String,
    val token: String,
    val childId: String,
    val name: String,
    val features: Set<String>,
    val contacts: List<SosContact>
)

/** Settings for a phone that has been paired to one child. Parents and teachers change them remotely. */
class DeviceStore(context: Context) {
    private val prefs = context.getSharedPreferences("amity_device", Context.MODE_PRIVATE)

    fun paired(): DeviceInfo? {
        val token = prefs.getString("token", null) ?: return null
        val contacts = JSONArray(prefs.getString("contacts", "[]"))
        return DeviceInfo(
            prefs.getString("url", "") ?: "",
            token,
            prefs.getString("childId", "") ?: "",
            prefs.getString("name", "") ?: "",
            (prefs.getString("features", "") ?: "").split(",").filter { it.isNotBlank() }.toSet(),
            (0 until contacts.length()).map { contacts.getJSONObject(it) }.map { SosContact(it.optString("name"), it.getString("phone")) }
        )
    }

    fun save(url: String, token: String, childId: String, config: DeviceConfig) {
        prefs.edit().putString("url", url).putString("token", token).putString("childId", childId).apply()
        update(config)
    }

    fun update(config: DeviceConfig) {
        val arr = JSONArray()
        config.contacts.forEach { arr.put(JSONObject().put("name", it.name).put("phone", it.phone)) }
        prefs.edit().putString("name", config.name).putString("features", config.features.joinToString(","))
            .putString("contacts", arr.toString()).apply()
    }

    fun clear() { prefs.edit().clear().apply() }
}

object DeviceSync {
    enum class Status { OK, REVOKED, OFFLINE }

    /** Fetches the latest settings from the server. Blocking: call from a background thread. */
    fun refresh(ctx: Context): Status {
        val store = DeviceStore(ctx)
        val info = store.paired() ?: return Status.REVOKED
        return try {
            val config = CloudClient(info.url, info.token).deviceConfig()
            if (config.removed) { store.clear(); Status.REVOKED } else { store.update(config); Status.OK }
        } catch (e: CloudException) {
            if (e.status == 401) { store.clear(); Status.REVOKED } else Status.OFFLINE
        }
    }
}

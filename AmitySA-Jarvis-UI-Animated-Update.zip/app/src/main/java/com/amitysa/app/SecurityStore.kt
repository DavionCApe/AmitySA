package com.amitysa.app

import android.content.Context

/** App lock and voice SOS settings, saved on this phone. */
class SecurityStore(context: Context) {
    private val prefs = context.getSharedPreferences("amity_security", Context.MODE_PRIVATE)

    /** Erases everything saved for this account on this phone. */
    fun deleteAll(owner: String) {
        val editor = prefs.edit()
        prefs.all.keys.filter { it.endsWith("_$owner") }.forEach { editor.remove(it) }
        editor.apply()
    }

    fun lockEnabled(owner: String) = prefs.getBoolean("lock_$owner", false)
    fun setLock(owner: String, on: Boolean) { prefs.edit().putBoolean("lock_$owner", on).apply() }

    fun voiceEnabled(owner: String) = prefs.getBoolean("voice_$owner", false)
    fun phrase(owner: String) = prefs.getString("phrase_$owner", "") ?: ""
    fun setVoice(owner: String, on: Boolean, phrase: String) {
        prefs.edit().putBoolean("voice_$owner", on).putString("phrase_$owner", phrase.trim()).apply()
    }
}

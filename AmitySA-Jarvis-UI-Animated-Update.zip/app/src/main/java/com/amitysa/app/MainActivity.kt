package com.amitysa.app

import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.compose.runtime.getValue
import androidx.compose.animation.core.LinearEasing
import androidx.activity.ComponentActivity
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.compose.ui.platform.LocalLifecycleOwner
import android.os.SystemClock
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Image
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.derivedStateOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlinx.coroutines.launch

// ---------- Themes (saved on the device, work fully offline) ----------

internal data class AmityTheme(
    val id: String,
    val label: String,
    val dark: Boolean,
    val canvas: Color,
    val card: Color,
    val ink: Color,
    val inkSoft: Color,
    val primary: Color,
    val accent: Color,
    val onAccent: Color
)

private val Midnight = AmityTheme(
    "midnight", "Midnight (logo colours)", true,
    Color(0xFF0F131A), Color(0xFF182029), Color(0xFFF2F4F7), Color(0xFF9AA5B4),
    Color(0xFF2DD4CF), Color(0xFFF5B942), Color(0xFF1A1405)
)
private val Ocean = AmityTheme(
    "ocean", "Ocean (light)", false,
    Color(0xFFF3F7F7), Color(0xFFFFFFFF), Color(0xFF10282A), Color(0xFF5F7070),
    Color(0xFF0B5D5E), Color(0xFFFFB020), Color(0xFF063F40)
)
private val Sunrise = AmityTheme(
    "sunrise", "Sunrise (warm light)", false,
    Color(0xFFFFF8EE), Color(0xFFFFFFFF), Color(0xFF3A2A12), Color(0xFF7A6850),
    Color(0xFFE07A1F), Color(0xFFF5B942), Color(0xFF3A2A12)
)
private val Forest = AmityTheme(
    "forest", "Forest (dark green)", true,
    Color(0xFF0E1712), Color(0xFF16241C), Color(0xFFEAF3EC), Color(0xFF93AA9B),
    Color(0xFF4CC38A), Color(0xFFE8C468), Color(0xFF14210F)
)
private val Lavender = AmityTheme(
    "lavender", "Lavender (soft purple)", false,
    Color(0xFFF5F2FB), Color(0xFFFFFFFF), Color(0xFF28213A), Color(0xFF766C8C),
    Color(0xFF7053B8), Color(0xFFE7B95D), Color(0xFFFFFFFF)
)
private val Rose = AmityTheme(
    "rose", "Rose (soft warm)", false,
    Color(0xFFFFF2F3), Color(0xFFFFFFFF), Color(0xFF3B2028), Color(0xFF896B73),
    Color(0xFFB84E70), Color(0xFFF2B45D), Color(0xFFFFFFFF)
)
private val themeChoices = listOf(Midnight, Ocean, Sunrise, Forest, Lavender, Rose)
private const val THEME_AUTO = "auto"

internal val LocalAmity = staticCompositionLocalOf { Midnight }

@Composable
private fun resolveTheme(id: String): AmityTheme = when (id) {
    "midnight" -> Midnight
    "ocean" -> Ocean
    "sunrise" -> Sunrise
    "forest" -> Forest
    "lavender" -> Lavender
    "rose" -> Rose
    else -> if (isSystemInDarkTheme()) Midnight else Ocean
}

// The header always stays dark so the logo glows in every theme.
internal val HeaderTop = Color(0xFF0B0E14)
internal val HeaderBottom = Color(0xFF05070B)
internal val Gold = Color(0xFFF5B942)
internal val Danger = Color(0xFFD93025)

// ---------- Content ----------

private val taglines = listOf(
    "Safety in your pocket.",
    "Securing our future.",
    "Peace of mind, simplified."
)

private data class QuickAction(
    val icon: String,
    val title: String,
    val subtitle: String,
    val needsInternet: Boolean = false
)

private data class Activity(val icon: String, val title: String, val time: String)

private val quickActions = listOf(
    QuickAction("👧", "Children", "Profiles & classes"),
    QuickAction("📍", "Location", "This phone, works offline"),
    QuickAction("🗺️", "Google Maps", "Open free maps on your device or browser"),
    QuickAction("🛡️", "Safe zones", "Saved on your phone"),
    QuickAction("🤝", "Family check-in", "Share quick status updates", needsInternet = true),
    QuickAction("🚨", "SOS setup", "Contacts & hotkey"),
    QuickAction("🔐", "Security", "Lock, voice & shortcut"),
    QuickAction("🎨", "Themes", "Change app look"),
    QuickAction("🔗", "Cloud link", "Optional · you choose"),
    QuickAction("⚙️", "Settings", "Account & privacy")
)

private val recentActivity = listOf(
    Activity("🏫", "Arrived at school", "Sample · 07:42"),
    Activity("🛡️", "Entered safe zone: Home", "Sample · Yesterday"),
    Activity("🔔", "Weekly safety summary ready", "Sample · Mon")
)

// ---------- Activity ----------

private fun isSosIntent(i: Intent?): Boolean =
    i?.getBooleanExtra("sos", false) == true || i?.action == "com.amitysa.app.action.SOS"

class MainActivity : FragmentActivity() {
    private var sosRequested by mutableStateOf(false)

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        if (isSosIntent(intent)) sosRequested = true
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
        )
        sosRequested = isSosIntent(intent)
        setContent { AmityApp(sosRequested) { sosRequested = false } }
    }
}

@Composable
fun AmityApp(sosRequested: Boolean = false, onSosHandled: () -> Unit = {}) {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("amity_prefs", Context.MODE_PRIVATE) }
    var themeId by remember { mutableStateOf(prefs.getString("theme", "midnight") ?: "midnight") }
    var showPopup by remember { mutableStateOf(!sosRequested) }
    var showThemes by remember { mutableStateOf(false) }
    var showGoogleMapsChooser by remember { mutableStateOf(false) }
    val online by rememberOnline()
    val store = remember { AccountStore(context) }
    var account by remember { mutableStateOf(store.currentAccount()) }
    val acc = account
    val deviceStore = remember { DeviceStore(context) }
    var device by remember { mutableStateOf(deviceStore.paired()) }
    val dev = device
    var pairing by remember { mutableStateOf(false) }
    var deviceSos by remember { mutableStateOf(false) }
    val childStore = remember { ChildStore(context) }
    val sec = remember { SecurityStore(context) }
    var secTick by remember { mutableStateOf(0) }
    var locked by remember { mutableStateOf(acc != null && sec.lockEnabled(acc.email)) }
    var sosOverLock by remember { mutableStateOf(false) }
    val restoredPage = remember(acc?.email) {
        if (acc == null) "home" else prefs.getString("active_page_${acc.email}", "home")
            ?.takeIf { it in setOf("home", "children", "map", "zones", "checkin", "cloud", "security", "sosSetup") }
            ?: "home"
    }
    var screen by remember { mutableStateOf(restoredPage) }
    val screenHistory = remember { mutableStateListOf<String>() }
    fun navigateTo(destination: String) {
        if (screen != destination) {
            // Close page-level popups before replacing the page so a modal can
            // never remain visually stranded underneath the next feature.
            showThemes = false
            showGoogleMapsChooser = false
            screenHistory.add(screen)
            screen = destination
        }
    }
    fun navigateBack() {
        showThemes = false
        showGoogleMapsChooser = false
        if (screenHistory.isNotEmpty()) {
            screen = screenHistory.removeAt(screenHistory.lastIndex)
        } else {
            screen = "home"
        }
    }
    // Keep the current page across app backgrounding and process recreation.
    LaunchedEffect(acc?.email, screen) {
        if (acc != null) prefs.edit().putString("active_page_${acc.email}", screen).apply()
    }
    // New visitors land on registration after the splash/loading screen.
    // The floating preview action can temporarily switch to read-only browsing.
    var showAuth by remember { mutableStateOf(true) }
    var authStartsRegistering by remember { mutableStateOf(true) }
    var editingId by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(acc) {
        if (acc != null && CloudStore(context).enabled(acc.email)) CloudSync.syncInBackground(context, acc)
        if (acc != null && ZoneStore(context).monitoring(acc.email) && ZoneMonitor.hasLocationPermission(context)) {
            try { startTracking(context, acc.email) } catch (e: Exception) { }
        }
    }
    LaunchedEffect(sosRequested, acc, dev) {
        if (sosRequested) {
            if (dev != null) { if (dev.features.contains(ChildFeature.SOS) || dev.features.contains(ChildFeature.HOTKEY)) deviceSos = true }
            else if (acc != null) { if (locked) sosOverLock = true else navigateTo("sos") }
            onSosHandled()
        }
    }
    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner, acc?.email) {
        var leftAt = 0L
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_STOP) leftAt = SystemClock.elapsedRealtime()
            if (event == Lifecycle.Event.ON_START && leftAt != 0L) {
                val email = acc?.email
                if (email != null && sec.lockEnabled(email) && SystemClock.elapsedRealtime() - leftAt > 30_000L) locked = true
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }
    // System Back does not silently close a feature page. The user closes it
    // explicitly with the X beside MENU; the current page is restored on relaunch.
    BackHandler(enabled = acc != null && screen != "home") { navigateBack() }
    val theme = resolveTheme(themeId)

    // Apply the selected palette to the complete Material surface system so
    // standard controls, cards, dialogs, text fields and advanced pages all
    // follow the same light/dark theme instead of falling back to defaults.
    val scheme = if (theme.dark) darkColorScheme(
        primary = theme.primary,
        onPrimary = theme.onAccent,
        secondary = theme.accent,
        onSecondary = theme.onAccent,
        tertiary = theme.accent,
        background = theme.canvas,
        onBackground = theme.ink,
        surface = theme.card,
        onSurface = theme.ink,
        surfaceVariant = theme.canvas,
        onSurfaceVariant = theme.inkSoft,
        outline = theme.inkSoft
    ) else lightColorScheme(
        primary = theme.primary,
        onPrimary = theme.onAccent,
        secondary = theme.accent,
        onSecondary = theme.onAccent,
        tertiary = theme.accent,
        background = theme.canvas,
        onBackground = theme.ink,
        surface = theme.card,
        onSurface = theme.ink,
        surfaceVariant = theme.canvas,
        onSurfaceVariant = theme.inkSoft,
        outline = theme.inkSoft
    )

    MaterialTheme(colorScheme = scheme) {
        Surface(modifier = Modifier.fillMaxSize(), color = theme.canvas) {
        CompositionLocalProvider(LocalAmity provides theme) {
            if (dev != null) {
                if (deviceSos) SosCountdownScreen(
                    account = null,
                    onClose = { deviceSos = false },
                    onSetup = { deviceSos = false },
                    deviceName = dev.name,
                    deviceNumbers = dev.contacts.map { it.phone }
                ) else ChildHomeScreen(
                    info = dev,
                    onSos = { deviceSos = true },
                    onChanged = { device = deviceStore.paired() }
                )
            }
            else if (pairing) ChildPairScreen(
                onPaired = { device = deviceStore.paired(); pairing = false },
                onBack = { pairing = false }
            )
            else if (acc == null && !showAuth) AmityWelcomeScreen(
                onSignIn = { authStartsRegistering = false; showAuth = true },
                onCreateAccount = { authStartsRegistering = true; showAuth = true }
            )
            else if (acc == null) AuthScreen(
                store = store,
                online = online,
                onChildSetup = { pairing = true },
                onAuthenticated = { account = it; showAuth = false },
                onPreview = { showAuth = false },
                startRegistering = authStartsRegistering
            )
            else if (locked) {
                if (sosOverLock) SosCountdownScreen(
                    account = acc,
                    onClose = { sosOverLock = false },
                    onSetup = { sosOverLock = false }
                ) else LockScreen(
                    onUnlock = { locked = false },
                    onSos = { sosOverLock = true },
                    onTurnOffLock = { sec.setLock(acc.email, false); locked = false; secTick++ }
                )
            }
            else if (screen == "children") ChildrenScreen(
                account = acc,
                store = childStore,
                onBack = { navigateBack() },
                onEdit = { editingId = it; navigateTo("edit") }
            )
            else if (screen == "edit") ChildEditScreen(
                account = acc,
                store = childStore,
                id = editingId,
                onDone = { navigateBack() }
            )
            else if (screen == "sos") SosCountdownScreen(
                account = acc,
                onClose = { navigateBack() },
                onSetup = { navigateTo("sosSetup") }
            )
            else if (screen == "sosSetup") SosSetupScreen(acc) { navigateBack() }
            else if (screen == "map") FamilyMapScreen(acc) { navigateBack() }
            else if (screen == "zones") ZonesScreen(acc) { navigateBack() }
            else if (screen == "checkin") FamilyCheckInScreen(acc) { navigateBack() }
            else if (screen == "cloud") CloudScreen(acc) { navigateBack() }
            else if (screen == "security") SecurityScreen(
                acc,
                onBack = { navigateBack() },
                onChanged = { secTick++ },
                onDeleted = { account = null; screenHistory.clear(); screen = "home"; locked = false }
            )
            else HomeScreen(
                account = acc,
                onSignOut = { stopTracking(context, acc.email); store.signOut(); account = null; screenHistory.clear(); screen = "home" },
                online = online,
                onOpenThemes = { showThemes = true },
                onSos = { navigateTo("sos") },
                onAction = { action ->
                    when {
                        action.needsInternet && !online ->
                            Toast.makeText(context, "${action.title} needs internet. You're offline.", Toast.LENGTH_SHORT).show()
                        action.title == "Themes" -> showThemes = true
                        action.title == "Children" -> navigateTo("children")
                        action.title == "SOS setup" -> navigateTo("sosSetup")
                        action.title == "Security" -> navigateTo("security")
                        action.title == "Cloud link" -> navigateTo("cloud")
                        action.title == "Location" -> navigateTo("map")
                        action.title == "Google Maps" -> showGoogleMapsChooser = true
                        action.title == "Safe zones" -> navigateTo("zones")
                        action.title == "Family check-in" -> navigateTo("checkin")
                        else ->
                            Toast.makeText(context, "${action.title} is coming in a later stage.", Toast.LENGTH_SHORT).show()
                    }
                },
                onMenuAction = { item ->
                    when (item) {
                        "Home" -> navigateTo("home")
                        "Children & family" -> navigateTo("children")
                        "Family live map" -> navigateTo("map")
                        "Google Maps" -> showGoogleMapsChooser = true
                        "Safe zones" -> navigateTo("zones")
                        "Family check-in" -> navigateTo("checkin")
                        "Emergency SOS" -> navigateTo("sos")
                        "SOS contacts" -> navigateTo("sosSetup")
                        "Security & privacy" -> navigateTo("security")
                        "Cloud sync" -> navigateTo("cloud")
                        "Appearance" -> showThemes = true
                        "Sign out" -> { stopTracking(context, acc.email); store.signOut(); account = null; screenHistory.clear(); screen = "home" }
                        else -> Toast.makeText(context, "$item will be available in a future update.", Toast.LENGTH_SHORT).show()
                    }
                }
            )
            // Shared animated HUD layer appears consistently across all
            // featured pages while remaining below modal popup windows.
            JarvisAmbientBackdrop(Modifier.fillMaxSize())
            if (acc != null && !locked && screen != "home") {
                SessionPageControls(
                    activePage = when (screen) {
                        "children" -> "Children & family"
                        "edit" -> "Edit child profile"
                        "map" -> "Family live map"
                        "zones" -> "Safe zones"
                        "checkin" -> "Family check-in"
                        "sos" -> "Emergency SOS"
                        "sosSetup" -> "SOS contacts"
                        "security" -> "Security & privacy"
                        "cloud" -> "Cloud sync"
                        else -> "Current page"
                    },
                    onClosePage = { navigateBack() },
                    onSelect = { item ->
                        when (item) {
                            "Home" -> navigateTo("home")
                            "Children & family" -> navigateTo("children")
                            "Family live map" -> navigateTo("map")
                            "Google Maps" -> showGoogleMapsChooser = true
                            "Safe zones" -> navigateTo("zones")
                            "Family check-in" -> navigateTo("checkin")
                            "Emergency SOS" -> navigateTo("sos")
                            "SOS contacts" -> navigateTo("sosSetup")
                            "Security & privacy" -> navigateTo("security")
                            "Cloud sync" -> navigateTo("cloud")
                            "Appearance" -> showThemes = true
                            "Sign out" -> { stopTracking(context, acc.email); store.signOut(); account = null; screenHistory.clear(); screen = "home" }
                        }
                    }
                )
            }
            val voiceActive = remember(secTick, acc?.email) { acc != null && sec.voiceEnabled(acc.email) }
            val voicePhrase = remember(secTick, acc?.email) { if (acc != null) sec.phrase(acc.email) else "" }
            VoicePhraseListener(
                enabled = voiceActive && !locked && screen != "sos" && screen != "security" && !showPopup,
                phrase = voicePhrase,
                onHeard = { navigateTo("sos") }
            )
            if (showGoogleMapsChooser) {
                AlertDialog(
                    onDismissRequest = { showGoogleMapsChooser = false },
                    title = { Text("Open Google Maps") },
                    text = { Text("Choose how to open Google Maps. It is free to use on supported devices and in a browser. An internet connection or mobile data may be needed for maps and directions.") },
                    confirmButton = {
                        TextButton(onClick = {
                            showGoogleMapsChooser = false
                            val mapsIntent = Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q="))
                                .setPackage("com.google.android.apps.maps")
                            try {
                                context.startActivity(mapsIntent)
                            } catch (_: Exception) {
                                Toast.makeText(context, "Google Maps is not installed. Please choose Web browser or install Google Maps from the Play Store.", Toast.LENGTH_LONG).show()
                            }
                        }) { Text("Google Maps app") }
                    },
                    dismissButton = {
                        Row {
                            TextButton(onClick = {
                                showGoogleMapsChooser = false
                                try {
                                    context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/maps")))
                                } catch (_: Exception) {
                                    Toast.makeText(context, "No web browser is available on this device.", Toast.LENGTH_SHORT).show()
                                }
                            }) { Text("Web browser") }
                            TextButton(onClick = { showGoogleMapsChooser = false }) { Text("Cancel") }
                        }
                    }
                )
            }
            if (showThemes) {
                ThemeDialog(
                    selected = themeId,
                    onSelect = {
                        themeId = it
                        prefs.edit().putString("theme", it).apply()
                    },
                    onDismiss = { showThemes = false }
                )
            }
            if (showPopup) LaunchPopup { showPopup = false }
        }
        }
    }
}

/**
 * Ambient JARVIS visual layer shared by every route. It sits at the back of
 * the root Surface, so screens and all dialog windows remain above it.
 */
@Composable
private fun JarvisAmbientBackdrop(modifier: Modifier = Modifier) {
    val motion = rememberInfiniteTransition(label = "ambientPlanetMotion")
    val orbit by motion.animateFloat(
        initialValue = 0f, targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(26000, easing = LinearEasing)),
        label = "planetOrbit"
    )
    val drift by motion.animateFloat(
        initialValue = -10f, targetValue = 10f,
        animationSpec = infiniteRepeatable(tween(5200, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "planetDrift"
    )
    val pulse by motion.animateFloat(
        initialValue = 0.28f, targetValue = 0.68f,
        animationSpec = infiniteRepeatable(tween(2100), RepeatMode.Reverse),
        label = "planetPulse"
    )
    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height
        val cx = w * 0.84f
        val cy = h * 0.80f + drift * density
        val r = (size.minDimension * 0.105f).coerceIn(34f * density, 58f * density)
        val cyan = Color(0xFF54DFFF)
        val ice = Color(0xFFB7F5FF)
        val amber = Color(0xFFFF9B58)

        // Sparse moving star/signal field, intentionally low contrast.
        for (i in 0..22) {
            val x = ((i * 73f + orbit * (0.10f + (i % 3) * 0.025f)) % w)
            val y = ((i * 137f + (i % 4) * 29f) % h)
            val a = (0.12f + pulse * 0.18f) * if (i % 5 == 0) 1.5f else 1f
            drawCircle(if (i % 6 == 0) amber.copy(alpha = a) else ice.copy(alpha = a), if (i % 4 == 0) 1.8f * density else 1f * density, androidx.compose.ui.geometry.Offset(x, y))
        }

        // Fine planetary orbit rings behind the globe.
        rotate(orbit, androidx.compose.ui.geometry.Offset(cx, cy)) {
            drawOval(cyan.copy(alpha = 0.16f), topLeft = androidx.compose.ui.geometry.Offset(cx - r * 1.8f, cy - r * 0.48f), size = androidx.compose.ui.geometry.Size(r * 3.6f, r * 0.96f), style = androidx.compose.ui.graphics.drawscope.Stroke(1.1f * density))
            drawOval(amber.copy(alpha = 0.12f), topLeft = androidx.compose.ui.geometry.Offset(cx - r * 1.55f, cy - r * 0.78f), size = androidx.compose.ui.geometry.Size(r * 3.1f, r * 1.56f), style = androidx.compose.ui.graphics.drawscope.Stroke(0.8f * density))
        }

        // Glassy Earth-like sphere with atmospheric rim.
        drawCircle(cyan.copy(alpha = 0.10f + pulse * 0.05f), r * 1.12f, androidx.compose.ui.geometry.Offset(cx, cy), style = androidx.compose.ui.graphics.drawscope.Stroke(2.2f * density))
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(Color(0xFF276F88).copy(alpha = 0.42f), Color(0xFF0B344D).copy(alpha = 0.28f), Color(0xFF03111E).copy(alpha = 0.12f)),
                center = androidx.compose.ui.geometry.Offset(cx - r * 0.32f, cy - r * 0.38f), radius = r * 1.45f
            ),
            radius = r,
            center = androidx.compose.ui.geometry.Offset(cx, cy)
        )
        drawCircle(cyan.copy(alpha = 0.36f), r, androidx.compose.ui.geometry.Offset(cx, cy), style = androidx.compose.ui.graphics.drawscope.Stroke(1.2f * density))

        // Stylised continents rotate slowly inside the spherical silhouette.
        rotate(orbit * 0.22f, androidx.compose.ui.geometry.Offset(cx, cy)) {
            val land = Brush.linearGradient(listOf(Color(0xFF63D6B4).copy(alpha = 0.24f), Color(0xFF2E9E9B).copy(alpha = 0.10f)))
            val continentA = androidx.compose.ui.graphics.Path().apply {
                moveTo(cx - r * 0.68f, cy - r * 0.38f); lineTo(cx - r * 0.35f, cy - r * 0.62f)
                lineTo(cx - r * 0.08f, cy - r * 0.48f); lineTo(cx - r * 0.16f, cy - r * 0.18f)
                lineTo(cx - r * 0.48f, cy - r * 0.12f); lineTo(cx - r * 0.68f, cy - r * 0.38f); close()
            }
            val continentB = androidx.compose.ui.graphics.Path().apply {
                moveTo(cx + r * 0.08f, cy - r * 0.20f); lineTo(cx + r * 0.42f, cy - r * 0.34f)
                lineTo(cx + r * 0.70f, cy - r * 0.08f); lineTo(cx + r * 0.48f, cy + r * 0.16f)
                lineTo(cx + r * 0.22f, cy + r * 0.12f); lineTo(cx + r * 0.08f, cy - r * 0.20f); close()
            }
            drawPath(continentA, land)
            drawPath(continentB, land)
            drawArc(cyan.copy(alpha = 0.17f), 90f, 180f, false, androidx.compose.ui.geometry.Offset(cx - r * 0.78f, cy - r), androidx.compose.ui.geometry.Size(r * 1.56f, r * 2f), style = androidx.compose.ui.graphics.drawscope.Stroke(0.9f * density))
        }
        val a = Math.toRadians(orbit.toDouble())
        val satellite = androidx.compose.ui.geometry.Offset(cx + kotlin.math.cos(a).toFloat() * r * 1.78f, cy + kotlin.math.sin(a).toFloat() * r * 0.48f)
        drawCircle(amber.copy(alpha = 0.25f + pulse * 0.35f), 5f * density, satellite)
        drawCircle(ice.copy(alpha = 0.78f), 1.8f * density, satellite)
        drawCircle(cyan.copy(alpha = 0.18f), r * 1.34f, androidx.compose.ui.geometry.Offset(cx, cy), style = androidx.compose.ui.graphics.drawscope.Stroke(0.7f * density))
    }
}

@Composable
private fun SessionPageControls(activePage: String, onClosePage: () -> Unit, onSelect: (String) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    val items = listOf(
        Triple("⌂", "Home", "Safety overview"),
        Triple("👨‍👩‍👧", "Children & family", "Profiles and family links"),
        Triple("🗺", "Family live map", "Shared family locations"),
        Triple("🌐", "Google Maps", "Open maps and directions"),
        Triple("📍", "Safe zones", "Arrival and departure alerts"),
        Triple("🤝", "Family check-in", "Quick shared status updates"),
        Triple("🚨", "Emergency SOS", "Emergency alert tools"),
        Triple("☎", "SOS contacts", "Manage emergency contacts"),
        Triple("🔐", "Security & privacy", "App lock and privacy"),
        Triple("☁", "Cloud sync", "Optional account backup"),
        Triple("🎨", "Appearance", "Themes and colours"),
        Triple("←", "Previous page", "Return to the screen you came from"),
        Triple("↪", "Sign out", "Sign out of this account")
    )
    Row(Modifier.fillMaxWidth().statusBarsPadding().padding(top = 8.dp, end = 14.dp), horizontalArrangement = Arrangement.End) {
        Surface(onClick = { expanded = true }, shape = RoundedCornerShape(13.dp), color = Color(0xE80A1A28), shadowElevation = 10.dp) {
            Text("☰  JARVIS MENU", Modifier.padding(horizontal = 15.dp, vertical = 11.dp), color = Color(0xFFDDF9FF), fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
        }
    }
    if (expanded) JarvisFloatingMenu(
        heading = "ACTIVE PAGE  /  $activePage",
        entries = items,
        onDismiss = { expanded = false },
        onSelect = { expanded = false; if (it == "Previous page") onClosePage() else onSelect(it) }
    )
}

// ---------- Connectivity ----------

@Composable
private fun rememberOnline(): State<Boolean> {
    val ctx = LocalContext.current
    val cm = remember { ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager }
    val state = remember { mutableStateOf(cm.isOnlineNow()) }
    DisposableEffect(cm) {
        val callback = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) { state.value = true }
            override fun onLost(network: Network) { state.value = false }
        }
        cm.registerDefaultNetworkCallback(callback)
        onDispose { cm.unregisterNetworkCallback(callback) }
    }
    return state
}

private fun ConnectivityManager.isOnlineNow(): Boolean {
    val caps = getNetworkCapabilities(activeNetwork) ?: return false
    return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
}

// ---------- Dialogs ----------

@Composable
private fun LaunchPopup(onDismiss: () -> Unit) {
    val scale = remember { Animatable(0.25f) }
    val fade = remember { Animatable(0f) }
    var index by remember { mutableStateOf(-1) }

    LaunchedEffect(Unit) {
        launch { fade.animateTo(1f, tween(600)) }
        scale.animateTo(
            1f,
            spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessLow)
        )
        delay(250)
        for (i in taglines.indices) {
            index = i
            delay(1400)
        }
        delay(150)
        onDismiss()
    }

    val pulse by rememberInfiniteTransition(label = "pulse").animateFloat(
        initialValue = 0.97f,
        targetValue = 1.04f,
        animationSpec = infiniteRepeatable(tween(1300, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "pulseValue"
    )

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Brush.radialGradient(listOf(Color(0xFF17222F), Color(0xFF05070B))))
                .clickable(onClick = onDismiss),
            contentAlignment = Alignment.Center
        ) {
            Column(
                modifier = Modifier.padding(32.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Image(
                    painter = painterResource(R.drawable.amity_logo),
                    contentDescription = "AmitySA logo",
                    modifier = Modifier
                        .fillMaxWidth(0.8f)
                        .widthIn(max = 360.dp)
                        .graphicsLayer {
                            val s = scale.value * pulse
                            scaleX = s
                            scaleY = s
                            alpha = fade.value
                        }
                )
                Spacer(Modifier.height(28.dp))
                Box(
                    modifier = Modifier.heightIn(min = 64.dp),
                    contentAlignment = Alignment.TopCenter
                ) {
                    AnimatedContent(
                        targetState = index,
                        transitionSpec = {
                            (slideInVertically { it } + fadeIn(tween(350)) + scaleIn(initialScale = 0.8f)) togetherWith
                                (slideOutVertically { -it } + fadeOut(tween(250)))
                        },
                        label = "tagline"
                    ) { i ->
                        if (i >= 0) {
                            Text(
                                "AmitySA: ${taglines[i]}",
                                color = Gold,
                                fontSize = 22.sp,
                                fontWeight = FontWeight.Bold,
                                textAlign = TextAlign.Center
                            )
                        } else {
                            Spacer(Modifier.height(1.dp))
                        }
                    }
                }
            }
            Text(
                "Tap to skip",
                color = Color.White.copy(alpha = 0.4f),
                fontSize = 12.sp,
                modifier = Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(24.dp)
            )
        }
    }
}

@Composable
private fun ThemeDialog(selected: String, onSelect: (String) -> Unit, onDismiss: () -> Unit) {
    val t = LocalAmity.current
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Box(Modifier.fillMaxSize().background(Color(0x99020710)), contentAlignment = Alignment.Center) {
        Card(
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xD9091B2A))
        ) {
            Column(modifier = Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("App theme", color = t.ink, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Text("Saved on this phone. Works offline.", color = t.inkSoft, fontSize = 13.sp)
                Spacer(Modifier.height(4.dp))
                themeChoices.forEach { choice ->
                    ThemeRow(
                        label = choice.label,
                        swatchA = choice.primary,
                        swatchB = choice.accent,
                        isSelected = selected == choice.id,
                        onClick = { onSelect(choice.id) }
                    )
                }
                ThemeRow(
                    label = "Match my phone (auto)",
                    swatchA = Midnight.canvas,
                    swatchB = Ocean.canvas,
                    isSelected = selected == THEME_AUTO,
                    onClick = { onSelect(THEME_AUTO) }
                )
                Spacer(Modifier.height(4.dp))
                TextButton(onClick = onDismiss, modifier = Modifier.align(Alignment.End)) {
                    Text("Done", color = t.primary, fontWeight = FontWeight.SemiBold)
                }
            }
        }
        }
    }
}

@Composable
private fun ThemeRow(label: String, swatchA: Color, swatchB: Color, isSelected: Boolean, onClick: () -> Unit) {
    val t = LocalAmity.current
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(if (isSelected) t.primary.copy(alpha = 0.15f) else Color.Transparent)
            .clickable(onClick = onClick)
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(26.dp).clip(CircleShape).background(swatchA))
        Box(Modifier.offset(x = (-8).dp).size(26.dp).clip(CircleShape).background(swatchB))
        Spacer(Modifier.width(4.dp))
        Text(label, color = t.ink, fontSize = 15.sp, modifier = Modifier.weight(1f))
        if (isSelected) Text("✓", color = t.primary, fontSize = 18.sp, fontWeight = FontWeight.Bold)
    }
}

// ---------- Home screen ----------

@Composable
private fun HomeScreen(
    account: Account,
    onSignOut: () -> Unit,
    online: Boolean,
    onOpenThemes: () -> Unit,
    onSos: () -> Unit,
    onAction: (QuickAction) -> Unit,
    onMenuAction: (String) -> Unit
) {
    val t = LocalAmity.current
    val listState = rememberLazyListState()
    val scope = rememberCoroutineScope()
    val showBackToTop by remember {
        derivedStateOf { listState.firstVisibleItemIndex > 1 || listState.firstVisibleItemScrollOffset > 420 }
    }
    val stories = listOf(
        Triple("🛡️", "Safety that starts with connection", "AmitySA brings family safety tools together in one place, helping parents and children stay connected."),
        Triple("🗺️", "Know the way. Stay connected.", "Explore family map options, Google Maps and saved safe places. Location sharing requires permission and an active connection."),
        Triple("🤝", "Little updates. Greater peace of mind.", "Family check-ins make it easier to share that you are safe, have arrived or need help."),
        Triple("🚨", "Support when it matters", "Set up emergency contacts and review SOS settings before relying on emergency features.")
    )
    var storyIndex by remember { mutableIntStateOf(0) }
    LaunchedEffect(Unit) {
        while (true) {
            delay(5200)
            storyIndex = (storyIndex + 1) % stories.size
        }
    }

    Box(Modifier.fillMaxSize().background(t.canvas)) {
        LazyColumn(
            state = listState,
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(bottom = 36.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            item { Header(account.username, onOpenThemes, onMenuAction) }
            if (!online) item { OfflineBanner() }
            item {
                Column(Modifier.fillMaxWidth().padding(horizontal = 20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("WELCOME TO AMITYSA", color = t.primary, fontSize = 11.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 2.sp)
                    Text("A safer way to
stay connected.", color = t.ink, fontSize = 30.sp, lineHeight = 35.sp, fontWeight = FontWeight.ExtraBold)
                    Text("Family-focused tools designed to help parents and children communicate, check in and stay informed.", color = t.inkSoft, fontSize = 15.sp, lineHeight = 22.sp)
                }
            }
            item { AnimatedFamilyHero() }
            item {
                AnimatedContent(
                    targetState = storyIndex,
                    transitionSpec = { (fadeIn(tween(420)) + scaleIn(initialScale = 0.94f, animationSpec = tween(420))) togetherWith (fadeOut(tween(260)) + scaleOut(targetScale = 1.03f, animationSpec = tween(260))) },
                    label = "Amity feature story"
                ) { index ->
                    val story = stories[index]
                    Card(
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp),
                        shape = RoundedCornerShape(24.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0xD9091B2A)),
                        elevation = CardDefaults.cardElevation(defaultElevation = 5.dp)
                    ) {
                        Row(Modifier.padding(20.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                            Box(Modifier.size(62.dp).clip(RoundedCornerShape(20.dp)).background(t.primary.copy(alpha = 0.13f)), contentAlignment = Alignment.Center) {
                                Text(story.first, fontSize = 34.sp)
                            }
                            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text(story.second, color = t.ink, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                                Text(story.third, color = t.inkSoft, fontSize = 13.sp, lineHeight = 19.sp)
                            }
                        }
                    }
                }
            }
            item {
                Column(Modifier.fillMaxWidth().padding(horizontal = 20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("MADE FOR EVERYDAY FAMILY LIFE", color = t.primary, fontSize = 11.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 1.5.sp)
                    InfoHighlight("🔐", "Privacy comes first", "Family tools are available after sign-in. Review permissions and sharing settings before enabling location or alerts.", t)
                    InfoHighlight("📍", "Your family, your choices", "Choose which features to set up. Location sharing is permission-based and can be controlled in the app.", t)
                    InfoHighlight("🇿🇦", "Designed with South African families in mind", "AmitySA brings family communication and safety tools into one simple experience.", t)
                }
            }
            item {
                Card(Modifier.fillMaxWidth().padding(horizontal = 20.dp), shape = RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(containerColor = t.primary.copy(alpha = 0.12f))) {
                    Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                        Text("Explore AmitySA", color = t.ink, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        Text("All features are organised in the MENU at the top of this screen. Open it whenever you want to access a tool or setting.", color = t.inkSoft, fontSize = 13.sp, lineHeight = 19.sp)
                    }
                }
            }
            item { Text("AmitySA · Family safety and connection", modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp), textAlign = TextAlign.Center, color = t.inkSoft, fontSize = 11.sp) }
        }
        AnimatedVisibility(
            visible = showBackToTop,
            modifier = Modifier.align(Alignment.BottomEnd).navigationBarsPadding().padding(end = 20.dp, bottom = 20.dp),
            enter = fadeIn(tween(180)) + scaleIn(initialScale = 0.82f, animationSpec = tween(220)),
            exit = fadeOut(tween(140)) + scaleOut(targetScale = 0.82f, animationSpec = tween(160))
        ) {
            FloatingActionButton(onClick = { scope.launch { listState.animateScrollToItem(0) } }, containerColor = t.primary, contentColor = Color.White, shape = RoundedCornerShape(18.dp)) {
                Text("↑", fontSize = 26.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun AnimatedFamilyHero() {
    val t = LocalAmity.current
    val motion = rememberInfiniteTransition(label = "family hero motion")
    val floatA by motion.animateFloat(initialValue = -9f, targetValue = 9f, animationSpec = infiniteRepeatable(tween(1900, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "shield float")
    val floatB by motion.animateFloat(initialValue = 8f, targetValue = -8f, animationSpec = infiniteRepeatable(tween(2300, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "heart float")
    val pulse by motion.animateFloat(initialValue = 0.94f, targetValue = 1.06f, animationSpec = infiniteRepeatable(tween(1600), RepeatMode.Reverse), label = "hero pulse")
    Box(
        Modifier.fillMaxWidth().padding(horizontal = 20.dp).height(218.dp).clip(RoundedCornerShape(30.dp))
            .background(Brush.linearGradient(listOf(HeaderTop, Color(0xFF176B78), HeaderBottom)))
    ) {
        Box(Modifier.align(Alignment.TopEnd).offset(x = 24.dp, y = (-26).dp).size(150.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.07f)))
        Box(Modifier.align(Alignment.BottomStart).offset(x = (-28).dp, y = 38.dp).size(130.dp).clip(CircleShape).background(Gold.copy(alpha = 0.12f)))
        Text("🛡️", modifier = Modifier.align(Alignment.CenterEnd).padding(end = 28.dp).graphicsLayer { translationY = floatA; scaleX = pulse; scaleY = pulse }, fontSize = 86.sp)
        Text("❤️", modifier = Modifier.align(Alignment.TopEnd).padding(top = 25.dp, end = 100.dp).graphicsLayer { translationY = floatB }, fontSize = 32.sp)
        Text("📍", modifier = Modifier.align(Alignment.BottomEnd).padding(end = 42.dp, bottom = 27.dp).graphicsLayer { translationY = -floatA }, fontSize = 30.sp)
        Column(Modifier.align(Alignment.CenterStart).fillMaxWidth(0.65f).padding(start = 22.dp, end = 8.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
            Text("TOGETHER,
WE LOOK OUT FOR EACH OTHER", color = Color.White, fontSize = 18.sp, lineHeight = 23.sp, fontWeight = FontWeight.ExtraBold)
            Text("Family connection. Everyday reassurance.", color = Color.White.copy(alpha = 0.82f), fontSize = 12.sp, lineHeight = 17.sp)
            Surface(shape = RoundedCornerShape(50), color = Gold) {
                Text("AMITYSA FAMILY", modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp), color = Color(0xFF211A08), fontSize = 10.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 1.sp)
            }
        }
    }
}

@Composable
private fun InfoHighlight(icon: String, title: String, description: String, theme: AmityTheme) {
    Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(19.dp), colors = CardDefaults.cardColors(containerColor = theme.card), elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)) {
        Row(Modifier.padding(15.dp), verticalAlignment = Alignment.Top, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Text(icon, fontSize = 25.sp)
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(title, color = theme.ink, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Text(description, color = theme.inkSoft, fontSize = 12.sp, lineHeight = 18.sp)
            }
        }
    }
}

@Composable
private fun Header(username: String, onOpenThemes: () -> Unit, onMenuAction: (String) -> Unit) {
    var menuExpanded by remember { mutableStateOf(false) }
    val entries = listOf(
        Triple("⌂", "Home", "Welcome page"),
        Triple("👨‍👩‍👧", "Children & family", "Profiles and family links"),
        Triple("🗺", "Family live map", "Shared family locations"),
        Triple("🌐", "Google Maps", "Open app or browser"),
        Triple("📍", "Safe zones", "Arrival and departure alerts"),
        Triple("🤝", "Family check-in", "Quick status updates"),
        Triple("🚨", "Emergency SOS", "Emergency alert tools"),
        Triple("☎", "SOS contacts", "Manage emergency contacts"),
        Triple("🔐", "Security & privacy", "App lock and privacy"),
        Triple("☁", "Cloud sync", "Optional account backup"),
        Triple("🎨", "Appearance", "Themes and colours"),
        Triple("↪", "Sign out", "Sign out of this account")
    )
    Column(
        modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(bottomStart = 30.dp, bottomEnd = 30.dp))
            .background(Brush.verticalGradient(listOf(Color(0xFF071A2B), Color(0xFF102B40))))
            .statusBarsPadding().padding(horizontal = 20.dp, vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Surface(onClick = { menuExpanded = true }, shape = RoundedCornerShape(14.dp), color = Color.White.copy(alpha = 0.13f)) {
                Row(Modifier.padding(horizontal = 14.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("☰", color = Color(0xFF78E8FF), fontSize = 19.sp)
                    Spacer(Modifier.width(8.dp))
                    Text("MENU", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 1.2.sp)
                    Spacer(Modifier.width(7.dp))
                    Text("◂", color = Color(0xFFFFA35C), fontSize = 15.sp)
                }
            }
            Spacer(Modifier.weight(1f))
            Text("🇿🇦", fontSize = 19.sp)
        }
        Image(painter = painterResource(R.drawable.amity_logo), contentDescription = "AmitySA logo", modifier = Modifier.fillMaxWidth(0.58f).widthIn(max = 250.dp))
        Text("Welcome back, $username", color = Color.White.copy(alpha = 0.82f), fontSize = 14.sp)
    }
    if (menuExpanded) JarvisFloatingMenu(
        heading = "AMITYSA  /  FEATURE & SYSTEM MENU",
        entries = entries,
        onDismiss = { menuExpanded = false },
        onSelect = { menuExpanded = false; if (it == "Appearance") onOpenThemes() else onMenuAction(it) }
    )
}

@Composable
private fun JarvisFloatingMenu(
    heading: String,
    entries: List<Triple<String, String, String>>,
    onDismiss: () -> Unit,
    onSelect: (String) -> Unit
) {
    val t = LocalAmity.current
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.58f)), contentAlignment = Alignment.CenterStart) {
            AnimatedVisibility(
                visible = true,
                enter = slideInHorizontally(initialOffsetX = { -it }) + fadeIn(tween(220)),
                exit = slideOutHorizontally(targetOffsetX = { -it }) + fadeOut(tween(180))
            ) {
                Surface(
                    modifier = Modifier.fillMaxHeight(0.94f).widthIn(max = 340.dp).fillMaxWidth(0.88f),
                    shape = RoundedCornerShape(topEnd = 26.dp, bottomEnd = 26.dp),
                    color = Color(0xF20A1A28),
                    shadowElevation = 24.dp,
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0x9959DFFF))
                ) {
                    Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
                        Column(Modifier.fillMaxWidth().background(Brush.verticalGradient(listOf(Color(0xFF102D43), Color(0xFF071522)))).padding(20.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    Text("AMITYSA", color = Color(0xFFE7FAFF), fontSize = 22.sp, fontWeight = FontWeight.Black, letterSpacing = 1.6.sp)
                                    Text("J.A.R.V.I.S  INTERFACE", color = Color(0xFF65DDF5), fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
                                }
                                JarvisMiniPlanet()
                                Spacer(Modifier.width(10.dp))
                                Surface(onClick = onDismiss, shape = CircleShape, color = Color(0x33FF9B5B)) {
                                    Text("✕", Modifier.padding(horizontal = 12.dp, vertical = 8.dp), color = Color(0xFFFFB17A), fontWeight = FontWeight.Bold)
                                }
                            }
                            Spacer(Modifier.height(13.dp))
                            Text(heading.uppercase(), color = Color(0xFF9FC6D8), fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                        }
                        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 12.dp, vertical = 10.dp)) {
                            entries.forEachIndexed { index, (icon, title, subtitle) ->
                                Surface(
                                    onClick = { onSelect(title) },
                                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                                    shape = RoundedCornerShape(15.dp),
                                    color = Color(0xB8143044),
                                    border = androidx.compose.foundation.BorderStroke(0.7.dp, Color(0x6659DFFF))
                                ) {
                                    Row(Modifier.padding(horizontal = 12.dp, vertical = 11.dp), verticalAlignment = Alignment.CenterVertically) {
                                        Box(Modifier.size(39.dp).clip(RoundedCornerShape(12.dp)).background(Color(0x3359DFFF)), contentAlignment = Alignment.Center) {
                                            Text(icon, fontSize = 19.sp)
                                        }
                                        Spacer(Modifier.width(12.dp))
                                        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                            Text(title, color = Color(0xFFE4F8FF), fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                            Text(subtitle, color = Color(0xFF9BB8C8), fontSize = 10.sp)
                                        }
                                        Text("›", color = Color(0xFF65DDF5), fontSize = 23.sp)
                                    }
                                }
                            }
                        }
                        Text("SYSTEM READY  •  FAMILY SAFETY CONNECTED", Modifier.fillMaxWidth().padding(16.dp), color = Color(0xFF65DDF5), fontSize = 8.sp, fontWeight = FontWeight.Bold, letterSpacing = 0.8.sp, textAlign = TextAlign.Center)
                    }
                }
            }
        }
    }
}

@Composable
private fun JarvisMiniPlanet() {
    val motion = rememberInfiniteTransition(label = "menuPlanet")
    val spin by motion.animateFloat(
        initialValue = 0f, targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(8500, easing = LinearEasing)),
        label = "menuPlanetSpin"
    )
    Canvas(Modifier.size(46.dp)) {
        val c = center
        val r = size.minDimension * 0.31f
        drawCircle(Brush.radialGradient(listOf(Color(0xFF5EDDF4).copy(alpha = 0.5f), Color(0xFF124B68).copy(alpha = 0.5f), Color(0xFF061625))), r, c)
        drawCircle(Color(0xFF79E9FF).copy(alpha = 0.75f), r, c, style = androidx.compose.ui.graphics.drawscope.Stroke(1.dp.toPx()))
        rotate(spin, c) {
            drawOval(Color(0xFF8CEBFF).copy(alpha = 0.58f), topLeft = androidx.compose.ui.geometry.Offset(c.x - r * 1.7f, c.y - r * 0.42f), size = androidx.compose.ui.geometry.Size(r * 3.4f, r * 0.84f), style = androidx.compose.ui.graphics.drawscope.Stroke(1.dp.toPx()))
            drawCircle(Color(0xFFFFA36B), 2.dp.toPx(), androidx.compose.ui.geometry.Offset(c.x + r * 1.7f, c.y))
        }
        drawArc(Color(0xFF8DEBFF).copy(alpha = 0.34f), spin * 0.4f, 145f, false, androidx.compose.ui.geometry.Offset(c.x - r * 0.72f, c.y - r * 0.88f), androidx.compose.ui.geometry.Size(r * 1.44f, r * 1.76f), style = androidx.compose.ui.graphics.drawscope.Stroke(0.8.dp.toPx()))
    }
}

@Composable
private fun NavigationDrawerContent(
    account: Account,
    onSelect: (String) -> Unit,
    onClose: () -> Unit
) {
    val t = LocalAmity.current
    val entries = listOf(
        Triple("⌂", "Home", "Your safety overview"),
        Triple("👨‍👩‍👧", "Children & family", "Profiles and family links"),
        Triple("🗺", "Family live map", "Shared family locations"),
        Triple("🌐", "Google Maps", "Open Google Maps app or browser"),
        Triple("📍", "Safe zones", "Arrival and departure alerts"),
        Triple("🤝", "Family check-in", "Quick shared status updates"),
        Triple("🚨", "Emergency SOS", "Start an emergency alert"),
        Triple("☎", "SOS contacts", "Manage emergency contacts"),
        Triple("🔐", "Security & privacy", "App lock and privacy"),
        Triple("☁", "Cloud sync", "Optional account backup"),
        Triple("🎨", "Appearance", "Themes and colours")
    )
    Surface(
        modifier = Modifier.fillMaxHeight().widthIn(max = 320.dp).fillMaxWidth(),
        color = t.card,
        shadowElevation = 18.dp,
        shape = RoundedCornerShape(topEnd = 26.dp, bottomEnd = 26.dp)
    ) {
        Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
            Box(
                Modifier.fillMaxWidth()
                    .background(Brush.verticalGradient(listOf(HeaderTop, HeaderBottom)))
                    .padding(start = 20.dp, end = 12.dp, top = 22.dp, bottom = 22.dp)
            ) {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("AmitySA", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.ExtraBold)
                            Text("FAMILY SAFETY", color = Gold, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.6.sp)
                        }
                        IconButton(onClick = onClose) {
                            Text("✕", color = Color.White, fontSize = 20.sp)
                        }
                    }
                    Spacer(Modifier.height(16.dp))
                    Text(account.username, color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
                    Text(if (account.role == Role.EDUCATOR) "Educator account" else "Parent account", color = Color.White.copy(alpha = 0.68f), fontSize = 12.sp)
                }
            }
            Text("MENU", modifier = Modifier.padding(start = 20.dp, top = 20.dp, bottom = 8.dp), color = t.inkSoft, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.4.sp)
            entries.forEach { (icon, title, subtitle) ->
                Row(
                    modifier = Modifier.fillMaxWidth().clickable { onSelect(title) }.padding(horizontal = 16.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(Modifier.size(42.dp).clip(RoundedCornerShape(13.dp)).background(t.primary.copy(alpha = 0.12f)), contentAlignment = Alignment.Center) {
                        Text(icon, fontSize = 20.sp)
                    }
                    Spacer(Modifier.width(13.dp))
                    Column(Modifier.weight(1f)) {
                        Text(title, color = t.ink, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                        Text(subtitle, color = t.inkSoft, fontSize = 11.sp)
                    }
                    Text("›", color = t.inkSoft, fontSize = 24.sp)
                }
            }
            Spacer(Modifier.weight(1f))
            HorizontalDivider(color = t.inkSoft.copy(alpha = 0.16f))
            Row(
                Modifier.fillMaxWidth().clickable { onSelect("Sign out") }.padding(horizontal = 20.dp, vertical = 18.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("↪", color = Danger, fontSize = 21.sp)
                Spacer(Modifier.width(12.dp))
                Text("Sign out", color = Danger, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
            }
        }
    }
}

@Composable
private fun OfflineBanner() {
    Row(
        modifier = Modifier
            .padding(horizontal = 20.dp)
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(Gold.copy(alpha = 0.18f))
            .padding(14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text("📴", fontSize = 20.sp)
        Spacer(Modifier.width(10.dp))
        Column {
            Text("Offline mode", color = LocalAmity.current.ink, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
            Text(
                "Limited features. Online-only tools are paused until you reconnect.",
                color = LocalAmity.current.inkSoft, fontSize = 12.sp
            )
        }
    }
}

@Composable
private fun StatusCard(online: Boolean) {
    val t = LocalAmity.current
    Card(
        modifier = Modifier.padding(horizontal = 20.dp).fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xD9091B2A)),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Row(modifier = Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(12.dp).clip(CircleShape)
                    .background(if (online) Color(0xFF2E9E5B) else Gold)
            )
            Spacer(Modifier.width(12.dp))
            Column {
                Text(
                    if (online) "Everything looks good" else "Working offline",
                    color = t.ink, fontWeight = FontWeight.SemiBold, fontSize = 16.sp
                )
                Text(
                    if (online) "Sign in to see your children's status" else "Showing information saved on this phone",
                    color = t.inkSoft, fontSize = 13.sp
                )
            }
        }
    }
}

@Composable
private fun SosCard(onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .padding(horizontal = 20.dp)
            .fillMaxWidth()
            .clip(RoundedCornerShape(24.dp))
            .background(Brush.horizontalGradient(listOf(Danger, Color(0xFFB3261E))))
            .clickable(onClick = onClick)
            .padding(22.dp)
    ) {
        Column {
            Text("SOS", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.ExtraBold)
            Text("Tap to alert your SOS contacts", color = Color.White.copy(alpha = 0.9f), fontSize = 14.sp)
        }
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(
        text,
        modifier = Modifier.padding(horizontal = 24.dp),
        fontSize = 18.sp,
        fontWeight = FontWeight.Bold,
        color = LocalAmity.current.ink
    )
}

@Composable
private fun ActionCard(item: QuickAction, enabled: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val t = LocalAmity.current
    Card(
        modifier = modifier.alpha(if (enabled) 1f else 0.45f).clickable(onClick = onClick),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xD9091B2A)),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Box(
                modifier = Modifier.size(44.dp).clip(CircleShape).background(t.primary.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) { Text(item.icon, fontSize = 22.sp) }
            Spacer(Modifier.height(12.dp))
            Text(item.title, color = t.ink, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
            Text(item.subtitle, color = t.inkSoft, fontSize = 12.sp)
        }
    }
}

@Composable
private fun ActivityRow(item: Activity) {
    val t = LocalAmity.current
    Row(
        modifier = Modifier
            .padding(horizontal = 20.dp)
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(t.card)
            .padding(14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(item.icon, fontSize = 22.sp)
        Spacer(Modifier.width(12.dp))
        Column {
            Text(item.title, color = t.ink, fontWeight = FontWeight.Medium, fontSize = 15.sp)
            Text(item.time, color = t.inkSoft, fontSize = 12.sp)
        }
    }
}

@Composable
private fun AccountSection(account: Account, onSignOut: () -> Unit) {
    val t = LocalAmity.current
    Column(
        modifier = Modifier.padding(horizontal = 20.dp).padding(top = 8.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xD9091B2A)),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
            Column(Modifier.padding(18.dp)) {
                Text(
                    if (account.role == Role.EDUCATOR) "Educator account" else "Parent account",
                    color = t.primary, fontWeight = FontWeight.SemiBold, fontSize = 13.sp
                )
                Text("@${account.username}", color = t.ink, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                Text(account.email, color = t.inkSoft, fontSize = 13.sp)
                Text(account.phone, color = t.inkSoft, fontSize = 13.sp)
            }
        }
        OutlinedButton(
            onClick = onSignOut,
            modifier = Modifier.fillMaxWidth().height(52.dp),
            shape = RoundedCornerShape(16.dp)
        ) { Text("Sign out", fontWeight = FontWeight.SemiBold, color = t.primary) }
    }
}

// ---------- Public feature preview (no account required) ----------

@Composable
private fun AmityWelcomeScreen(onSignIn: () -> Unit, onCreateAccount: () -> Unit) {
    val t = LocalAmity.current
    val features = listOf(
        Triple("🚨", "Emergency SOS", "A clear emergency flow to alert configured trusted contacts."),
        Triple("🗺️", "Family live map", "View linked family locations, saved safe zones and supported map views."),
        Triple("📍", "Safe-zone alerts", "Keep track of arrivals and departures around places your family saves."),
        Triple("🤝", "Family check-ins", "Share quick updates such as I'm safe, arrived, need pickup or need help."),
        Triple("👨‍👩‍👧", "Family profiles", "Organise family and child profiles from a parent account."),
        Triple("🧭", "Google Maps", "Choose to open Google Maps in the installed phone app or in a web browser."),
        Triple("📴", "Offline map option", "Browse an imported offline map package where supported. Fresh family locations still need internet."),
        Triple("🔐", "Privacy and security", "Account-based access, device security options and family controls."),
        Triple("🎨", "Personalise the app", "Preview themes and settings designed for a clearer family safety experience.")
    )
    Column(
        Modifier.fillMaxSize().background(t.canvas).verticalScroll(rememberScrollState()).navigationBarsPadding(),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Column(
            Modifier.fillMaxWidth().background(Brush.verticalGradient(listOf(HeaderTop, HeaderBottom))).statusBarsPadding().padding(horizontal = 24.dp, vertical = 28.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Image(painter = painterResource(R.drawable.amity_logo), contentDescription = "AmitySA logo", modifier = Modifier.fillMaxWidth(0.62f).widthIn(max = 250.dp))
            Spacer(Modifier.height(18.dp))
            Text("Family safety starts together.", color = Gold, fontSize = 24.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
            Spacer(Modifier.height(8.dp))
            Text("Explore what AmitySA offers before creating an account.", color = Color.White.copy(alpha = 0.78f), fontSize = 14.sp, textAlign = TextAlign.Center)
        }
        Column(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("Explore app features", color = t.ink, fontSize = 21.sp, fontWeight = FontWeight.Bold)
            Text("This is a preview. Sample screens and descriptions do not show real family data or send alerts.", color = t.inkSoft, fontSize = 13.sp)
            features.forEach { (icon, title, description) ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xD9091B2A))
                ) {
                    Row(Modifier.padding(16.dp), verticalAlignment = Alignment.Top, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                        Text(icon, fontSize = 28.sp)
                        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(title, color = t.ink, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                            Text(description, color = t.inkSoft, fontSize = 13.sp)
                        }
                    }
                }
            }
            Spacer(Modifier.height(4.dp))
            Button(onClick = onCreateAccount, modifier = Modifier.fillMaxWidth().height(54.dp), shape = RoundedCornerShape(16.dp)) {
                Text("Create free account", fontWeight = FontWeight.Bold)
            }
            OutlinedButton(onClick = onSignIn, modifier = Modifier.fillMaxWidth().height(52.dp), shape = RoundedCornerShape(16.dp)) {
                Text("Already have an account? Sign in")
            }
            Text("Sign up or sign in to unlock and use app features. SOS and location services must be configured and permissions granted before relying on them.", color = t.inkSoft, fontSize = 12.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(top = 4.dp, bottom = 12.dp))
        }
    }
}

// ---------- Sign in / Create account ----------

@Composable
private fun AuthScreen(store: AccountStore, online: Boolean, onChildSetup: () -> Unit, onAuthenticated: (Account) -> Unit, onPreview: () -> Unit, startRegistering: Boolean) {
    val t = LocalAmity.current
    var registering by remember { mutableStateOf(startRegistering) }
    var role by remember { mutableStateOf(Role.PARENT) }
    var username by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var confirm by remember { mutableStateOf("") }
    var showPassword by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    fun submit() {
        val result = if (registering) {
            if (password != confirm) AuthResult.Error("Passwords don't match.")
            else store.register(username, email, phone, password, role)
        } else store.signIn(email, password)
        when (result) {
            is AuthResult.Success -> onAuthenticated(result.account)
            is AuthResult.Error -> error = result.message
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(t.canvas)
    ) {
      Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .imePadding()
            .navigationBarsPadding()
            .padding(bottom = 104.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(bottomStart = 32.dp, bottomEnd = 32.dp))
                .background(Brush.verticalGradient(listOf(HeaderTop, HeaderBottom)))
                .statusBarsPadding()
                .padding(vertical = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Image(
                painter = painterResource(R.drawable.amity_logo),
                contentDescription = "AmitySA logo",
                modifier = Modifier.fillMaxWidth(0.5f).widthIn(max = 240.dp)
            )
        }

        Column(
            modifier = Modifier.padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text("Welcome to AmitySA", color = t.ink, fontSize = 23.sp, fontWeight = FontWeight.Bold)
            Text("Create an account to use family safety features, or preview the app first.", color = t.inkSoft, fontSize = 13.sp)
            Row(
                modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(t.card).padding(4.dp)
            ) {
                ModePill("Sign in", !registering, Modifier.weight(1f)) { registering = false; error = null }
                ModePill("Create account", registering, Modifier.weight(1f)) { registering = true; error = null }
            }

            if (registering) {
                Text("I am a…", color = t.inkSoft, fontSize = 13.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    RolePill("Educator", role == Role.EDUCATOR, Modifier.weight(1f)) { role = Role.EDUCATOR }
                    RolePill("Parent", role == Role.PARENT, Modifier.weight(1f)) { role = Role.PARENT }
                }
                AuthField(username, { username = it; error = null }, "Username")
                AuthField(phone, { phone = it; error = null }, "Phone number (South Africa)", KeyboardType.Phone)
                Text("South African numbers only, e.g. 082 123 4567 or +27 82 123 4567", color = t.inkSoft, fontSize = 12.sp)
            }
            AuthField(email, { email = it; error = null }, "Email", KeyboardType.Email)
            AuthField(
                password, { password = it; error = null }, "Password",
                password = true, showPassword = showPassword,
                trailing = {
                    Text(
                        if (showPassword) "Hide" else "Show",
                        color = t.primary, fontSize = 13.sp, fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.clickable { showPassword = !showPassword }.padding(12.dp)
                    )
                }
            )
            if (registering) {
                AuthField(confirm, { confirm = it; error = null }, "Confirm password", password = true, showPassword = showPassword)
            }

            error?.let { Text(it, color = Danger, fontSize = 13.sp) }

            Button(
                onClick = { submit() },
                modifier = Modifier.fillMaxWidth().height(54.dp),
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = t.primary,
                    contentColor = if (t.dark) Color(0xFF04201F) else Color.White
                )
            ) { Text(if (registering) "Create account" else "Sign in", fontWeight = FontWeight.SemiBold) }

            TextButton(onClick = onChildSetup, modifier = Modifier.fillMaxWidth()) {
                Text("Setting up a child's phone? Pair it here", color = t.primary, fontWeight = FontWeight.SemiBold)
            }
            Text(
                if (online) "Your account is saved securely on this phone."
                else "📴 Offline: you can still create an account and sign in on this phone.",
                color = t.inkSoft, fontSize = 12.sp, textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth()
            )
        }
      }
      // This preview-only action belongs exclusively to the signup/sign-in screen.
      // It is not rendered on the welcome preview, home screen, or feature pages.
      ExtendedFloatingActionButton(
          onClick = onPreview,
          modifier = Modifier
              .align(Alignment.BottomCenter)
              .padding(horizontal = 18.dp, vertical = 12.dp)
              .imePadding()
              .navigationBarsPadding()
              .fillMaxWidth(),
          containerColor = t.accent,
          contentColor = if (t.dark) Color(0xFF241A05) else Color(0xFF241A05),
          shape = RoundedCornerShape(18.dp)
      ) {
          Text("Skip signup for now · Preview app", fontWeight = FontWeight.Bold, fontSize = 14.sp)
      }
    }
}

@Composable
private fun ModePill(label: String, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val t = LocalAmity.current
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .background(if (selected) t.primary else Color.Transparent)
            .clickable(onClick = onClick)
            .padding(vertical = 12.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            label, fontWeight = FontWeight.SemiBold, fontSize = 14.sp,
            color = if (selected) (if (t.dark) Color(0xFF04201F) else Color.White) else t.inkSoft
        )
    }
}

@Composable
private fun RolePill(label: String, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val t = LocalAmity.current
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(14.dp))
            .background(if (selected) t.primary.copy(alpha = 0.18f) else t.card)
            .clickable(onClick = onClick)
            .padding(vertical = 14.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            if (selected) "✓ $label" else label,
            color = if (selected) t.primary else t.ink,
            fontWeight = FontWeight.SemiBold, fontSize = 15.sp
        )
    }
}

@Composable
internal fun AuthField(
    value: String,
    onChange: (String) -> Unit,
    label: String,
    keyboard: KeyboardType = KeyboardType.Text,
    password: Boolean = false,
    showPassword: Boolean = false,
    singleLine: Boolean = true,
    capitalize: Boolean = false,
    trailing: (@Composable () -> Unit)? = null
) {
    val t = LocalAmity.current
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        label = { Text(label) },
        singleLine = singleLine,
        minLines = if (singleLine) 1 else 3,
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        keyboardOptions = KeyboardOptions(
            capitalization = if (capitalize) KeyboardCapitalization.Words else KeyboardCapitalization.None,
            keyboardType = if (password) KeyboardType.Password else keyboard
        ),
        visualTransformation = if (password && !showPassword) PasswordVisualTransformation() else VisualTransformation.None,
        trailingIcon = trailing,
        colors = OutlinedTextFieldDefaults.colors(
            focusedTextColor = t.ink,
            unfocusedTextColor = t.ink,
            cursorColor = t.primary,
            focusedBorderColor = t.primary,
            unfocusedBorderColor = t.inkSoft.copy(alpha = 0.5f),
            focusedLabelColor = t.primary,
            unfocusedLabelColor = t.inkSoft
        )
    )
}

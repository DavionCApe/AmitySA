package com.amitysa.app

import android.graphics.Color
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import org.osmdroid.config.Configuration
import org.osmdroid.tileprovider.modules.OfflineTileProvider
import org.osmdroid.tileprovider.util.SimpleRegisterReceiver
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.Marker
import org.osmdroid.views.overlay.Polygon
import java.io.File
import kotlin.math.cos
import kotlin.math.sin

@Composable
internal fun OfflineFamilyMapView(
    mapFile: File,
    points: List<FamilyMapPoint>,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val mapView = androidx.compose.runtime.remember(mapFile.absolutePath) {
        Configuration.getInstance().userAgentValue = context.packageName
        MapView(context).apply {
            setTileSource(TileSourceFactory.MAPNIK)
            setMultiTouchControls(true)
            setBuiltInZoomControls(true)
            setUseDataConnection(false)
            val offlineProvider = OfflineTileProvider(SimpleRegisterReceiver(context), arrayOf(mapFile))
            setTileProvider(offlineProvider)
            controller.setZoom(12.0)
            controller.setCenter(GeoPoint(-33.9249, 18.4241))
        }
    }

    DisposableEffect(lifecycleOwner, mapView) {
        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_RESUME -> mapView.onResume()
                Lifecycle.Event.ON_PAUSE -> mapView.onPause()
                else -> Unit
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
            mapView.onPause()
            mapView.onDetach()
        }
    }

    AndroidView(
        factory = { mapView },
        modifier = modifier,
        update = { view ->
            view.overlays.clear()
            points.forEach { point ->
                val location = GeoPoint(point.lat, point.lng)
                if (point.kind == "zone" && point.radiusM > 0) {
                    val circle = Polygon(view).apply {
                        points = circlePoints(point.lat, point.lng, point.radiusM.toDouble())
                        fillPaint.color = Color.argb(35, 217, 154, 39)
                        outlinePaint.color = Color.rgb(217, 154, 39)
                        outlinePaint.strokeWidth = 3f
                    }
                    view.overlays.add(circle)
                }
                val marker = Marker(view).apply {
                    position = location
                    title = point.name
                    snippet = when {
                        point.time > 0L -> "Updated ${ageLabel(point.time)}"
                        point.kind == "zone" -> "Safe zone · ${point.radiusM} m radius"
                        else -> "Family device"
                    }
                    setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM)
                }
                view.overlays.add(marker)
            }
            view.invalidate()
        }
    )
}

private fun circlePoints(lat: Double, lon: Double, radiusMeters: Double): List<GeoPoint> {
    val earthRadius = 6_371_000.0
    val latRad = Math.toRadians(lat)
    val lonRad = Math.toRadians(lon)
    return (0..60).map { index ->
        val bearing = Math.toRadians(index * 6.0)
        val angular = radiusMeters / earthRadius
        val outLat = kotlin.math.asin(
            sin(latRad) * kotlin.math.cos(angular) +
                cos(latRad) * sin(angular) * cos(bearing)
        )
        val outLon = lonRad + kotlin.math.atan2(
            sin(bearing) * sin(angular) * cos(latRad),
            cos(angular) - sin(latRad) * sin(outLat)
        )
        GeoPoint(Math.toDegrees(outLat), Math.toDegrees(outLon))
    }
}

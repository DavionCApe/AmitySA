package com.amitysa.app

import android.annotation.SuppressLint
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat

/**
 * Parent/teacher phone: watches safe zones so arrival and departure alerts work offline.
 * Paired child phone: shares the child's location, but only while a parent or teacher keeps that feature on.
 */
class LocationService : Service(), LocationListener {
    private lateinit var lm: LocationManager
    private var lastPost = 0L
    private var lastConfig = 0L

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        lm = getSystemService(Context.LOCATION_SERVICE) as LocationManager
        ZoneMonitor.ensureChannels(this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val device = DeviceStore(this).paired()
        val account = AccountStore(this).currentAccount()
        val allowed = when {
            !ZoneMonitor.hasLocationPermission(this) -> false
            device != null -> device.features.contains(ChildFeature.LOCATION)
            account != null -> ZoneStore(this).monitoring(account.email)
            else -> false
        }
        if (!allowed) {
            stopSelf()
            return START_NOT_STICKY
        }
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val notification = NotificationCompat.Builder(this, ZoneMonitor.CHANNEL_WATCH)
            .setSmallIcon(R.drawable.ic_stat_shield)
            .setContentTitle(if (device != null) "AmitySA is sharing this phone's location" else "AmitySA is watching your safe zones")
            .setContentText(if (device != null) "Your parent or teacher turned this on." else "Tap to open. Turn off in Safe zones.")
            .setContentIntent(open)
            .setOngoing(true)
            .build()
        ServiceCompat.startForeground(this, 4101, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION)
        requestUpdates()
        return START_STICKY
    }

    @SuppressLint("MissingPermission")
    private fun requestUpdates() {
        lm.removeUpdates(this)
        listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER).forEach { provider ->
            try {
                if (lm.isProviderEnabled(provider)) lm.requestLocationUpdates(provider, 30_000L, 20f, this, Looper.getMainLooper())
            } catch (e: Exception) { }
        }
    }

    override fun onLocationChanged(location: Location) {
        val device = DeviceStore(this).paired()
        if (device != null) {
            shareChildLocation(device, location)
            return
        }
        val account = AccountStore(this).currentAccount() ?: return
        ZoneMonitor.process(this, account, location)
    }

    private fun shareChildLocation(device: DeviceInfo, location: Location) {
        val now = SystemClock.elapsedRealtime()
        if (now - lastPost < 30_000L) return
        lastPost = now
        val checkSettings = now - lastConfig > 300_000L
        if (checkSettings) lastConfig = now
        Thread {
            try { CloudClient(device.url, device.token).deviceFix(location.latitude, location.longitude, location.time) }
            catch (e: CloudException) { /* offline, or switched off remotely: the settings check below handles that */ }
            if (checkSettings) {
                val status = DeviceSync.refresh(applicationContext)
                val stillOn = DeviceStore(applicationContext).paired()?.features?.contains(ChildFeature.LOCATION) == true
                if (status == DeviceSync.Status.REVOKED || !stillOn) stopSelf()
            }
        }.start()
    }

    override fun onProviderEnabled(provider: String) { requestUpdates() }
    override fun onProviderDisabled(provider: String) {}
    @Deprecated("Deprecated in Java")
    override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}

    override fun onDestroy() {
        try { lm.removeUpdates(this) } catch (e: Exception) { }
        super.onDestroy()
    }
}

package com.amitysa.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class SosContact(val name: String, val phone: String)
data class SosEvent(val time: Long, val sent: Int, val total: Int, val hasLocation: Boolean, val source: String)

/** SOS contacts and history, saved on this phone (works offline). */
class SosStore(context: Context) {
    private val prefs = context.getSharedPreferences("amity_sos", Context.MODE_PRIVATE)

    /** Erases everything saved for this account on this phone. */
    fun deleteAll(owner: String) {
        val editor = prefs.edit()
        prefs.all.keys.filter { it.endsWith("_$owner") }.forEach { editor.remove(it) }
        editor.apply()
    }

    fun contacts(owner: String): List<SosContact> {
        val arr = JSONArray(prefs.getString("contacts_$owner", "[]"))
        return (0 until arr.length()).map { arr.getJSONObject(it) }
            .map { SosContact(it.getString("name"), it.getString("phone")) }
    }

    /** Returns false if the list is full or the number is already saved. */
    fun addContact(owner: String, contact: SosContact): Boolean {
        val current = contacts(owner)
        if (current.size >= MAX_CONTACTS || current.any { it.phone == contact.phone }) return false
        writeContacts(owner, current + contact)
        return true
    }

    fun removeContact(owner: String, phone: String) {
        writeContacts(owner, contacts(owner).filter { it.phone != phone })
    }

    fun events(owner: String): List<SosEvent> {
        val arr = JSONArray(prefs.getString("events_$owner", "[]"))
        return (0 until arr.length()).map { arr.getJSONObject(it) }.map {
            SosEvent(it.getLong("time"), it.getInt("sent"), it.getInt("total"), it.getBoolean("loc"), it.optString("source"))
        }
    }

    fun log(owner: String, event: SosEvent) {
        val updated = (listOf(event) + events(owner)).take(20)
        val arr = JSONArray()
        updated.forEach {
            arr.put(
                JSONObject().put("time", it.time).put("sent", it.sent).put("total", it.total)
                    .put("loc", it.hasLocation).put("source", it.source)
            )
        }
        prefs.edit().putString("events_$owner", arr.toString()).apply()
    }

    private fun writeContacts(owner: String, list: List<SosContact>) {
        val arr = JSONArray()
        list.forEach { arr.put(JSONObject().put("name", it.name).put("phone", it.phone)) }
        prefs.edit().putString("contacts_$owner", arr.toString()).apply()
    }

    companion object { const val MAX_CONTACTS = 5 }
}

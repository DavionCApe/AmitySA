package com.amitysa.app

import android.accessibilityservice.AccessibilityService
import android.app.KeyguardManager
import android.content.Intent
import android.os.SystemClock
import android.os.VibrationEffect
import android.os.Vibrator
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent

/**
 * Hotkey: press Volume Down 3 times within 1.5 seconds.
 * Only key presses are watched. The service does not read the screen or other apps.
 * Locked phone: the SOS text is sent straight away. Unlocked: the app opens with a 5-second cancel countdown.
 * On a paired child phone it only runs if a parent or teacher switched the hotkey on for that child.
 */
class SosHotkeyService : AccessibilityService() {
    private val presses = mutableListOf<Long>()

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onKeyEvent(event: KeyEvent): Boolean {
        if (event.keyCode == KeyEvent.KEYCODE_VOLUME_DOWN &&
            event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0
        ) {
            val now = SystemClock.elapsedRealtime()
            presses.add(now)
            presses.removeAll { now - it > 1500L }
            if (presses.size >= 3) {
                presses.clear()
                trigger()
            }
        }
        return false // volume still works as normal
    }

    private fun openApp() {
        startActivity(
            Intent(this, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                .putExtra("sos", true)
        )
    }

    private fun trigger() {
        val device = DeviceStore(this).paired()
        if (device != null && !device.features.contains(ChildFeature.HOTKEY)) return

        val vibrator = getSystemService(Vibrator::class.java)
        vibrator?.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 200, 100, 200, 100, 200), -1))
        val locked = getSystemService(KeyguardManager::class.java)?.isKeyguardLocked == true

        if (device != null) {
            if (locked && SosSender.canSend(this)) {
                Thread { SosSender.sendToNumbers(applicationContext, device.name, device.contacts.map { it.phone }, "hotkey (locked)") }.start()
            } else openApp()
            return
        }

        val account = AccountStore(this).currentAccount()
        if (locked && account != null && SosSender.canSend(this)) {
            Thread { SosSender.send(applicationContext, account, "hotkey (locked)") }.start()
        } else openApp()
    }
}

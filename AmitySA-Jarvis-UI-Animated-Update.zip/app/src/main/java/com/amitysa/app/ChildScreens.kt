package com.amitysa.app

import android.Manifest
import android.content.Intent
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// ---------- Pair this phone with a child ----------

@Composable
internal fun ChildPairScreen(onPaired: () -> Unit, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val t = LocalAmity.current
    val scope = rememberCoroutineScope()
    var inviteText by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    var agreed by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(t.canvas)
            .verticalScroll(rememberScrollState())
            .imePadding()
            .navigationBarsPadding()
    ) {
        ScreenHeader("Set up a child's phone", onBack)
        Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text(
                "A linked parent or teacher opens the child under Children, taps “Pair this child's phone” and sends you an invite. " +
                    "Paste it here. You don't need any passwords or server details.",
                color = t.inkSoft, fontSize = 14.sp
            )
            AuthField(inviteText, { inviteText = it; error = null }, "Invite (looks like ABCD2345@https://…)", KeyboardType.Uri)
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xD9091B2A))
            ) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("What pairing does", color = t.ink, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                    Text(
                        "This phone will be managed by the parent or teacher who sent the invite. Depending on what they switch on, it can " +
                            "share this phone's location with them and show an SOS button that alerts the guardian. A notification is always " +
                            "visible while location is shared. They can change or stop this at any time, and you can unpair using the phone's screen lock.",
                        color = t.inkSoft, fontSize = 13.sp
                    )
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.clickable { agreed = !agreed }) {
                        Checkbox(checked = agreed, onCheckedChange = { agreed = it })
                        Text("I understand and agree (a parent or guardian has agreed for a child)", color = t.ink, fontSize = 13.sp)
                    }
                }
            }
            error?.let { Text(it, color = Danger, fontSize = 13.sp) }
            Button(
                onClick = {
                    val invite = parseInvite(inviteText)
                    if (invite == null) { error = "That doesn't look like an invite."; return@Button }
                    if (!agreed) { error = "Please read and tick the box to agree."; return@Button }
                    scope.launch {
                        busy = true
                        try {
                            val result = withContext(Dispatchers.IO) { CloudClient(invite.url, "").pair(invite.code) }
                            if (result.config.removed) error = "This child is no longer available."
                            else {
                                DeviceStore(ctx).save(invite.url, result.token, result.childId, result.config)
                                onPaired()
                            }
                        } catch (e: CloudException) {
                            error = e.message
                        } finally { busy = false }
                    }
                },
                enabled = !busy,
                modifier = Modifier.fillMaxWidth().height(54.dp),
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(containerColor = t.primary, contentColor = if (t.dark) Color(0xFF04201F) else Color.White)
            ) { Text(if (busy) "Pairing…" else "Pair this phone", fontWeight = FontWeight.SemiBold) }
            Text(
                "A paired phone only runs the features a parent or teacher switched on for this child.",
                color = t.inkSoft, fontSize = 12.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth()
            )
        }
    }
}

// ---------- Home screen of a paired child phone ----------

private fun childPermissions(info: DeviceInfo): Array<String> = buildList {
    if (info.features.contains(ChildFeature.LOCATION)) {
        add(Manifest.permission.ACCESS_FINE_LOCATION)
        add(Manifest.permission.ACCESS_COARSE_LOCATION)
        if (Build.VERSION.SDK_INT >= 33) add(Manifest.permission.POST_NOTIFICATIONS)
    }
    if (BuildConfig.DIRECT_SMS && (info.features.contains(ChildFeature.SOS) || info.features.contains(ChildFeature.HOTKEY))) {
        add(Manifest.permission.SEND_SMS)
        add(Manifest.permission.ACCESS_FINE_LOCATION)
        add(Manifest.permission.ACCESS_COARSE_LOCATION)
    }
}.distinct().toTypedArray()

@Composable
internal fun ChildHomeScreen(info: DeviceInfo, onSos: () -> Unit, onChanged: () -> Unit) {
    val ctx = LocalContext.current
    val activity = ctx as? FragmentActivity
    val t = LocalAmity.current
    val clock = remember { SimpleDateFormat("HH:mm", Locale.getDefault()) }
    var status by remember { mutableStateOf<String?>(null) }
    var permTick by remember { mutableStateOf(0) }
    var showDisclosure by remember { mutableStateOf(false) }
    var hotkeyOn by remember { mutableStateOf(isHotkeyEnabled(ctx)) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { permTick++ }

    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) { hotkeyOn = isHotkeyEnabled(ctx); permTick++ }
        }
        owner.lifecycle.addObserver(observer)
        onDispose { owner.lifecycle.removeObserver(observer) }
    }

    suspend fun refresh() {
        val result = withContext(Dispatchers.IO) { DeviceSync.refresh(ctx) }
        status = when (result) {
            DeviceSync.Status.OK -> "Settings updated at ${clock.format(Date())}"
            DeviceSync.Status.REVOKED -> "This phone was unpaired by a parent or teacher."
            DeviceSync.Status.OFFLINE -> "Offline: using the last saved settings."
        }
        onChanged()
    }
    LaunchedEffect(Unit) {
        while (true) {
            refresh()
            delay(60_000)
        }
    }

    val wantsLocation = info.features.contains(ChildFeature.LOCATION)
    val hasLocation = remember(permTick) { ZoneMonitor.hasLocationPermission(ctx) }
    val hasSms = remember(permTick) { SosSender.ready(ctx) }
    LaunchedEffect(wantsLocation, hasLocation) {
        try {
            if (wantsLocation && hasLocation) ContextCompat.startForegroundService(ctx, Intent(ctx, LocationService::class.java))
            else ctx.stopService(Intent(ctx, LocationService::class.java))
        } catch (e: Exception) { }
    }
    val needsPermissions = (wantsLocation && !hasLocation) ||
        ((info.features.contains(ChildFeature.SOS) || info.features.contains(ChildFeature.HOTKEY)) && !hasSms)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(t.canvas)
            .verticalScroll(rememberScrollState())
            .navigationBarsPadding()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(bottomStart = 32.dp, bottomEnd = 32.dp))
                .background(Brush.verticalGradient(listOf(HeaderTop, HeaderBottom)))
                .statusBarsPadding()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Image(
                painter = painterResource(R.drawable.amity_logo),
                contentDescription = "AmitySA logo",
                modifier = Modifier.fillMaxWidth(0.6f).widthIn(max = 280.dp)
            )
            Text("Hi ${info.name} 👋", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Text("Your parent or teacher manages this phone's safety features.", color = Color.White.copy(alpha = 0.7f), fontSize = 13.sp, textAlign = TextAlign.Center)
        }

        Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            if (info.features.contains(ChildFeature.SOS)) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(24.dp))
                        .background(Brush.horizontalGradient(listOf(Danger, Color(0xFFB3261E))))
                        .clickable(onClick = onSos)
                        .padding(26.dp)
                ) {
                    Column {
                        Text("SOS", color = Color.White, fontSize = 32.sp, fontWeight = FontWeight.ExtraBold)
                        Text("Tap to text your guardian for help", color = Color.White.copy(alpha = 0.9f), fontSize = 14.sp)
                    }
                }
            }

            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xD9091B2A)),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Active on this phone", color = t.ink, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                    ChildFeature.available.forEach { (key, label, _) ->
                        val on = key in info.features
                        Text(
                            (if (on) "✓ " else "✗ ") + label + (if (on) "" else " (off)"),
                            color = if (on) t.ink else t.inkSoft, fontSize = 14.sp
                        )
                    }
                }
            }

            if (needsPermissions) {
                Button(
                    onClick = { launcher.launch(childPermissions(info)) },
                    modifier = Modifier.fillMaxWidth().height(50.dp),
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = t.primary, contentColor = if (t.dark) Color(0xFF04201F) else Color.White)
                ) { Text("Allow the permissions needed", fontWeight = FontWeight.SemiBold) }
            }

            if (BuildConfig.HOTKEY && info.features.contains(ChildFeature.HOTKEY) && !hotkeyOn) {
                OutlinedButton(
                    onClick = { showDisclosure = true },
                    modifier = Modifier.fillMaxWidth().height(50.dp),
                    shape = RoundedCornerShape(14.dp)
                ) { Text("Turn on the SOS hotkey", color = t.primary, fontWeight = FontWeight.SemiBold) }
                Text("Find “AmitySA SOS hotkey” in Accessibility and switch it on.", color = t.inkSoft, fontSize = 12.sp)
            }

            status?.let { Text(it, color = t.inkSoft, fontSize = 12.sp) }

            Text(
                "Unpair this phone", color = Danger, fontSize = 13.sp, fontWeight = FontWeight.SemiBold,
                modifier = Modifier.clickable {
                    if (activity != null && canUseLock(ctx)) {
                        promptUnlock(
                            activity, "Confirm to unpair this phone",
                            onSuccess = {
                                DeviceStore(ctx).clear()
                                ctx.stopService(Intent(ctx, LocationService::class.java))
                                onChanged()
                            },
                            onFail = { status = it }
                        )
                    } else status = "Set a screen lock on this phone to unpair it here, or ask a parent or teacher to unpair it."
                }.padding(vertical = 8.dp)
            )
        }
    }

    if (showDisclosure) {
        HotkeyDisclosureDialog(
            onAgree = {
                showDisclosure = false
                ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            },
            onDismiss = { showDisclosure = false }
        )
    }
}

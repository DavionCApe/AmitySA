package com.amitysa.app

import android.Manifest
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

internal fun startTracking(ctx: Context, owner: String) {
    ZoneStore(ctx).setMonitoring(owner, true)
    ContextCompat.startForegroundService(ctx, Intent(ctx, LocationService::class.java))
}

internal fun stopTracking(ctx: Context, owner: String) {
    ZoneStore(ctx).setMonitoring(owner, false)
    ctx.stopService(Intent(ctx, LocationService::class.java))
}

private fun trackingPermissions(): Array<String> = buildList {
    add(Manifest.permission.ACCESS_FINE_LOCATION)
    add(Manifest.permission.ACCESS_COARSE_LOCATION)
    if (Build.VERSION.SDK_INT >= 33) add(Manifest.permission.POST_NOTIFICATIONS)
}.toTypedArray()

@Composable
internal fun ZonesScreen(account: Account, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val t = LocalAmity.current
    val store = remember { ZoneStore(ctx) }
    val owner = account.email
    var zones by remember { mutableStateOf(store.zones(owner)) }
    var states by remember { mutableStateOf(store.insideStates(owner)) }
    var events by remember { mutableStateOf(store.events(owner)) }
    var fix by remember { mutableStateOf(store.lastFix(owner)) }
    var tracking by remember { mutableStateOf(store.monitoring(owner)) }
    var permOk by remember { mutableStateOf(ZoneMonitor.hasLocationPermission(ctx)) }
    var pendingStart by remember { mutableStateOf(false) }
    var name by remember { mutableStateOf("") }
    var radius by remember { mutableStateOf(200) }
    var error by remember { mutableStateOf<String?>(null) }
    val clock = remember { SimpleDateFormat("HH:mm", Locale.getDefault()) }
    val dayClock = remember { SimpleDateFormat("d MMM, HH:mm", Locale.getDefault()) }

    fun reload() {
        zones = store.zones(owner)
        states = store.insideStates(owner)
        events = store.events(owner)
        fix = store.lastFix(owner)
    }

    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        permOk = ZoneMonitor.hasLocationPermission(ctx)
        if (permOk && pendingStart) { startTracking(ctx, owner); tracking = true }
        pendingStart = false
    }

    LaunchedEffect(Unit) {
        while (true) {
            delay(5000)
            reload()
        }
    }

    fun refreshNow() {
        if (!permOk) { error = "Allow location first (tap Start tracking)."; return }
        SosSender.lastKnown(ctx)?.let { store.setLastFix(owner, it.latitude, it.longitude, it.time) }
        reload()
    }

    val buttonColors = ButtonDefaults.buttonColors(
        containerColor = t.primary, contentColor = if (t.dark) Color(0xFF04201F) else Color.White
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(t.canvas)
            .verticalScroll(rememberScrollState())
            .imePadding()
            .navigationBarsPadding()
    ) {
        ScreenHeader("Location & safe zones", onBack)
        Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {

            ZoneCard {
                Text("This phone", color = t.ink, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                Text(
                    if (tracking) "✓ Tracking is on. Arrivals and departures are checked every few seconds, even offline."
                    else "Tracking is off. Turn it on to get arrival and departure alerts.",
                    color = t.inkSoft, fontSize = 13.sp
                )
                fix?.let {
                    Text(
                        "Last position: ${"%.5f".format(it.lat)}, ${"%.5f".format(it.lng)} · ${dayClock.format(Date(it.time))}",
                        color = t.inkSoft, fontSize = 12.sp
                    )
                }
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Button(
                        onClick = {
                            if (tracking) { stopTracking(ctx, owner); tracking = false }
                            else if (permOk) { startTracking(ctx, owner); tracking = true }
                            else { pendingStart = true; launcher.launch(trackingPermissions()) }
                        },
                        shape = RoundedCornerShape(14.dp), colors = buttonColors
                    ) { Text(if (tracking) "Stop tracking" else "Start tracking", fontWeight = FontWeight.SemiBold) }
                    OutlinedButton(onClick = { refreshNow() }, shape = RoundedCornerShape(14.dp)) {
                        Text("Refresh", color = t.primary, fontWeight = FontWeight.SemiBold)
                    }
                }
                fix?.let {
                    Text(
                        "Open in Maps", color = t.primary, fontSize = 13.sp, fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.clickable {
                            ctx.startActivity(
                                Intent(Intent.ACTION_VIEW, Uri.parse("https://maps.google.com/?q=${it.lat},${it.lng}"))
                                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            )
                        }.padding(vertical = 4.dp)
                    )
                }
            }

            ZoneCard {
                Text("Safe zones", color = t.ink, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                if (zones.isEmpty()) {
                    Text("No zones yet. Stand at home, school or another safe place and save it below.", color = t.inkSoft, fontSize = 13.sp)
                }
                zones.forEach { z ->
                    val status = when (states[z.id]) {
                        true -> "Inside"
                        false -> "Outside"
                        null -> "Waiting for location"
                    }
                    Column(
                        modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(t.canvas).padding(12.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text("🛡️ ${z.name}", color = t.ink, fontWeight = FontWeight.SemiBold)
                                Text("${z.radiusM} m · $status", color = t.inkSoft, fontSize = 12.sp)
                            }
                            Text(
                                "Delete", color = Danger, fontSize = 13.sp, fontWeight = FontWeight.SemiBold,
                                modifier = Modifier.clickable { store.deleteZone(owner, z.id); reload() }.padding(8.dp)
                            )
                        }
                        if (BuildConfig.DIRECT_SMS) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Text my SOS contacts on arrival/departure", color = t.inkSoft, fontSize = 12.sp, modifier = Modifier.weight(1f))
                            Switch(checked = z.notify, onCheckedChange = { store.setNotify(owner, z.id, it); reload() })
                        }
                    }
                        }
                }
            }

            if (zones.size < ZoneStore.MAX_ZONES) {
                ZoneCard {
                    Text("Save this place as a zone", color = t.ink, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                    AuthField(name, { name = it.take(30); error = null }, "Zone name (e.g. Home, School)", capitalize = true)
                    Text("Zone size", color = t.inkSoft, fontSize = 12.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf(100, 200, 500).forEach { r ->
                            val selected = radius == r
                            Box(
                                modifier = Modifier.weight(1f).clip(RoundedCornerShape(12.dp))
                                    .background(if (selected) t.primary.copy(alpha = 0.2f) else t.canvas)
                                    .clickable { radius = r }.padding(vertical = 12.dp),
                                contentAlignment = Alignment.Center
                            ) { Text("$r m", color = if (selected) t.primary else t.ink, fontWeight = FontWeight.SemiBold) }
                        }
                    }
                    error?.let { Text(it, color = Danger, fontSize = 13.sp) }
                    Button(
                        onClick = {
                            val here = fix ?: SosSender.lastKnown(ctx)?.let { Fix(it.latitude, it.longitude, it.time) }
                            when {
                                name.isBlank() -> error = "Give the zone a name."
                                !permOk -> error = "Allow location first (tap Start tracking)."
                                here == null -> error = "No location yet. Switch on GPS, wait a moment and tap Refresh."
                                else -> {
                                    store.addZone(owner, SafeZone(store.newId(), name.trim(), here.lat, here.lng, radius, true))
                                    name = ""; error = null; reload()
                                }
                            }
                        },
                        modifier = Modifier.fillMaxWidth().height(50.dp),
                        shape = RoundedCornerShape(14.dp), colors = buttonColors
                    ) { Text("Save current location", fontWeight = FontWeight.SemiBold) }
                    Text("Stand in the middle of the place when you save it.", color = t.inkSoft, fontSize = 12.sp)
                }
            }

            if (events.isNotEmpty()) {
                ZoneCard {
                    Text("Recent zone activity", color = t.ink, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                    events.take(8).forEach {
                        Text("${dayClock.format(Date(it.time))} · ${it.text}", color = t.inkSoft, fontSize = 13.sp)
                    }
                }
            }

            Text(
                "Only this phone is tracked, and everything stays on it. Seeing another phone's location from your own needs the cloud stage.",
                color = t.inkSoft, fontSize = 12.sp
            )
        }
    }
}

@Composable
private fun ZoneCard(content: @Composable ColumnScope.() -> Unit) {
    val t = LocalAmity.current
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xD9091B2A)),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp), content = content)
    }
}

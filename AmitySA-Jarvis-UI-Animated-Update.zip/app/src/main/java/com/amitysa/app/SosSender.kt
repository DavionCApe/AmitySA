package com.amitysa.app

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationManager
import android.net.Uri
import android.os.Build
import android.telephony.SmsManager
import androidx.core.content.ContextCompat

/**
 * Sends the SOS message.
 *  - Direct build: texts the contacts by itself over the phone network (works with no internet).
 *  - Google Play build: Play does not allow the SMS permission for this app, so it opens the phone's own
 *    messages app with the alert already written. The person taps Send.
 */
object SosSender {
    data class Result(
        val sent: Int,
        val total: Int,
        val hasLocation: Boolean,
        val error: String? = null,
        val composeNumbers: List<String> = emptyList(),
        val composeMessage: String = ""
    )

    fun canSend(ctx: Context): Boolean = BuildConfig.DIRECT_SMS && granted(ctx, Manifest.permission.SEND_SMS)

    /** SOS can go ahead: direct builds need the SMS permission, Play builds only ask for location. */
    fun ready(ctx: Context): Boolean =
        if (BuildConfig.DIRECT_SMS) canSend(ctx) else ZoneMonitor.hasLocationPermission(ctx)

    private fun granted(ctx: Context, p: String) =
        ContextCompat.checkSelfPermission(ctx, p) == PackageManager.PERMISSION_GRANTED

    @SuppressLint("MissingPermission")
    internal fun lastKnown(ctx: Context): Location? {
        if (!granted(ctx, Manifest.permission.ACCESS_FINE_LOCATION) &&
            !granted(ctx, Manifest.permission.ACCESS_COARSE_LOCATION)
        ) return null
        val lm = ctx.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        return lm.getProviders(true)
            .mapNotNull { provider -> try { lm.getLastKnownLocation(provider) } catch (e: Exception) { null } }
            .maxByOrNull { it.time }
    }

    private fun smsManager(ctx: Context): SmsManager =
        if (Build.VERSION.SDK_INT >= 31) ctx.getSystemService(SmsManager::class.java)
        else @Suppress("DEPRECATION") SmsManager.getDefault()

    /** The alert text and whether it contains a location. */
    private fun emergencyMessage(ctx: Context, name: String): Pair<String, Boolean> {
        val loc = lastKnown(ctx)
        val ageMin = loc?.let { ((System.currentTimeMillis() - it.time) / 60_000L).coerceAtLeast(0) }
        val text = buildString {
            append("EMERGENCY: $name needs help (sent from AmitySA). ")
            if (loc != null) {
                append("Location: https://maps.google.com/?q=${loc.latitude},${loc.longitude}")
                if (ageMin != null && ageMin > 1) append(" (about $ageMin min ago)")
            } else append("Location unavailable.")
        }
        return text to (loc != null)
    }

    /** Opens the phone's messages app with the alert ready to send. */
    fun openCompose(ctx: Context, numbers: List<String>, message: String) {
        ctx.startActivity(
            Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + numbers.joinToString(";")))
                .putExtra("sms_body", message)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    }

    /** Direct build only. Sends any short text to the saved SOS contacts. Returns (sent, total). */
    fun sendText(ctx: Context, account: Account, text: String): Pair<Int, Int> {
        if (!BuildConfig.DIRECT_SMS) return Pair(0, 0)
        val contacts = SosStore(ctx).contacts(account.email)
        if (contacts.isEmpty() || !canSend(ctx)) return Pair(0, contacts.size)
        val sms = smsManager(ctx)
        var sent = 0
        contacts.forEach { c ->
            try {
                sms.sendMultipartTextMessage(c.phone, null, sms.divideMessage(text), null, null)
                sent++
            } catch (e: Exception) { }
        }
        return Pair(sent, contacts.size)
    }

    /** For a paired child phone: alerts the guardian number(s) with the child's last known location. */
    fun sendToNumbers(ctx: Context, name: String, numbers: List<String>, source: String): Result {
        if (numbers.isEmpty()) return Result(0, 0, false, "No guardian number is saved for this child.")
        val (message, hasLocation) = emergencyMessage(ctx, name)
        if (!BuildConfig.DIRECT_SMS) return Result(0, numbers.size, hasLocation, composeNumbers = numbers, composeMessage = message)
        if (!canSend(ctx)) return Result(0, numbers.size, false, "SMS permission is not allowed.")
        val sms = smsManager(ctx)
        var sent = 0
        numbers.forEach { n ->
            try {
                sms.sendMultipartTextMessage(n, null, sms.divideMessage(message), null, null)
                sent++
            } catch (e: Exception) { }
        }
        return Result(sent, numbers.size, hasLocation)
    }

    fun send(ctx: Context, account: Account, source: String): Result {
        val store = SosStore(ctx)
        val contacts = store.contacts(account.email)
        if (contacts.isEmpty()) return Result(0, 0, false, "You haven't added any SOS contacts yet.")
        val (message, hasLocation) = emergencyMessage(ctx, account.username)

        if (!BuildConfig.DIRECT_SMS) {
            return Result(0, contacts.size, hasLocation, composeNumbers = contacts.map { it.phone }, composeMessage = message)
        }
        if (!canSend(ctx)) return Result(0, contacts.size, false, "SMS permission is not allowed.")

        val sms = smsManager(ctx)
        var sent = 0
        contacts.forEach { c ->
            try {
                sms.sendMultipartTextMessage(c.phone, null, sms.divideMessage(message), null, null)
                sent++
            } catch (e: Exception) { /* keep trying the other contacts */ }
        }
        store.log(account.email, SosEvent(System.currentTimeMillis(), sent, contacts.size, hasLocation, source))
        return Result(sent, contacts.size, hasLocation)
    }
}

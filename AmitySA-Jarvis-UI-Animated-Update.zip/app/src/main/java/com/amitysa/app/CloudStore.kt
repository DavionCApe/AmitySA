package com.amitysa.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.security.MessageDigest

data class LinkInfo(val linkId: String, val status: String, val code: String, val partnerName: String, val partnerRole: String)

/** Optional cloud settings. Nothing is sent anywhere until the user connects and shares a child. */
class CloudStore(context: Context) {
    private val prefs = context.getSharedPreferences("amity_cloud", Context.MODE_PRIVATE)

    fun enabled(owner: String) = prefs.getBoolean("enabled_$owner", false)
    fun url(owner: String) = prefs.getString("url_$owner", "") ?: ""
    /** This phone's own token for the server. The shared access key is never stored. */
    fun token(owner: String) = prefs.getString("token_$owner", "") ?: ""

    fun connect(owner: String, url: String, token: String) {
        prefs.edit().putBoolean("enabled_$owner", true).putString("url_$owner", url).putString("token_$owner", token).apply()
    }

    fun disconnect(owner: String) {
        val editor = prefs.edit()
        prefs.all.keys.filter { it.endsWith("_$owner") }.forEach { editor.remove(it) }
        editor.apply()
    }

    /** Only a hash of the email is ever sent to the server. */
    fun accountId(email: String): String =
        MessageDigest.getInstance("SHA-256").digest(email.trim().lowercase().toByteArray()).joinToString("") { "%02x".format(it) }

    fun cachedLinks(owner: String): List<LinkInfo> {
        val arr = JSONArray(prefs.getString("links_$owner", "[]"))
        return (0 until arr.length()).map { arr.getJSONObject(it) }.map {
            LinkInfo(it.getString("linkId"), it.getString("status"), it.optString("code"), it.optString("partnerName"), it.optString("partnerRole"))
        }
    }

    fun setCachedLinks(owner: String, links: List<LinkInfo>) {
        val arr = JSONArray()
        links.forEach {
            arr.put(JSONObject().put("linkId", it.linkId).put("status", it.status).put("code", it.code)
                .put("partnerName", it.partnerName).put("partnerRole", it.partnerRole))
        }
        prefs.edit().putString("links_$owner", arr.toString()).apply()
    }

    fun setFixes(owner: String, fixes: Map<String, Fix>) {
        val obj = JSONObject()
        fixes.forEach { (id, f) -> obj.put(id, JSONObject().put("lat", f.lat).put("lng", f.lng).put("time", f.time)) }
        prefs.edit().putString("fixes_$owner", obj.toString()).apply()
    }

    fun fix(owner: String, childId: String): Fix? {
        val o = JSONObject(prefs.getString("fixes_$owner", "{}")).optJSONObject(childId) ?: return null
        return Fix(o.getDouble("lat"), o.getDouble("lng"), o.getLong("time"))
    }

    fun setDevices(owner: String, counts: Map<String, Int>) {
        val obj = JSONObject()
        counts.forEach { (id, n) -> obj.put(id, n) }
        prefs.edit().putString("devices_$owner", obj.toString()).apply()
    }

    fun deviceCount(owner: String, childId: String): Int =
        JSONObject(prefs.getString("devices_$owner", "{}")).optInt(childId, 0)
}

package com.amitysa.app

import android.content.Context
import android.util.Base64
import android.util.Patterns
import org.json.JSONArray
import org.json.JSONObject
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

enum class Role { EDUCATOR, PARENT }

data class Account(val username: String, val email: String, val phone: String, val role: Role)

sealed class AuthResult {
    data class Success(val account: Account) : AuthResult()
    data class Error(val message: String) : AuthResult()
}

/**
 * Stage 2: accounts are stored on this phone only, so sign-in works fully offline.
 * Passwords are never stored; only a salted PBKDF2 hash is kept.
 * A cloud backend (for multi-device sign-in and password reset) comes in a later stage.
 */
class AccountStore(context: Context) {
    private val prefs = context.getSharedPreferences("amity_accounts", Context.MODE_PRIVATE)

    fun currentAccount(): Account? {
        val email = prefs.getString("session_email", null) ?: return null
        return find(email)?.toAccount()
    }

    /** Removes the account from this phone, including its sign-in lock-out counters. */
    fun deleteAccount(email: String) {
        val e = email.trim().lowercase()
        val all = load()
        val kept = JSONArray()
        (0 until all.length()).map { all.getJSONObject(it) }.filter { it.getString("email") != e }.forEach { kept.put(it) }
        prefs.edit().putString("accounts", kept.toString()).remove("session_email").remove("fails_$e").remove("lock_$e").apply()
    }

    fun signOut() {
        prefs.edit().remove("session_email").apply()
    }

    fun register(username: String, email: String, phone: String, password: String, role: Role): AuthResult {
        val u = username.trim()
        val e = email.trim().lowercase()
        if (!Regex("^[A-Za-z0-9_]{3,20}$").matches(u))
            return AuthResult.Error("Username must be 3–20 letters, numbers or underscores.")
        if (!Patterns.EMAIL_ADDRESS.matcher(e).matches())
            return AuthResult.Error("Enter a valid email address.")
        val cleanPhone = normalizePhone(phone)
            ?: return AuthResult.Error("Only South African phone numbers can be registered, e.g. 082 123 4567 or +27 82 123 4567.")
        if (password.length < 8 || password.none { it.isLetter() } || password.none { it.isDigit() })
            return AuthResult.Error("Password needs 8+ characters with at least one letter and one number.")

        val accounts = load()
        if ((0 until accounts.length()).any { accounts.getJSONObject(it).getString("email") == e })
            return AuthResult.Error("An account with this email already exists.")
        if ((0 until accounts.length()).any { accounts.getJSONObject(it).getString("username").equals(u, true) })
            return AuthResult.Error("That username is taken.")

        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
        val entry = JSONObject()
            .put("username", u)
            .put("email", e)
            .put("phone", cleanPhone)
            .put("role", role.name)
            .put("salt", b64(salt))
            .put("hash", b64(hash(password, salt)))
        accounts.put(entry)
        prefs.edit().putString("accounts", accounts.toString()).putString("session_email", e).apply()
        return AuthResult.Success(entry.toAccount())
    }

    fun signIn(email: String, password: String): AuthResult {
        val e = email.trim().lowercase()
        val now = System.currentTimeMillis()
        val lockedUntil = prefs.getLong("lock_$e", 0L)
        if (now < lockedUntil)
            return AuthResult.Error("Too many attempts. Try again in ${(lockedUntil - now) / 1000 + 1}s.")

        val entry = find(e)
        val ok = entry != null && MessageDigest.isEqual(
            hash(password, Base64.decode(entry.getString("salt"), Base64.NO_WRAP)),
            Base64.decode(entry.getString("hash"), Base64.NO_WRAP)
        )
        if (ok && entry != null) {
            prefs.edit().remove("fails_$e").remove("lock_$e").putString("session_email", e).apply()
            return AuthResult.Success(entry.toAccount())
        }
        val fails = prefs.getInt("fails_$e", 0) + 1
        val editor = prefs.edit()
        if (fails >= 5) editor.putInt("fails_$e", 0).putLong("lock_$e", now + 30_000L)
        else editor.putInt("fails_$e", fails)
        editor.apply()
        return AuthResult.Error("Incorrect email or password.")
    }

    private fun normalizePhone(raw: String): String? = normalizeSaPhone(raw)

    private fun load(): JSONArray = JSONArray(prefs.getString("accounts", "[]"))

    private fun find(email: String): JSONObject? {
        val all = load()
        return (0 until all.length()).map { all.getJSONObject(it) }.firstOrNull { it.getString("email") == email }
    }

    private fun JSONObject.toAccount() =
        Account(getString("username"), getString("email"), getString("phone"), Role.valueOf(getString("role")))

    private fun hash(password: String, salt: ByteArray): ByteArray =
        SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
            .generateSecret(PBEKeySpec(password.toCharArray(), salt, 120_000, 256)).encoded

    private fun b64(bytes: ByteArray) = Base64.encodeToString(bytes, Base64.NO_WRAP)
}

/** Accepts South African numbers only (082 123 4567, 0821234567, +27 82 123 4567, 27821234567). Returns +27XXXXXXXXX or null. */
fun normalizeSaPhone(raw: String): String? {
    val cleaned = raw.filter { it.isDigit() || it == '+' }
    if (cleaned.indexOf('+') > 0 || cleaned.count { it == '+' } > 1) return null
    val national = when {
        cleaned.startsWith("+27") -> cleaned.drop(3)
        cleaned.startsWith("0027") -> cleaned.drop(4)
        cleaned.startsWith("27") && cleaned.length == 11 -> cleaned.drop(2)
        cleaned.startsWith("0") && cleaned.length == 10 -> cleaned.drop(1)
        else -> return null
    }
    return if (Regex("^[1-8][0-9]{8}$").matches(national)) "+27$national" else null
}

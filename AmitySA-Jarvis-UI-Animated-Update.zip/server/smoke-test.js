'use strict';
// Starts the backend on a spare port and walks through the real flow. Run: node server/smoke-test.js
const { spawn } = require('child_process');
const crypto = require('crypto');
const os = require('os');
const path = require('path');

const KEY = 'smoke-test-key-0123456789abcdef';
const PORT = 20000 + Math.floor(Math.random() * 10000);
const BASE = `http://127.0.0.1:${PORT}`;
const DATA = path.join(os.tmpdir(), `amity-smoke-${process.pid}.json`);
const sha = (s) => crypto.createHash('sha256').update(s).digest('hex');
const PARENT = sha('parent@example.com');
const TEACHER = sha('teacher@example.com');
const OTHER_PARENT = sha('other@example.com');

let failures = 0;
const check = (name, ok, extra = '') => {
  console.log(`${ok ? 'PASS' : 'FAIL'}  ${name}${ok ? '' : '  ' + extra}`);
  if (!ok) failures += 1;
};

const call = async (method, route, token, body) => {
  const res = await fetch(BASE + route, {
    method,
    headers: { 'Content-Type': 'application/json', ...(token !== undefined ? { Authorization: `Bearer ${token}` } : {}) },
    body: body ? JSON.stringify(body) : undefined,
  });
  let json = {};
  try { json = await res.json(); } catch (e) { /* empty */ }
  return { status: res.status, json };
};

(async () => {
  const server = spawn(process.execPath, [path.join(__dirname, 'server.js')], {
    env: { ...process.env, PORT: String(PORT), AMITY_API_KEY: KEY, DATA_FILE: DATA },
    stdio: 'ignore',
  });
  try {
    for (let i = 0; i < 50; i++) {
      try { const r = await fetch(BASE + '/health'); if (r.ok) break; } catch (e) { /* not up yet */ }
      await new Promise((r) => setTimeout(r, 100));
    }

    let r = await call('GET', '/v1/ping', 'wrong-key');
    check('wrong access key is refused', r.status === 401);
    r = await call('GET', '/v1/link/list');
    check('no token is refused', r.status === 401);

    r = await call('POST', '/v1/account/register', KEY, { accountId: PARENT, username: 'mama', role: 'parent' });
    const parentToken = r.json.token;
    check('parent registers once with the access key', r.status === 200 && !!parentToken);
    r = await call('GET', '/v1/link/list', KEY);
    check('access key alone cannot read links', r.status === 401);

    r = await call('POST', '/v1/link/create', parentToken, {});
    const { code, linkId } = r.json;
    check('parent creates an invite', r.status === 200 && code.length === 8);

    r = await call('POST', '/v1/link/join-invite', undefined, { code, accountId: OTHER_PARENT, username: 'dad', role: 'parent' });
    check('a second parent cannot join a parent invite', r.status === 400);

    r = await call('POST', '/v1/link/join-invite', undefined, { code, accountId: TEACHER, username: 'mrsx', role: 'educator' });
    const teacherToken = r.json.token;
    check('teacher joins with the invite alone (no key, no server details)', r.status === 200 && !!teacherToken);
    r = await call('POST', '/v1/link/join-invite', undefined, { code, accountId: TEACHER, username: 'mrsx', role: 'educator' });
    check('an invite works only once', r.status === 404);

    r = await call('GET', '/v1/link/list', teacherToken);
    check('teacher sees the link with the parent\'s username only',
      r.json.links.length === 1 && r.json.links[0].partnerName === 'mama' && r.json.links[0].partnerRole === 'parent');

    r = await call('POST', '/v1/checkins/create', parentToken, { linkId, status: 'SAFE', note: 'At home' });
    check('family member can send a shared safe check-in', r.status === 200 && r.json.checkin.status === 'SAFE');
    r = await call('GET', `/v1/checkins/list?linkId=${linkId}`, teacherToken);
    check('linked adult can read family check-ins', r.status === 200 && r.json.checkins.length === 1 && r.json.checkins[0].note === 'At home');
    r = await call('POST', '/v1/checkins/create', parentToken, { linkId, status: 'INVALID' });
    check('invalid check-in states are rejected', r.status === 400);

    const now = Date.now();
    r = await call('POST', '/v1/children/sync', parentToken, { linkId, children: [{
      id: 'child-0001', firstName: 'Lee', lastName: 'Kay', grade: 'Grade 4', contactName: 'Mama',
      contactPhone: '+27821234567', features: ['sos'], notes: 'peanut allergy', updatedAt: now,
    }] });
    check('parent adds a child', r.status === 200 && r.json.children.length === 1);
    check('notes and allergies are never stored on the server', !JSON.stringify(r.json).includes('peanut'));

    r = await call('POST', '/v1/children/sync', teacherToken, { linkId, children: [{
      id: 'child-0001', firstName: 'Lee', lastName: 'Kay', grade: 'Grade 4', className: '4A',
      features: ['sos', 'location', 'not-a-feature'], updatedAt: now + 5000,
    }] });
    const edited = r.json.children.find((c) => c.id === 'child-0001');
    check('teacher edits the same child with equal rights', edited.className === '4A' && edited.features.includes('location'));
    check('unknown features are dropped', !edited.features.includes('not-a-feature'));

    r = await call('POST', '/v1/children/sync', parentToken, { linkId, children: [{ id: 'child-0001', firstName: 'OLD', lastName: 'Kay', updatedAt: now + 1000 }] });
    check('an older edit does not overwrite a newer one', r.json.children[0].firstName === 'Lee');

    const many = Array.from({ length: 150 }, (_, i) => ({ id: `bulk-child-${i}`, firstName: `Kid${i}`, lastName: 'Test', updatedAt: now }));
    r = await call('POST', '/v1/children/sync', teacherToken, { linkId, children: many });
    check('many children can be added', r.status === 200 && r.json.children.length === 151);

    r = await call('POST', '/v1/device/code', parentToken, { linkId, childId: 'child-0001' });
    const pairCode = r.json.code;
    check('parent creates a child-phone pairing invite', r.status === 200 && pairCode.length === 8);
    r = await call('POST', '/v1/device/pair', undefined, { code: pairCode });
    const deviceToken = r.json.token;
    check('child phone pairs without any key', r.status === 200 && !!deviceToken && r.json.config.features.includes('location'));
    r = await call('POST', '/v1/device/pair', undefined, { code: pairCode });
    check('a pairing code works only once', r.status === 404);

    r = await call('POST', '/v1/device/fix', deviceToken, { lat: -26.2, lng: 28.04, time: Date.now() });
    check('child phone shares location while the feature is on', r.status === 200);
    r = await call('POST', '/v1/children/sync', parentToken, { linkId, children: [] });
    check('both adults see the child\'s last location', !!r.json.fixes['child-0001'] && r.json.devices['child-0001'] === 1);

    r = await call('POST', '/v1/children/sync', parentToken, { linkId, children: [{
      id: 'child-0001', firstName: 'Lee', lastName: 'Kay', features: ['sos'], updatedAt: now + 9000,
    }] });
    r = await call('POST', '/v1/device/fix', deviceToken, { lat: -26.2, lng: 28.04 });
    check('turning location off from an adult phone stops the child phone sharing', r.status === 403);
    r = await call('GET', '/v1/device/config', deviceToken);
    check('the child phone gets the new feature list', r.json.features.length === 1 && r.json.features[0] === 'sos');

    r = await call('POST', '/v1/device/revoke', teacherToken, { linkId, childId: 'child-0001' });
    r = await call('GET', '/v1/device/config', deviceToken);
    check('an adult can unpair a child phone remotely', r.status === 401);

    r = await call('POST', '/v1/children/sync', teacherToken, { linkId, children: [{ id: 'child-0001', deleted: true, updatedAt: now + 20000 }] });
    const gone = r.json.children.find((c) => c.id === 'child-0001');
    check('deleting a child removes its personal details', gone.deleted === true && !gone.firstName);

    r = await call('POST', '/v1/link/revoke', parentToken, { linkId });
    r = await call('GET', '/v1/link/list', teacherToken);
    check('either adult can remove the link', r.json.links.length === 0);

    // account deletion
    const p2 = sha('p2@example.com'), t2 = sha('t2@example.com');
    r = await call('POST', '/v1/account/register', KEY, { accountId: p2, username: 'parent2', role: 'parent' });
    const p2Token = r.json.token;
    r = await call('POST', '/v1/link/create', p2Token, {});
    const inv2 = r.json;
    r = await call('POST', '/v1/link/join-invite', undefined, { code: inv2.code, accountId: t2, username: 'teacher2', role: 'educator' });
    const t2Token = r.json.token;
    await call('POST', '/v1/children/sync', p2Token, { linkId: inv2.linkId, children: [{ id: 'child-del-01', firstName: 'Gone', lastName: 'Soon', updatedAt: Date.now() }] });
    r = await call('POST', '/v1/account/delete', p2Token, {});
    check('a person can delete their account from the server', r.status === 200);
    r = await call('GET', '/v1/link/list', p2Token);
    check('their token stops working', r.status === 401);
    r = await call('GET', '/v1/link/list', t2Token);
    check('their links and shared children are removed for the other adult too', r.json.links.length === 0);
  } catch (e) {
    console.log('FAIL  unexpected error: ' + e.message);
    failures += 1;
  } finally {
    server.kill();
    try { require('fs').unlinkSync(DATA); } catch (e) { /* none */ }
  }
  console.log(failures === 0 ? '\nAll server checks passed.' : `\n${failures} check(s) failed.`);
  process.exit(failures === 0 ? 0 : 1);
})();

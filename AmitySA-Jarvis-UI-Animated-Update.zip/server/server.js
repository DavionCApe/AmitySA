'use strict';
// AmitySA reference backend: optional parent <-> educator linking, shared children, per-child features,
// and child-phone pairing. No npm packages needed.
// The access key (AMITY_API_KEY) is only used by whoever sets the server up, once, to register their phone.
// Everyone else joins with an invite and never needs the key or anyone's login details.
// Run:  AMITY_API_KEY=<long-random-secret> node server.js
const http = require('http');
const fs = require('fs');
const crypto = require('crypto');

const PORT = process.env.PORT || 8080;
const API_KEY = process.env.AMITY_API_KEY || '';
const DATA_FILE = process.env.DATA_FILE || './data.json';
const CODE_TTL_MS = 24 * 60 * 60 * 1000;
const PAIR_TTL_MS = 15 * 60 * 1000;
const MAX_CHILDREN_PER_LINK = 5000;
const FEATURES = ['sos', 'hotkey', 'location'];

if (API_KEY.length < 16) {
  console.error('Set AMITY_API_KEY to a secret of at least 16 characters.');
  process.exit(1);
}

let db = { accounts: {}, links: {}, children: {}, devices: {}, pairCodes: {}, fixes: {}, checkins: {} };
try { db = Object.assign(db, JSON.parse(fs.readFileSync(DATA_FILE, 'utf8'))); } catch (e) { /* first run */ }
const save = () => fs.writeFileSync(DATA_FILE, JSON.stringify(db));

const digest = (s) => crypto.createHash('sha256').update(String(s)).digest();
const bearer = (req) => (req.headers['authorization'] || '').replace(/^Bearer\s*/i, '');
const authorized = (req) => crypto.timingSafeEqual(digest(bearer(req)), digest(API_KEY));

const send = (res, code, obj) => {
  res.writeHead(code, { 'Content-Type': 'application/json' });
  res.end(JSON.stringify(obj));
};
const fail = (message, status = 400) => Object.assign(new Error(message), { status });

const readBody = (req) => new Promise((resolve, reject) => {
  let data = '';
  req.on('data', (chunk) => {
    data += chunk;
    if (data.length > 2000000) { reject(fail('Request too large.', 413)); req.destroy(); }
  });
  req.on('end', () => { try { resolve(data ? JSON.parse(data) : {}); } catch (e) { reject(fail('Bad JSON.')); } });
  req.on('error', reject);
});

const attempts = new Map();
const throttled = (req) => {
  const ip = (req.headers['x-forwarded-for'] || req.socket.remoteAddress || '').toString().split(',')[0].trim();
  const now = Date.now();
  const a = attempts.get(ip) || { n: 0, reset: now + 600000 };
  if (now > a.reset) { a.n = 0; a.reset = now + 600000; }
  a.n += 1;
  attempts.set(ip, a);
  return a.n > 10;
};

const ALPHABET = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
const makeCode = () => Array.from(crypto.randomBytes(8), (b) => ALPHABET[b % ALPHABET.length]).join('');
const s = (v, n) => String(v || '').trim().slice(0, n);

const adult = (req) => {
  const a = db.accounts[bearer(req)];
  if (!a) throw fail('Please reconnect Cloud link in the app.', 401);
  return a;
};
const who = (b) => {
  if (!/^[a-f0-9]{64}$/.test(b.accountId || '')) throw fail('Bad account.');
  if (!['parent', 'educator'].includes(b.role)) throw fail('Bad role.');
  const username = s(b.username, 20);
  if (username.length < 3) throw fail('Bad username.');
  return { id: b.accountId, role: b.role, username };
};
const mine = (link, id) => link && (link.creator.id === id || (link.partner && link.partner.id === id));
const activeLinkFor = (linkId, accountId) => {
  const link = db.links[linkId];
  if (!mine(link, accountId) || link.status !== 'active') throw fail('Link not found.', 404);
  return link;
};

const prune = () => {
  const now = Date.now();
  for (const [id, l] of Object.entries(db.links)) {
    if (l.status === 'pending' && now - l.createdAt > CODE_TTL_MS) delete db.links[id];
  }
  for (const [code, p] of Object.entries(db.pairCodes)) {
    if (now > p.expires) delete db.pairCodes[code];
  }
};

const cleanRecord = (c) => {
  const id = String(c.id || '');
  if (!/^[A-Za-z0-9-]{8,64}$/.test(id)) throw fail('Bad child id.');
  const updatedAt = Math.min(Number(c.updatedAt) || 0, Date.now() + 60000);
  if (c.deleted) return { id, deleted: true, updatedAt }; // deleted records keep no personal details
  return {
    id, deleted: false, updatedAt,
    firstName: s(c.firstName, 40), lastName: s(c.lastName, 40), grade: s(c.grade, 20),
    className: s(c.className, 20), school: s(c.school, 60),
    contactName: s(c.contactName, 60), contactPhone: s(c.contactPhone, 20),
    features: (Array.isArray(c.features) ? c.features : []).filter((f) => FEATURES.includes(f)),
  };
};

const configFor = (device) => {
  const link = db.links[device.linkId];
  const rec = (db.children[device.linkId] || {})[device.childId];
  if (!link || link.status !== 'active' || !rec || rec.deleted) return { removed: true };
  return {
    removed: false,
    child: { firstName: rec.firstName, lastName: rec.lastName },
    features: rec.features,
    contacts: rec.contactPhone ? [{ name: rec.contactName, phone: rec.contactPhone }] : [],
  };
};

const dropDevices = (linkId, childId) => {
  for (const [token, d] of Object.entries(db.devices)) {
    if (d.linkId === linkId && (!childId || d.childId === childId)) delete db.devices[token];
  }
};

const server = http.createServer(async (req, res) => {
  try {
    const url = new URL(req.url, 'http://localhost');
    const path = url.pathname;
    if (req.method === 'GET' && path === '/health') return send(res, 200, { ok: true });

    const open = ['/v1/device/pair', '/v1/link/join-invite'];
    const keyed = ['/v1/ping', '/v1/account/register'];
    const isDevice = path.startsWith('/v1/device/') && !open.includes(path) && !['/v1/device/code', '/v1/device/revoke'].includes(path);
    let device = null;
    let me = null;
    if (open.includes(path)) {
      if (throttled(req)) return send(res, 429, { error: 'Too many attempts. Try again in a few minutes.' });
    } else if (keyed.includes(path)) {
      if (!authorized(req)) return send(res, 401, { error: 'Wrong access key.' });
    } else if (isDevice) {
      device = db.devices[bearer(req)];
      if (!device) return send(res, 401, { error: 'This phone is no longer paired.' });
    } else {
      me = adult(req);
    }

    const body = req.method === 'POST' ? await readBody(req) : {};
    prune();
    const route = `${req.method} ${path}`;

    if (route === 'GET /v1/ping') return send(res, 200, { ok: true });

    // Registers this phone's account and hands back its own token. The shared access key is never stored by the app.
    if (route === 'POST /v1/account/register') {
      const acct = who(body);
      const token = crypto.randomBytes(24).toString('hex');
      db.accounts[token] = { accountId: acct.id, username: acct.username, role: acct.role };
      save();
      return send(res, 200, { token });
    }

    // ----- linking (parent <-> educator). Both sides have identical rights once active. -----
    if (route === 'POST /v1/link/create') {
      const linkId = crypto.randomBytes(12).toString('hex');
      const code = makeCode();
      db.links[linkId] = { linkId, code, creator: { id: me.accountId, role: me.role, username: me.username }, partner: null, status: 'pending', createdAt: Date.now() };
      save();
      return send(res, 200, { linkId, code });
    }

    // Erases this person from the server: their tokens, their links and everything shared on those links.
    if (route === 'POST /v1/account/delete') {
      const id = me.accountId;
      for (const [linkId, l] of Object.entries(db.links)) {
        if (mine(l, id)) {
          delete db.links[linkId];
          delete db.children[linkId];
          delete db.fixes[linkId];
          delete db.checkins[linkId];
          dropDevices(linkId);
        }
      }
      for (const [token, a] of Object.entries(db.accounts)) {
        if (a.accountId === id) delete db.accounts[token];
      }
      save();
      return send(res, 200, { ok: true });
    }

    const joinWith = (code, joiner) => {
      const link = Object.values(db.links).find((l) => l.status === 'pending' && l.code === String(code || '').toUpperCase().trim());
      if (!link) throw fail('That code is not valid or has expired.', 404);
      if (link.creator.id === joiner.id) throw fail('You cannot use your own code.');
      if (link.creator.role === joiner.role) {
        throw fail(joiner.role === 'parent' ? 'A parent can only link with an educator.' : 'An educator can only link with a parent.');
      }
      link.partner = joiner;
      link.status = 'active';
      return link;
    };

    if (route === 'POST /v1/link/join') {
      const link = joinWith(body.code, { id: me.accountId, role: me.role, username: me.username });
      save();
      return send(res, 200, { linkId: link.linkId });
    }

    // Joining with an invite: no access key and no account on the server needed beforehand.
    if (route === 'POST /v1/link/join-invite') {
      const joiner = who(body);
      const link = joinWith(body.code, joiner);
      const token = crypto.randomBytes(24).toString('hex');
      db.accounts[token] = { accountId: joiner.id, username: joiner.username, role: joiner.role };
      save();
      return send(res, 200, { token, linkId: link.linkId });
    }

    if (route === 'GET /v1/link/list') {
      const id = me.accountId;
      const links = Object.values(db.links).filter((l) => mine(l, id)).map((l) => {
        const iAmCreator = l.creator.id === id;
        const other = iAmCreator ? l.partner : l.creator;
        return {
          linkId: l.linkId, status: l.status,
          code: l.status === 'pending' && iAmCreator ? l.code : '',
          partnerName: other ? other.username : '', partnerRole: other ? other.role : '',
        };
      });
      return send(res, 200, { links });
    }

    if (route === 'POST /v1/link/revoke') {
      const id = me.accountId;
      const link = db.links[body.linkId];
      if (!mine(link, id)) throw fail('Link not found.', 404);
      delete db.links[body.linkId];
      delete db.children[body.linkId];
      delete db.fixes[body.linkId];
      delete db.checkins[body.linkId];
      dropDevices(body.linkId);
      save();
      return send(res, 200, { ok: true });
    }

    // ----- shared children: either linked adult can add, edit, delete, set features -----
    if (route === 'POST /v1/children/sync') {
      const id = me.accountId;
      const link = activeLinkFor(body.linkId, id);
      const incoming = Array.isArray(body.children) ? body.children : [];
      if (incoming.length > MAX_CHILDREN_PER_LINK) throw fail('Too many children in one request.');
      const store = (db.children[link.linkId] = db.children[link.linkId] || {});
      for (const raw of incoming) {
        const r = cleanRecord(raw);
        const cur = store[r.id];
        if (!cur || r.updatedAt > cur.updatedAt) store[r.id] = r;
      }
      if (Object.keys(store).length > MAX_CHILDREN_PER_LINK) throw fail('This link has reached its child limit.');
      save();
      const live = Object.values(store).filter((c) => !c.deleted).map((c) => c.id);
      const fixes = {};
      for (const cid of live) { const f = (db.fixes[link.linkId] || {})[cid]; if (f) fixes[cid] = f; }
      const devices = {};
      for (const d of Object.values(db.devices)) {
        if (d.linkId === link.linkId) devices[d.childId] = (devices[d.childId] || 0) + 1;
      }
      return send(res, 200, { children: Object.values(store), fixes, devices });
    }

    // ----- family check-ins shared only with adults on the same active link -----
    if (route === 'POST /v1/checkins/create') {
      const link = activeLinkFor(body.linkId, me.accountId);
      const status = s(body.status, 40);
      const note = s(body.note, 180);
      if (!['SAFE', 'ARRIVED', 'PICKUP', 'HELP'].includes(status)) throw fail('Invalid check-in status.');
      const event = { id: crypto.randomBytes(10).toString('hex'), by: s(me.username, 20), role: me.role,
        status, note, time: Date.now() };
      db.checkins[link.linkId] = [event, ...(db.checkins[link.linkId] || [])].slice(0, 100);
      save();
      return send(res, 200, { checkin: event });
    }

    if (route === 'GET /v1/checkins/list') {
      const linkId = s(url.searchParams.get('linkId'), 64);
      activeLinkFor(linkId, me.accountId);
      return send(res, 200, { checkins: db.checkins[linkId] || [] });
    }

    // ----- child phones -----
    if (route === 'POST /v1/device/code') {
      const id = me.accountId;
      const link = activeLinkFor(body.linkId, id);
      const rec = (db.children[link.linkId] || {})[body.childId];
      if (!rec || rec.deleted) throw fail('Save and sync this child first.', 404);
      const code = makeCode();
      db.pairCodes[code] = { linkId: link.linkId, childId: rec.id, expires: Date.now() + PAIR_TTL_MS };
      save();
      return send(res, 200, { code });
    }

    if (route === 'POST /v1/device/pair') {
      const code = String(body.code || '').toUpperCase().trim();
      const p = db.pairCodes[code];
      if (!p) throw fail('That pairing code is not valid or has expired.', 404);
      delete db.pairCodes[code];
      const token = crypto.randomBytes(24).toString('hex');
      db.devices[token] = { linkId: p.linkId, childId: p.childId, createdAt: Date.now() };
      save();
      return send(res, 200, { token, childId: p.childId, config: configFor(db.devices[token]) });
    }

    if (route === 'POST /v1/device/revoke') {
      const id = me.accountId;
      activeLinkFor(body.linkId, id);
      dropDevices(body.linkId, body.childId);
      save();
      return send(res, 200, { ok: true });
    }

    if (route === 'GET /v1/device/config') return send(res, 200, configFor(device));

    if (route === 'POST /v1/device/fix') {
      const cfg = configFor(device);
      if (cfg.removed) return send(res, 401, { error: 'This phone is no longer paired.' });
      if (!cfg.features.includes('location')) throw fail('Location sharing is turned off for this child.', 403);
      const lat = Number(body.lat), lng = Number(body.lng);
      if (!(lat >= -90 && lat <= 90 && lng >= -180 && lng <= 180)) throw fail('Bad position.');
      const time = Math.min(Number(body.time) || Date.now(), Date.now() + 60000);
      db.fixes[device.linkId] = db.fixes[device.linkId] || {};
      db.fixes[device.linkId][device.childId] = { lat, lng, time };
      save();
      return send(res, 200, { ok: true });
    }

    return send(res, 404, { error: 'Not found.' });
  } catch (e) {
    return send(res, e.status || 500, { error: e.status ? e.message : 'Server error.' });
  }
});

server.listen(PORT, () => console.log(`AmitySA backend listening on ${PORT}`));

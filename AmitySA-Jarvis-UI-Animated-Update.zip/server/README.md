# AmitySA backend (optional)

Only needed if parents and teachers want to link accounts. The app works fully without it.

## Run it
1. Install Node.js 18 or newer on any host (Render, Railway, Fly.io, a VPS...).
2. Choose a long random secret, for example: `openssl rand -hex 24`
3. Start: `AMITY_API_KEY=your-secret node server.js`
4. Put it behind HTTPS (hosts like Render and Railway do this for you). The app only accepts `https://` addresses.

## Who needs what
- **One person (the person who hosts the server) sets it up, once, inside the app:** Cloud link, "Setting up for the first time?", enter the server address and the secret. The app uses the secret only to register that phone, then forgets it. Each phone gets its own token.
- **Everyone else just uses an invite.** A parent or teacher taps "Create an invite" and shares it (looks like `ABCD2345@https://your-server`). The other person pastes it into Cloud link. They never need the secret, the server address typed in, or anyone's login details.
- **A child's phone** is paired with an invite too: open the child under Children, tap "Pair this child's phone", share the invite.

## What links do
- A link is between one parent and one teacher. Both have equal rights: they can add, edit and delete the children on the link and switch features (SOS button, SOS hotkey, share location) on or off per child. The newest edit wins.
- Only usernames and the children each person chooses to share are stored: names, grade, class, school, guardian contact and feature settings. Notes and allergies are never sent. Passwords and emails never leave the phone (only a one-way hash of the email is used as an account ID).
- Deleting a shared child, or removing a link, removes the shared copy from the server.

## Test it
`node smoke-test.js` starts the server on a spare port and checks the whole linking, sharing and pairing flow.

## Before real use
This is a starting point, not a finished service. Data is saved in `data.json`; on hosts with temporary disks attach a persistent disk and set `DATA_FILE`. Add backups, rate limiting on all routes, and a POPIA-compliant privacy notice before storing real children's details.

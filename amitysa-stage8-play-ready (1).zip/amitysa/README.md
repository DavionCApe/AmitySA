# AmitySA

Child-safety app for parents and teachers (Android, Kotlin + Jetpack Compose).

- `app/`: the Android app. Works fully on its own, offline.
- `server/`: optional backend for linking a parent and a teacher. Includes `smoke-test.js`.
- `docs/PLAY_STORE.md`: Google Play requirements, the Play build, and Play Console answers.
- `docs/privacy-policy.html`, `docs/account-deletion.html`: templates to host and fill in.
- `docs/DEPLOY.md`: build, sign and install the APK.
- `docs/TEST_CHECKLIST.md`: what to test on real phones.
- `.github/workflows/android.yml`: tests the server, builds the debug APK, and builds a signed release APK on a `v*` tag.

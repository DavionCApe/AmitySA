plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.amitysa.app"
    compileSdk = 36
    defaultConfig {
        applicationId = "com.amitysa.app"
        minSdk = 26
        targetSdk = 36
        // Every GitHub Actions run gets a higher versionCode, so a newer APK always installs over an older one.
        versionCode = (System.getenv("GITHUB_RUN_NUMBER") ?: "1").toInt()
        versionName = "0.9.0"
    }
    // Two builds from one code base:
    //  direct = installed from a file (sends SOS texts by itself, has the volume-button hotkey)
    //  play   = for Google Play (no restricted SMS permission, no accessibility service)
    flavorDimensions += "dist"
    productFlavors {
        create("direct") {
            dimension = "dist"
            buildConfigField("boolean", "DIRECT_SMS", "true")
            buildConfigField("boolean", "HOTKEY", "true")
            buildConfigField("boolean", "EDUCATOR_SEES_LOCATION", "true")
        }
        create("play") {
            dimension = "dist"
            buildConfigField("boolean", "DIRECT_SMS", "false")
            buildConfigField("boolean", "HOTKEY", "false")
            buildConfigField("boolean", "EDUCATOR_SEES_LOCATION", "false")
        }
    }
    signingConfigs {
        create("release") {
            val keystorePath = System.getenv("KEYSTORE_PATH")
            if (keystorePath != null) {
                storeFile = file(keystorePath)
                storePassword = System.getenv("KEYSTORE_PASSWORD")
                keyAlias = System.getenv("KEY_ALIAS")
                keyPassword = System.getenv("KEY_PASSWORD")
            }
        }
    }
    buildTypes {
        release {
            isMinifyEnabled = false
            if (System.getenv("KEYSTORE_PATH") != null) signingConfig = signingConfigs.getByName("release")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures {
        compose = true
        buildConfig = true
    }
    composeOptions { kotlinCompilerExtensionVersion = "1.5.14" }
}

dependencies {
    val bom = platform("androidx.compose:compose-bom:2024.06.00")
    implementation(bom)
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.core:core-splashscreen:1.0.1")
    implementation("androidx.activity:activity-compose:1.9.0")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.biometric:biometric:1.1.0")
    implementation("androidx.compose.animation:animation")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
}

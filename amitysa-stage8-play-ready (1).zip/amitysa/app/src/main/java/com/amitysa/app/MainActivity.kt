package com.amitysa.app

import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.compose.ui.platform.LocalLifecycleOwner
import android.os.SystemClock
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlinx.coroutines.launch

// ---------- Themes (saved on the device, work fully offline) ----------

internal data class AmityTheme(
    val id: String,
    val label: String,
    val dark: Boolean,
    val canvas: Color,
    val card: Color,
    val ink: Color,
    val inkSoft: Color,
    val primary: Color,
    val accent: Color,
    val onAccent: Color
)

private val Midnight = AmityTheme(
    "midnight", "Midnight (logo colours)", true,
    Color(0xFF0F131A), Color(0xFF182029), Color(0xFFF2F4F7), Color(0xFF9AA5B4),
    Color(0xFF2DD4CF), Color(0xFFF5B942), Color(0xFF1A1405)
)
private val Ocean = AmityTheme(
    "ocean", "Ocean (light)", false,
    Color(0xFFF3F7F7), Color(0xFFFFFFFF), Color(0xFF10282A), Color(0xFF5F7070),
    Color(0xFF0B5D5E), Color(0xFFFFB020), Color(0xFF063F40)
)
private val Sunrise = AmityTheme(
    "sunrise", "Sunrise (warm light)", false,
    Color(0xFFFFF8EE), Color(0xFFFFFFFF), Color(0xFF3A2A12), Color(0xFF7A6850),
    Color(0xFFE07A1F), Color(0xFFF5B942), Color(0xFF3A2A12)
)
private val Forest = AmityTheme(
    "forest", "Forest (dark green)", true,
    Color(0xFF0E1712), Color(0xFF16241C), Color(0xFFEAF3EC), Color(0xFF93AA9B),
    Color(0xFF4CC38A), Color(0xFFE8C468), Color(0xFF14210F)
)
private val themeChoices = listOf(Midnight, Ocean, Sunrise, Forest)
private const val THEME_AUTO = "auto"

internal val LocalAmity = staticCompositionLocalOf { Midnight }

@Composable
private fun resolveTheme(id: String): AmityTheme = when (id) {
    "midnight" -> Midnight
    "ocean" -> Ocean
    "sunrise" -> Sunrise
    "forest" -> Forest
    else -> if (isSystemInDarkTheme()) Midnight else Ocean
}

// The header always stays dark so the logo glows in every theme.
internal val HeaderTop = Color(0xFF0B0E14)
internal val HeaderBottom = Color(0xFF05070B)
internal val Gold = Color(0xFFF5B942)
internal val Danger = Color(0xFFD93025)

// ---------- Content ----------

private val taglines = listOf(
    "Safety in your pocket.",
    "Securing our future.",
    "Peace of mind, simplified."
)

private data class QuickAction(
    val icon: String,
    val title: String,
    val subtitle: String,
    val needsInternet: Boolean = false
)

private data class Activity(val icon: String, val title: String, val time: String)

private val quickActions = listOf(
    QuickAction("👧", "Children", "Profiles & classes"),
    QuickAction("📍", "Location", "This phone, works offline"),
    QuickAction("🛡️", "Safe zones", "Saved on your phone"),
    QuickAction("🚨", "SOS setup", "Contacts & hotkey"),
    QuickAction("🔐", "Security", "Lock, voice & shortcut"),
    QuickAction("🎨", "Themes", "Change app look"),
    QuickAction("🔗", "Cloud link", "Optional · you choose"),
    QuickAction("⚙️", "Settings", "Account & privacy")
)

private val recentActivity = listOf(
    Activity("🏫", "Arrived at school", "Sample · 07:42"),
    Activity("🛡️", "Entered safe zone: Home", "Sample · Yesterday"),
    Activity("🔔", "Weekly safety summary ready", "Sample · Mon")
)

// ---------- Activity ----------

private fun isSosIntent(i: Intent?): Boolean =
    i?.getBooleanExtra("sos", false) == true || i?.action == "com.amitysa.app.action.SOS"

class MainActivity : FragmentActivity() {
    private var sosRequested by mutableStateOf(false)

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        if (isSosIntent(intent)) sosRequested = true
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
        )
        sosRequested = isSosIntent(intent)
        setContent { AmityApp(sosRequested) { sosRequested = false } }
    }
}

@Composable
fun AmityApp(sosRequested: Boolean = false, onSosHandled: () -> Unit = {}) {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("amity_prefs", Context.MODE_PRIVATE) }
    var themeId by remember { mutableStateOf(prefs.getString("theme", "midnight") ?: "midnight") }
    var showPopup by remember { mutableStateOf(!sosRequested) }
    var showThemes by remember { mutableStateOf(false) }
    val online by rememberOnline()
    val store = remember { AccountStore(context) }
    var account by remember { mutableStateOf(store.currentAccount()) }
    val acc = account
    val deviceStore = remember { DeviceStore(context) }
    var device by remember { mutableStateOf(deviceStore.paired()) }
    val dev = device
    var pairing by remember { mutableStateOf(false) }
    var deviceSos by remember { mutableStateOf(false) }
    val childStore = remember { ChildStore(context) }
    val sec = remember { SecurityStore(context) }
    var secTick by remember { mutableStateOf(0) }
    var locked by remember { mutableStateOf(acc != null && sec.lockEnabled(acc.email)) }
    var sosOverLock by remember { mutableStateOf(false) }
    var screen by remember { mutableStateOf("home") }
    var editingId by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(acc) {
        if (acc != null && CloudStore(context).enabled(acc.email)) CloudSync.syncInBackground(context, acc)
        if (acc != null && ZoneStore(context).monitoring(acc.email) && ZoneMonitor.hasLocationPermission(context)) {
            try { startTracking(context, acc.email) } catch (e: Exception) { }
        }
    }
    LaunchedEffect(sosRequested, acc, dev) {
        if (sosRequested) {
            if (dev != null) { if (dev.features.contains(ChildFeature.SOS) || dev.features.contains(ChildFeature.HOTKEY)) deviceSos = true }
            else if (acc != null) { if (locked) sosOverLock = true else screen = "sos" }
            onSosHandled()
        }
    }
    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner, acc?.email) {
        var leftAt = 0L
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_STOP) leftAt = SystemClock.elapsedRealtime()
            if (event == Lifecycle.Event.ON_START && leftAt != 0L) {
                val email = acc?.email
                if (email != null && sec.lockEnabled(email) && SystemClock.elapsedRealtime() - leftAt > 30_000L) locked = true
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }
    BackHandler(enabled = acc != null && screen != "home") {
        screen = if (screen == "edit") "children" else "home"
    }
    val theme = resolveTheme(themeId)

    val scheme = if (theme.dark)
        darkColorScheme(primary = theme.primary, secondary = theme.accent)
    else
        lightColorScheme(primary = theme.primary, secondary = theme.accent)

    MaterialTheme(colorScheme = scheme) {
        CompositionLocalProvider(LocalAmity provides theme) {
            if (dev != null) {
                if (deviceSos) SosCountdownScreen(
                    account = null,
                    onClose = { deviceSos = false },
                    onSetup = { deviceSos = false },
                    deviceName = dev.name,
                    deviceNumbers = dev.contacts.map { it.phone }
                ) else ChildHomeScreen(
                    info = dev,
                    onSos = { deviceSos = true },
                    onChanged = { device = deviceStore.paired() }
                )
            }
            else if (pairing) ChildPairScreen(
                onPaired = { device = deviceStore.paired(); pairing = false },
                onBack = { pairing = false }
            )
            else if (acc == null) AuthScreen(store = store, online = online, onChildSetup = { pairing = true }) { account = it }
            else if (locked) {
                if (sosOverLock) SosCountdownScreen(
                    account = acc,
                    onClose = { sosOverLock = false },
                    onSetup = { sosOverLock = false }
                ) else LockScreen(
                    onUnlock = { locked = false },
                    onSos = { sosOverLock = true },
                    onTurnOffLock = { sec.setLock(acc.email, false); locked = false; secTick++ }
                )
            }
            else if (screen == "children") ChildrenScreen(
                account = acc,
                store = childStore,
                onBack = { screen = "home" },
                onEdit = { editingId = it; screen = "edit" }
            )
            else if (screen == "edit") ChildEditScreen(
                account = acc,
                store = childStore,
                id = editingId,
                onDone = { screen = "children" }
            )
            else if (screen == "sos") SosCountdownScreen(
                account = acc,
                onClose = { screen = "home" },
                onSetup = { screen = "sosSetup" }
            )
            else if (screen == "sosSetup") SosSetupScreen(acc) { screen = "home" }
            else if (screen == "zones") ZonesScreen(acc) { screen = "home" }
            else if (screen == "cloud") CloudScreen(acc) { screen = "home" }
            else if (screen == "security") SecurityScreen(
                acc,
                onBack = { screen = "home" },
                onChanged = { secTick++ },
                onDeleted = { account = null; screen = "home"; locked = false }
            )
            else HomeScreen(
                account = acc,
                onSignOut = { stopTracking(context, acc.email); store.signOut(); account = null; screen = "home" },
                online = online,
                onOpenThemes = { showThemes = true },
                onSos = { screen = "sos" },
                onAction = { action ->
                    when {
                        action.needsInternet && !online ->
                            Toast.makeText(context, "${action.title} needs internet. You're offline.", Toast.LENGTH_SHORT).show()
                        action.title == "Themes" -> showThemes = true
                        action.title == "Children" -> screen = "children"
                        action.title == "SOS setup" -> screen = "sosSetup"
                        action.title == "Security" -> screen = "security"
                        action.title == "Cloud link" -> screen = "cloud"
                        action.title == "Location" || action.title == "Safe zones" -> screen = "zones"
                        else ->
                            Toast.makeText(context, "${action.title} is coming in a later stage.", Toast.LENGTH_SHORT).show()
                    }
                }
            )
            val voiceActive = remember(secTick, acc?.email) { acc != null && sec.voiceEnabled(acc.email) }
            val voicePhrase = remember(secTick, acc?.email) { if (acc != null) sec.phrase(acc.email) else "" }
            VoicePhraseListener(
                enabled = voiceActive && !locked && screen != "sos" && screen != "security" && !showPopup,
                phrase = voicePhrase,
                onHeard = { screen = "sos" }
            )
            if (showThemes) {
                ThemeDialog(
                    selected = themeId,
                    onSelect = {
                        themeId = it
                        prefs.edit().putString("theme", it).apply()
                    },
                    onDismiss = { showThemes = false }
                )
            }
            if (showPopup) LaunchPopup { showPopup = false }
        }
    }
}

// ---------- Connectivity ----------

@Composable
private fun rememberOnline(): State<Boolean> {
    val ctx = LocalContext.current
    val cm = remember { ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager }
    val state = remember { mutableStateOf(cm.isOnlineNow()) }
    DisposableEffect(cm) {
        val callback = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) { state.value = true }
            override fun onLost(network: Network) { state.value = false }
        }
        cm.registerDefaultNetworkCallback(callback)
        onDispose { cm.unregisterNetworkCallback(callback) }
    }
    return state
}

private fun ConnectivityManager.isOnlineNow(): Boolean {
    val caps = getNetworkCapabilities(activeNetwork) ?: return false
    return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
}

// ---------- Dialogs ----------

@Composable
private fun LaunchPopup(onDismiss: () -> Unit) {
    val scale = remember { Animatable(0.25f) }
    val fade = remember { Animatable(0f) }
    var index by remember { mutableStateOf(-1) }

    LaunchedEffect(Unit) {
        launch { fade.animateTo(1f, tween(600)) }
        scale.animateTo(
            1f,
            spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessLow)
        )
        delay(250)
        for (i in taglines.indices) {
            index = i
            delay(1400)
        }
        delay(150)
        onDismiss()
    }

    val pulse by rememberInfiniteTransition(label = "pulse").animateFloat(
        initialValue = 0.97f,
        targetValue = 1.04f,
        animationSpec = infiniteRepeatable(tween(1300, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "pulseValue"
    )

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Brush.radialGradient(listOf(Color(0xFF17222F), Color(0xFF05070B))))
                .clickable(onClick = onDismiss),
            contentAlignment = Alignment.Center
        ) {
            Column(
                modifier = Modifier.padding(32.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Image(
                    painter = painterResource(R.drawable.amity_logo),
                    contentDescription = "AmitySA logo",
                    modifier = Modifier
                        .fillMaxWidth(0.8f)
                        .widthIn(max = 360.dp)
                        .graphicsLayer {
                            val s = scale.value * pulse
                            scaleX = s
                            scaleY = s
                            alpha = fade.value
                        }
                )
                Spacer(Modifier.height(28.dp))
                Box(
                    modifier = Modifier.heightIn(min = 64.dp),
                    contentAlignment = Alignment.TopCenter
                ) {
                    AnimatedContent(
                        targetState = index,
                        transitionSpec = {
                            (slideInVertically { it } + fadeIn(tween(350)) + scaleIn(initialScale = 0.8f)) togetherWith
                                (slideOutVertically { -it } + fadeOut(tween(250)))
                        },
                        label = "tagline"
                    ) { i ->
                        if (i >= 0) {
                            Text(
                                "AmitySA: ${taglines[i]}",
                                color = Gold,
                                fontSize = 22.sp,
                                fontWeight = FontWeight.Bold,
                                textAlign = TextAlign.Center
                            )
                        } else {
                            Spacer(Modifier.height(1.dp))
                        }
                    }
                }
            }
            Text(
                "Tap to skip",
                color = Color.White.copy(alpha = 0.4f),
                fontSize = 12.sp,
                modifier = Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(24.dp)
            )
        }
    }
}

@Composable
private fun ThemeDialog(selected: String, onSelect: (String) -> Unit, onDismiss: () -> Unit) {
    val t = LocalAmity.current
    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = t.card)
        ) {
            Column(modifier = Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("App theme", color = t.ink, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Text("Saved on this phone. Works offline.", color = t.inkSoft, fontSize = 13.sp)
                Spacer(Modifier.height(4.dp))
                themeChoices.forEach { choice ->
                    ThemeRow(
                        label = choice.label,
                        swatchA = choice.primary,
                        swatchB = choice.accent,
                        isSelected = selected == choice.id,
                        onClick = { onSelect(choice.id) }
                    )
                }
                ThemeRow(
                    label = "Match my phone (auto)",
                    swatchA = Midnight.canvas,
                    swatchB = Ocean.canvas,
                    isSelected = selected == THEME_AUTO,
                    onClick = { onSelect(THEME_AUTO) }
                )
                Spacer(Modifier.height(4.dp))
                TextButton(onClick = onDismiss, modifier = Modifier.align(Alignment.End)) {
                    Text("Done", color = t.primary, fontWeight = FontWeight.SemiBold)
                }
            }
        }
    }
}

@Composable
private fun ThemeRow(label: String, swatchA: Color, swatchB: Color, isSelected: Boolean, onClick: () -> Unit) {
    val t = LocalAmity.current
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(if (isSelected) t.primary.copy(alpha = 0.15f) else Color.Transparent)
            .clickable(onClick = onClick)
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(26.dp).clip(CircleShape).background(swatchA))
        Box(Modifier.offset(x = (-8).dp).size(26.dp).clip(CircleShape).background(swatchB))
        Spacer(Modifier.width(4.dp))
        Text(label, color = t.ink, fontSize = 15.sp, modifier = Modifier.weight(1f))
        if (isSelected) Text("✓", color = t.primary, fontSize = 18.sp, fontWeight = FontWeight.Bold)
    }
}

// ---------- Home screen ----------

@Composable
private fun HomeScreen(
    account: Account,
    onSignOut: () -> Unit,
    online: Boolean,
    onOpenThemes: () -> Unit,
    onSos: () -> Unit,
    onAction: (QuickAction) -> Unit
) {
    val t = LocalAmity.current
    val ctx = LocalContext.current
    val feed = remember(account.email) {
        val fmt = SimpleDateFormat("d MMM, HH:mm", Locale.getDefault())
        ZoneStore(ctx).events(account.email).take(3).map { Activity("📍", it.text, fmt.format(Date(it.time))) }
            .ifEmpty { recentActivity }
    }
    LazyColumn(
        modifier = Modifier.fillMaxSize().background(t.canvas),
        contentPadding = PaddingValues(bottom = 40.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item { Header(account.username, onOpenThemes) }
        if (!online) item { OfflineBanner() }
        item { StatusCard(online) }
        item { SosCard(onSos) }
        item { SectionTitle("Quick actions") }
        items(quickActions.chunked(2)) { pair ->
            Row(
                modifier = Modifier.padding(horizontal = 20.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                pair.forEach { action ->
                    ActionCard(action, enabled = !(action.needsInternet && !online), modifier = Modifier.weight(1f)) {
                        onAction(action)
                    }
                }
            }
        }
        item { SectionTitle(if (online) "Recent activity" else "Saved activity") }
        items(feed) { ActivityRow(it) }
        item { AccountSection(account, onSignOut) }
    }
}

@Composable
private fun Header(username: String, onOpenThemes: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(bottomStart = 32.dp, bottomEnd = 32.dp))
            .background(Brush.verticalGradient(listOf(HeaderTop, HeaderBottom)))
            .statusBarsPadding()
            .padding(horizontal = 24.dp, vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
            Text("🎨", fontSize = 22.sp, modifier = Modifier.clickable(onClick = onOpenThemes).padding(8.dp))
        }
        Image(
            painter = painterResource(R.drawable.amity_logo),
            contentDescription = "AmitySA logo",
            modifier = Modifier.fillMaxWidth(0.7f).widthIn(max = 320.dp)
        )
        Spacer(Modifier.height(4.dp))
        Text("Welcome back, $username", color = Color.White.copy(alpha = 0.7f), fontSize = 14.sp)
        Spacer(Modifier.height(8.dp))
    }
}

@Composable
private fun OfflineBanner() {
    Row(
        modifier = Modifier
            .padding(horizontal = 20.dp)
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(Gold.copy(alpha = 0.18f))
            .padding(14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text("📴", fontSize = 20.sp)
        Spacer(Modifier.width(10.dp))
        Column {
            Text("Offline mode", color = LocalAmity.current.ink, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
            Text(
                "Limited features. Online-only tools are paused until you reconnect.",
                color = LocalAmity.current.inkSoft, fontSize = 12.sp
            )
        }
    }
}

@Composable
private fun StatusCard(online: Boolean) {
    val t = LocalAmity.current
    Card(
        modifier = Modifier.padding(horizontal = 20.dp).fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = t.card),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Row(modifier = Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(12.dp).clip(CircleShape)
                    .background(if (online) Color(0xFF2E9E5B) else Gold)
            )
            Spacer(Modifier.width(12.dp))
            Column {
                Text(
                    if (online) "Everything looks good" else "Working offline",
                    color = t.ink, fontWeight = FontWeight.SemiBold, fontSize = 16.sp
                )
                Text(
                    if (online) "Sign in to see your children's status" else "Showing information saved on this phone",
                    color = t.inkSoft, fontSize = 13.sp
                )
            }
        }
    }
}

@Composable
private fun SosCard(onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .padding(horizontal = 20.dp)
            .fillMaxWidth()
            .clip(RoundedCornerShape(24.dp))
            .background(Brush.horizontalGradient(listOf(Danger, Color(0xFFB3261E))))
            .clickable(onClick = onClick)
            .padding(22.dp)
    ) {
        Column {
            Text("SOS", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.ExtraBold)
            Text("Tap to alert your SOS contacts", color = Color.White.copy(alpha = 0.9f), fontSize = 14.sp)
        }
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(
        text,
        modifier = Modifier.padding(horizontal = 24.dp),
        fontSize = 18.sp,
        fontWeight = FontWeight.Bold,
        color = LocalAmity.current.ink
    )
}

@Composable
private fun ActionCard(item: QuickAction, enabled: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val t = LocalAmity.current
    Card(
        modifier = modifier.alpha(if (enabled) 1f else 0.45f).clickable(onClick = onClick),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = t.card),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Box(
                modifier = Modifier.size(44.dp).clip(CircleShape).background(t.primary.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) { Text(item.icon, fontSize = 22.sp) }
            Spacer(Modifier.height(12.dp))
            Text(item.title, color = t.ink, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
            Text(item.subtitle, color = t.inkSoft, fontSize = 12.sp)
        }
    }
}

@Composable
private fun ActivityRow(item: Activity) {
    val t = LocalAmity.current
    Row(
        modifier = Modifier
            .padding(horizontal = 20.dp)
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(t.card)
            .padding(14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(item.icon, fontSize = 22.sp)
        Spacer(Modifier.width(12.dp))
        Column {
            Text(item.title, color = t.ink, fontWeight = FontWeight.Medium, fontSize = 15.sp)
            Text(item.time, color = t.inkSoft, fontSize = 12.sp)
        }
    }
}

@Composable
private fun AccountSection(account: Account, onSignOut: () -> Unit) {
    val t = LocalAmity.current
    Column(
        modifier = Modifier.padding(horizontal = 20.dp).padding(top = 8.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = t.card),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
            Column(Modifier.padding(18.dp)) {
                Text(
                    if (account.role == Role.EDUCATOR) "Educator account" else "Parent account",
                    color = t.primary, fontWeight = FontWeight.SemiBold, fontSize = 13.sp
                )
                Text("@${account.username}", color = t.ink, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                Text(account.email, color = t.inkSoft, fontSize = 13.sp)
                Text(account.phone, color = t.inkSoft, fontSize = 13.sp)
            }
        }
        OutlinedButton(
            onClick = onSignOut,
            modifier = Modifier.fillMaxWidth().height(52.dp),
            shape = RoundedCornerShape(16.dp)
        ) { Text("Sign out", fontWeight = FontWeight.SemiBold, color = t.primary) }
    }
}

// ---------- Sign in / Create account ----------

@Composable
private fun AuthScreen(store: AccountStore, online: Boolean, onChildSetup: () -> Unit, onAuthenticated: (Account) -> Unit) {
    val t = LocalAmity.current
    var registering by remember { mutableStateOf(false) }
    var role by remember { mutableStateOf(Role.PARENT) }
    var username by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var confirm by remember { mutableStateOf("") }
    var showPassword by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    fun submit() {
        val result = if (registering) {
            if (password != confirm) AuthResult.Error("Passwords don't match.")
            else store.register(username, email, phone, password, role)
        } else store.signIn(email, password)
        when (result) {
            is AuthResult.Success -> onAuthenticated(result.account)
            is AuthResult.Error -> error = result.message
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(t.canvas)
            .verticalScroll(rememberScrollState())
            .imePadding()
            .navigationBarsPadding()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(bottomStart = 32.dp, bottomEnd = 32.dp))
                .background(Brush.verticalGradient(listOf(HeaderTop, HeaderBottom)))
                .statusBarsPadding()
                .padding(vertical = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Image(
                painter = painterResource(R.drawable.amity_logo),
                contentDescription = "AmitySA logo",
                modifier = Modifier.fillMaxWidth(0.5f).widthIn(max = 240.dp)
            )
        }

        Column(
            modifier = Modifier.padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(t.card).padding(4.dp)
            ) {
                ModePill("Sign in", !registering, Modifier.weight(1f)) { registering = false; error = null }
                ModePill("Create account", registering, Modifier.weight(1f)) { registering = true; error = null }
            }

            if (registering) {
                Text("I am a…", color = t.inkSoft, fontSize = 13.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    RolePill("Educator", role == Role.EDUCATOR, Modifier.weight(1f)) { role = Role.EDUCATOR }
                    RolePill("Parent", role == Role.PARENT, Modifier.weight(1f)) { role = Role.PARENT }
                }
                AuthField(username, { username = it; error = null }, "Username")
                AuthField(phone, { phone = it; error = null }, "Phone number (South Africa)", KeyboardType.Phone)
                Text("South African numbers only, e.g. 082 123 4567 or +27 82 123 4567", color = t.inkSoft, fontSize = 12.sp)
            }
            AuthField(email, { email = it; error = null }, "Email", KeyboardType.Email)
            AuthField(
                password, { password = it; error = null }, "Password",
                password = true, showPassword = showPassword,
                trailing = {
                    Text(
                        if (showPassword) "Hide" else "Show",
                        color = t.primary, fontSize = 13.sp, fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.clickable { showPassword = !showPassword }.padding(12.dp)
                    )
                }
            )
            if (registering) {
                AuthField(confirm, { confirm = it; error = null }, "Confirm password", password = true, showPassword = showPassword)
            }

            error?.let { Text(it, color = Danger, fontSize = 13.sp) }

            Button(
                onClick = { submit() },
                modifier = Modifier.fillMaxWidth().height(54.dp),
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = t.primary,
                    contentColor = if (t.dark) Color(0xFF04201F) else Color.White
                )
            ) { Text(if (registering) "Create account" else "Sign in", fontWeight = FontWeight.SemiBold) }

            TextButton(onClick = onChildSetup, modifier = Modifier.fillMaxWidth()) {
                Text("Setting up a child's phone? Pair it here", color = t.primary, fontWeight = FontWeight.SemiBold)
            }
            Text(
                if (online) "Your account is saved securely on this phone."
                else "📴 Offline: you can still create an account and sign in on this phone.",
                color = t.inkSoft, fontSize = 12.sp, textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}

@Composable
private fun ModePill(label: String, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val t = LocalAmity.current
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .background(if (selected) t.primary else Color.Transparent)
            .clickable(onClick = onClick)
            .padding(vertical = 12.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            label, fontWeight = FontWeight.SemiBold, fontSize = 14.sp,
            color = if (selected) (if (t.dark) Color(0xFF04201F) else Color.White) else t.inkSoft
        )
    }
}

@Composable
private fun RolePill(label: String, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val t = LocalAmity.current
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(14.dp))
            .background(if (selected) t.primary.copy(alpha = 0.18f) else t.card)
            .clickable(onClick = onClick)
            .padding(vertical = 14.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            if (selected) "✓ $label" else label,
            color = if (selected) t.primary else t.ink,
            fontWeight = FontWeight.SemiBold, fontSize = 15.sp
        )
    }
}

@Composable
internal fun AuthField(
    value: String,
    onChange: (String) -> Unit,
    label: String,
    keyboard: KeyboardType = KeyboardType.Text,
    password: Boolean = false,
    showPassword: Boolean = false,
    singleLine: Boolean = true,
    capitalize: Boolean = false,
    trailing: (@Composable () -> Unit)? = null
) {
    val t = LocalAmity.current
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        label = { Text(label) },
        singleLine = singleLine,
        minLines = if (singleLine) 1 else 3,
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        keyboardOptions = KeyboardOptions(
            capitalization = if (capitalize) KeyboardCapitalization.Words else KeyboardCapitalization.None,
            keyboardType = if (password) KeyboardType.Password else keyboard
        ),
        visualTransformation = if (password && !showPassword) PasswordVisualTransformation() else VisualTransformation.None,
        trailingIcon = trailing,
        colors = OutlinedTextFieldDefaults.colors(
            focusedTextColor = t.ink,
            unfocusedTextColor = t.ink,
            cursorColor = t.primary,
            focusedBorderColor = t.primary,
            unfocusedBorderColor = t.inkSoft.copy(alpha = 0.5f),
            focusedLabelColor = t.primary,
            unfocusedLabelColor = t.inkSoft
        )
    )
}

package com.amitysa.app

import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

class CloudException(message: String, val status: Int = 0) : Exception(message)

data class SyncResult(
    val children: List<Child>,
    val deleted: List<Pair<String, Long>>,
    val fixes: Map<String, Fix>,
    val devices: Map<String, Int>
)

data class DeviceConfig(val removed: Boolean, val name: String, val features: Set<String>, val contacts: List<SosContact>)
data class PairResult(val token: String, val childId: String, val config: DeviceConfig)

/**
 * Talks to the (optional) AmitySA backend over HTTPS. Call from a background thread.
 * [bearer] is the server access key for parents/teachers, or the device token on a paired child phone.
 */
class CloudClient(baseUrl: String, private val bearer: String) {
    private val base = baseUrl.trim().trimEnd('/')

    private fun request(method: String, path: String, body: JSONObject? = null): JSONObject {
        val conn = try { URL(base + path).openConnection() as HttpURLConnection }
        catch (e: Exception) { throw CloudException("That server address doesn't look right.") }
        try {
            conn.requestMethod = method
            conn.connectTimeout = 8000
            conn.readTimeout = 15000
            conn.setRequestProperty("Authorization", "Bearer $bearer")
            conn.setRequestProperty("Accept", "application/json")
            if (body != null) {
                conn.doOutput = true
                conn.setRequestProperty("Content-Type", "application/json")
                conn.outputStream.use { it.write(body.toString().toByteArray()) }
            }
            val code = conn.responseCode
            val text = (if (code in 200..299) conn.inputStream else conn.errorStream)
                ?.bufferedReader()?.use { it.readText() } ?: ""
            if (code !in 200..299) {
                val message = try { JSONObject(text).optString("error") } catch (e: Exception) { "" }
                throw CloudException(message.ifBlank { "Server error ($code)." }, code)
            }
            return if (text.isBlank()) JSONObject() else JSONObject(text)
        } catch (e: IOException) {
            throw CloudException("Can't reach the server. Check your internet connection and the address.")
        } finally {
            conn.disconnect()
        }
    }

    private fun who(accountId: String, account: Account) = JSONObject()
        .put("accountId", accountId).put("username", account.username).put("role", account.role.name.lowercase())

    // ----- parents and teachers -----

    fun ping() { request("GET", "/v1/ping") }

    /** Removes this account, its links and everything it shared from the server. */
    fun deleteAccount() { request("POST", "/v1/account/delete", JSONObject()) }

    /** Used once by whoever sets the server up: registers this phone with the access key and returns its own token. */
    fun register(accountId: String, account: Account): String =
        request("POST", "/v1/account/register", who(accountId, account)).getString("token")

    /** Joins with an invite alone: no access key and no earlier setup needed. Returns this phone's token. */
    fun joinInvite(code: String, accountId: String, account: Account): String =
        request("POST", "/v1/link/join-invite", who(accountId, account).put("code", code)).getString("token")

    fun createLink() { request("POST", "/v1/link/create", JSONObject()) }

    fun join(code: String) { request("POST", "/v1/link/join", JSONObject().put("code", code)) }

    fun links(): List<LinkInfo> {
        val arr = request("GET", "/v1/link/list").optJSONArray("links") ?: JSONArray()
        return (0 until arr.length()).map { arr.getJSONObject(it) }.map {
            LinkInfo(it.getString("linkId"), it.getString("status"), it.optString("code"), it.optString("partnerName"), it.optString("partnerRole"))
        }
    }

    fun revokeLink(linkId: String) {
        request("POST", "/v1/link/revoke", JSONObject().put("linkId", linkId))
    }

    /** Sends this phone's edits and deletions, and returns the merged state of every child on the link. */
    fun syncChildren(linkId: String, mine: List<Child>, tombstones: List<Pair<String, Long>>): SyncResult {
        val arr = JSONArray()
        mine.forEach { arr.put(it.toSyncJson()) }
        tombstones.forEach { (id, time) -> arr.put(JSONObject().put("id", id).put("deleted", true).put("updatedAt", time)) }
        val res = request("POST", "/v1/children/sync", JSONObject().put("linkId", linkId).put("children", arr))

        val children = mutableListOf<Child>()
        val deleted = mutableListOf<Pair<String, Long>>()
        val list = res.optJSONArray("children") ?: JSONArray()
        for (i in 0 until list.length()) {
            val o = list.getJSONObject(i)
            if (o.optBoolean("deleted")) deleted.add(o.getString("id") to o.optLong("updatedAt"))
            else children.add(
                Child(
                    o.getString("id"), o.optString("firstName"), o.optString("lastName"), o.optString("grade"),
                    o.optString("className"), o.optString("school"), o.optString("contactName"), o.optString("contactPhone"), "",
                    features = o.optJSONArray("features")?.let { a -> (0 until a.length()).map { a.getString(it) }.toSet() } ?: emptySet(),
                    updatedAt = o.optLong("updatedAt"), linkId = linkId
                )
            )
        }
        val fixes = mutableMapOf<String, Fix>()
        res.optJSONObject("fixes")?.let { f ->
            f.keys().forEach { id -> f.getJSONObject(id).let { fixes[id] = Fix(it.getDouble("lat"), it.getDouble("lng"), it.getLong("time")) } }
        }
        val devices = mutableMapOf<String, Int>()
        res.optJSONObject("devices")?.let { d -> d.keys().forEach { id -> devices[id] = d.getInt(id) } }
        return SyncResult(children, deleted, fixes, devices)
    }

    fun deviceCode(linkId: String, childId: String): String =
        request("POST", "/v1/device/code", JSONObject().put("linkId", linkId).put("childId", childId))
            .getString("code")

    fun deviceRevoke(linkId: String, childId: String) {
        request("POST", "/v1/device/revoke", JSONObject().put("linkId", linkId).put("childId", childId))
    }

    // ----- child phone -----

    fun pair(code: String): PairResult {
        val res = request("POST", "/v1/device/pair", JSONObject().put("code", code))
        return PairResult(res.getString("token"), res.getString("childId"), parseConfig(res.getJSONObject("config")))
    }

    fun deviceConfig(): DeviceConfig = parseConfig(request("GET", "/v1/device/config"))

    fun deviceFix(lat: Double, lng: Double, time: Long) {
        request("POST", "/v1/device/fix", JSONObject().put("lat", lat).put("lng", lng).put("time", time))
    }

    private fun parseConfig(o: JSONObject): DeviceConfig {
        val features = o.optJSONArray("features")?.let { a -> (0 until a.length()).map { a.getString(it) }.toSet() } ?: emptySet()
        val contacts = o.optJSONArray("contacts")?.let { a ->
            (0 until a.length()).map { a.getJSONObject(it) }.map { SosContact(it.optString("name"), it.getString("phone")) }
        } ?: emptyList()
        return DeviceConfig(o.optBoolean("removed"), o.optJSONObject("child")?.optString("firstName") ?: "", features, contacts)
    }
}

/** An invite looks like ABCD2345@https://your-server.example. It carries a one-time code and the server address, never a key. */
data class Invite(val code: String, val url: String)

internal fun parseInvite(raw: String): Invite? {
    val text = raw.trim()
    val at = text.indexOf('@')
    if (at < 0) return null
    val code = text.substring(0, at).trim().uppercase()
    val url = text.substring(at + 1).trim()
    return if (code.length == 8 && url.startsWith("https://")) Invite(code, url) else null
}

internal fun makeInvite(code: String, url: String) = "$code@${url.trim().trimEnd('/')}"

/** What leaves the phone for a shared child. Notes and allergies are never included. */
internal fun Child.toSyncJson(): JSONObject = JSONObject()
    .put("id", id).put("firstName", firstName).put("lastName", lastName).put("grade", grade)
    .put("className", className).put("school", school)
    .put("contactName", contactName).put("contactPhone", contactPhone)
    .put("features", JSONArray(features.toList())).put("updatedAt", updatedAt).put("deleted", false)
